$.datepicker.setDefaults({
	dateFormat: 'yy-mm-dd',
    prevText: '이전 달',
    nextText: '다음 달',
    monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
    dayNames: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
    dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'],
    showMonthAfterYear: true,
    yearSuffix: '년'
});

$(document).ready(function(){
	var fileTarget = $('.filebox .upload-hidden');
	var visible = true;
	
	fileTarget.on('change', function(){ // 값이 변경되면 
		var files = $(this)[0].files;
		
		if(window.FileReader){ // modern browser 
			var filename = $(this)[0].files[0].name; 
		} else { // old IE 
			var filename = $(this).val().split('/').pop().split('\\').pop(); // 파일명만 추출 
		} // 추출한 파일명 삽입 
		
		$(this).siblings('.upload-name').val(filename); 
		
		return false;
	});
	
	var uploadFiles = $('#ex_files');
	uploadFiles.on('change', function(){ // 값이 변경되면 
		var fileArray = $(this)[0].files;
		var fileCount = $('#file-name-field tr').length;
		$("#file-name-field tr:not(:first)").remove();

		for(var i=0; i<fileArray.length; i++){
			var filesize = formatBytes(fileArray[i].size, 0);
			if(window.FileReader){ // modern browser 
				var filename = fileArray[i].name; 
			} else { // old IE 
				var filename = $(this).val().split('/').pop().split('\\').pop(); // 파일명만 추출 
			} // 추출한 파일명 삽입 
			
			$('#file-name-field tr:last').after(
												'<tr>' +
												'<td><input type=\'checkbox\'></td> '+
		  										'<td>'+filename+'</td>' +
		  										'<td>'+filesize+'</td>' + 
												'</tr>'
												);
		}
		return false;
	});
	
	$('.my_datepicker').datepicker();
	
	// 장비관리 - 장비명 우선검색
	var hiddenShowButton = $('.check-hidden');
	hiddenShowButton.on('click', function(){
		
		if(visible){
			$('#expand_table').css('display', 'none');
			$('.check-hidden').text('▶');
		}else{
			$('#expand_table').css('display', '');
			$('.check-hidden').text('▼');
		}
		
		visible = !visible;
		return false;
	});
});

$(function(){
	$('#header').load('include/header.jsp');
});

function linkTo(url, menuName, menuIndex){
	var goTo = url + '?menuName=' + menuName;
	
	return $.ajax({
		url:url,
		type:'POST',
		data: 'menuName='+menuName,
		success: function(data){
			location.href=goTo;
		}
	});
}
function popupwindow(url, title, width, height){
	var left = (screen.width/2) - (width/2);
	var top = (screen.height/2) - (height/2);
	
	var param = 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width='+width+', height='+height+', top='+top+', left='+left;
	title = title.replace(' ', '_');
	return window.open(url, title, param);
}
function popupwindow(url, title, width, height, scrollbars){
	var left = (screen.width/2) - (width/2);
	var top = (screen.height/2) - (height/2);
	
	var param = 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width='+width+', height='+height+', top='+top+', left='+left;
	title = title.replace(' ', '_');
	return window.open(url, title, param);
}
function resizablePopupwindow(url, title, width, height){
	var left = (screen.width/2) - (width/2);
	var top = (screen.height/2) - (height/2);
	
	var param = 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, copyhistory=no, resizable=yes, width='+width+', height='+height+', top='+top+', left='+left;
	title = title.replace(' ', '_');
	return window.open(url, title, param);
}
function formatBytes(bytes,decimals) {
   if(bytes == 0) return '0 Bytes';
   var k = 1000,
       dm = decimals + 1 || 3,
       sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
       i = Math.floor(Math.log(bytes) / Math.log(k));
   return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
function msieversion() {
    var ua = window.navigator.userAgent;
    
    var msie = ua.indexOf("MSIE ");

    if (msie > 0) { // If Internet Explorer, return version number
        //console.log(parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))));
    	return true;
    } else {		// If another browser, return 0
    	//console.log('otherbrowser');
    }
    return false;
}
String.prototype.replaceAt=function(index, replacement) {
    return this.substr(0, index) + replacement+ this.substr(index + replacement.length);
}
