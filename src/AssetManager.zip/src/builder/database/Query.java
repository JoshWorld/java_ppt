package builder.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.PreparedStatement;
import java.util.ArrayList;

import builder.*;

public class Query extends Builder {

	public ArrayList Query(String SQL) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		ArrayList 			list 		= 	new ArrayList();

		try {
			con = DBCon.getConnection();
			G_Str_Msg+="Query : " + SQL + "<br>";
			pstmt = con.prepareStatement(SQL);
			pstmt.execute();
			int cnt = pstmt.getUpdateCount();
			if(cnt < 0) {
				rs = pstmt.getResultSet();
				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();
					
				ArrayList column_row = new ArrayList();
				for (int i = 1; i <= columnCount; i++)
					column_row.add(metaData.getColumnName( i ));
				list.add(column_row);
				
				while (rs.next()) {
					ArrayList row = new ArrayList();
					for (int i = 1; i <= columnCount; i++) 
						row.add(rs.getObject(i));
					list.add(row);
				}
			} else {
				ArrayList column_row = new ArrayList();
				column_row.add("���");
				ArrayList row = new ArrayList();
				row.add(Integer.toString(cnt));
				list.add(column_row);
				list.add(row);
			}
		} catch(Exception e) {
			G_Str_Err+="Query:"+e.toString()+"<br/>";
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
  		}
	}		
}