package builder.database;

import java.sql.Connection;
import java.util.logging.Logger;

import javax.sql.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;

import builder.*;

public class DBConnection extends Builder {
	static Logger logger = Logger.getLogger(DBConnection.class.getSimpleName());
	
	public Connection getConnection() throws Exception {
	    Connection conn = null;
	    Context initCtx = new InitialContext();
		DataSource ds = null;
		
		if(!Get_Property("database.lookup").equals("")) {
			Context envCtx = (Context) initCtx.lookup(Get_Property("database.lookup"));
			ds = (DataSource) envCtx.lookup(Get_Property("database.name"));
		} else {
			ds = (DataSource) initCtx.lookup(Get_Property("database.name"));
		}
	    conn = ds.getConnection();
		return conn;
	}

}
