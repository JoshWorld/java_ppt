package builder.web;

import java.util.Enumeration;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;

public class Param {
	protected HttpServletRequest request;
	protected boolean decode = false;
	protected String from = "";
	protected String to = "";
	
	public Param(HttpServletRequest request) {
		this.request = request;
	}
	public Param(HttpServletRequest request, boolean decode, String from, String to) {
		this.request = request;
		this.decode = decode;
		this.from = from;
		this.to = to;
	}
	public String getParameter(String key) {
		if(!decode) {
			return request.getParameter(key) != null ? request.getParameter(key) : "";
		} else {
			return request.getParameter(key) != null ? Utility.encode(request.getParameter(key), from, to):"";
		}
	}
	public String[] getParameterValues(String key) {
		if(!decode)
			return request.getParameterValues(key);
		else
			return Convert(key);
	}
	public String[] Convert(String key) {
		String[] str = request.getParameterValues(key);
		if(str != null) {
			for(int i=0;i<str.length;i++) {
				str[i] = Utility.encode(str[i], from, to);
			}	
		}
		return str;
	}
	public String getPrevUrl() {
		return request.getHeader("referer");
	}
	public Enumeration getHeaderNames() {
		return request.getHeaderNames();
	}
	public String getRequestURI() {
		return request.getRequestURI();	
	}
	public String getQueryString() {
		return request.getQueryString();	
	}
	public String getMethod() {
		return request.getMethod();	
	}
	public String getPathInfo() {
		return request.getPathInfo();
	}
	public String getRemoteAddr() {
		return request.getRemoteAddr();	
	}
	public String getCookie(String name) {
		String value = "";
		Cookie[] cookies = request.getCookies();
		try {
			if(cookies != null) {
				for (int i = 0; i < cookies.length; i++) {
					String temp = cookies[i].getName();
					if ((temp != null)) {
						if(temp.equals(name)) {
							 value = cookies[i].getValue();
							 break;
						}
					}
				}
			}
		} catch(Exception e) {
			System.out.print(e.toString());
		}
		return value;
	}

	public boolean setCookie(HttpServletResponse response, String dir, String name, String value, boolean expire, int second, String domain) {
		boolean result = false;
		try {
			Cookie cookie = new Cookie(name, value);
			if(!domain.equals("")) cookie.setDomain(domain);
			cookie.setVersion(0);
			cookie.setPath(dir);
			if(expire) {
				cookie.setMaxAge(second);
			}
			response.addCookie(cookie);
			result = true;
		} catch(Exception e) {
			System.out.print(e.toString());
		}
		return result;
	}
	public boolean delCookie(HttpServletResponse response,String dir,String name, String domain) {
		boolean result = false;
		try	{
			Cookie cookie = new Cookie(name, "");
			if(!domain.equals("")) cookie.setDomain(domain);
			cookie.setVersion(0);
			cookie.setPath(dir);
			cookie.setMaxAge(0);		
			response.addCookie(cookie);
			result = true;
		} catch(Exception e) {
			System.out.print(e.toString());
		}
		return result;
	}
	public boolean delAllCookie(HttpServletResponse response) {
		boolean result = false;
		Cookie[] cookies = request.getCookies();
		try {
			if(cookies != null) {
				for (int i = 0; i < cookies.length; i++) {
					cookies[i].setVersion(0);
					cookies[i].setPath("/"); 
            	//	cookies[i].setDomain(".domain.com");
					cookies[i].setMaxAge(0);		
					response.addCookie(cookies[i]);
					result = true;
				}
			}
		} catch(Exception e) {
			System.out.print(e.toString());
		}
		return result;
	}
	public boolean delAllCookie(HttpServletResponse response,String dir) {
		boolean result = false;
		Cookie[] cookies = request.getCookies();
		try {
			if(cookies != null) {
				for (int i = 0; i < cookies.length; i++) {
					cookies[i].setVersion(0);
					cookies[i].setPath(dir);
            	//	cookies[i].setDomain(".domain.com");
					cookies[i].setMaxAge(0);		
					response.addCookie(cookies[i]);
					result = true;
				}
			}
		} catch(Exception e) {
			System.out.print(e.toString());
		}
		return result;
	}
}