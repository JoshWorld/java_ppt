package builder.web;

import java.util.*;
import java.io.*;

public class SystemProperty {
    private static SystemProperty instance = null;
    private Properties props = null;
    
    private SystemProperty() throws Exception {
    	init();
    }
    
    public static synchronized SystemProperty getInstance() throws Exception {
    	if(instance == null) {
    		instance = new SystemProperty();	
    	}
    	return instance;
    }
    
    public String getProperty(String name) {
    	String result = null;
    	if(props != null) {
    		//result = Utility.encode(props.getProperty(name), "ISO8859_1", "utf-8");
    		result = props.getProperty(name);
    	}
    	return result;
    }
    
    private void init() throws Exception {
        try {
        	InputStream is = getClass().getResourceAsStream("/System.properties");
        	props = new Properties();
            	props.load(is);
        } catch (Exception e) {
		throw e;
        }
    }

 }