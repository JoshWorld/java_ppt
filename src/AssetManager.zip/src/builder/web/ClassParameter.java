package builder.web;

import java.util.Hashtable;
import java.util.ArrayList; 
import java.util.LinkedList; 
import java.text.NumberFormat;
import java.io.Serializable;
import java.io.Reader;
import java.sql.Clob;

public class ClassParameter implements java.io.Serializable {
	private Hashtable 		row 		= null;
	private int 			count 		= 0;
	private LinkedList 		list 		= null;
	private LinkedList 		rel_list 	= null;
	private ArrayList 		a_list  	= null;
	private ClassParameter 	child 		= null;

	public ArrayList getArrayList() {
		return a_list;	
	}
	
	public LinkedList getList() {
		return list;	
	}
	
	public LinkedList getRelList() {
		return rel_list;	
	}

	public int getCount() {
		return count;
	}
	
	public Object getObject(String pColName) {
		Object result = null;
		if(pColName == null) throw new java.lang.NullPointerException();
		try {
			result = (Object)row.get(pColName.toLowerCase());
		} catch(java.lang.NullPointerException e) {
			//ignore	
		}
		return result;
	}
	
	public String getString(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null)	{
			try	{
				result = obj.toString();	
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}

	public String getDecoding(String pColName, String pSecret) {
		String result = "";
		if(!pSecret.equals("1")) 
			result=getString(pColName);
		else {
			if(pColName == null) throw new java.lang.NullPointerException();
			Object obj = getObject(pColName);
			if(obj != null)	{
				try	{
					result = obj.toString();
					result = new String(org.apache.commons.codec.binary.Base64.decodeBase64(result));
				} catch(java.lang.NullPointerException e) {
					//ignore	
				}
			}
		}
		return result;
	}
	
	public String getString(String pColName, int str_length, String dot) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
			
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = obj.toString();
				if(result.length() > str_length) {
					result = result.substring(0,str_length)+dot;
				}	
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public String getString(String pColName, int str_length) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = obj.toString();
				if(result.length() > str_length) {
					result = result.substring(0,str_length);
				}	
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public String getFileName(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = obj.toString();
				if(result.length() > 21) {
					result = result.substring(21);
				}
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public String getCurrency(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = NumberFormat.getInstance().format(Long.parseLong(obj.toString())); 	
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public String getHtml(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = toHtml(obj.toString(), false);
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	public String getXml(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = toHtml(obj.toString(), true);
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public String getHtml(String pColName, int str_length, String dot) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = obj.toString();
				if(result.length() > str_length) {
					result = result.substring(0,str_length);
					result = toHtml(result, false)+dot;
				}	
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	public String getHtml(String pColName, int str_length) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = obj.toString();
				if(result.length() > str_length) {
					result = result.substring(0,str_length);
					result = toHtml(result, false);
				}	
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public int getInt(String pColName) {
		int result = 0;
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = Integer.parseInt(obj.toString().trim());
			} catch(java.lang.NumberFormatException nfe) {
				//ignore
			}
		}
		return result;
	}
	
	public long getLong(String pColName) {
		long result = 0;
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = Long.parseLong(obj.toString());
			} catch(java.lang.NumberFormatException nfe) {
				//ignore
			}
		}
		return result;
	}
	
	public float getFloat(String pColName) {
		float result = 0;
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = Float.parseFloat(obj.toString());
			} catch(java.lang.NumberFormatException nfe) {
				//ignore
			}
		}
		return result;
	}

	public double getDouble(String pColName) {
		double result = 0.00;
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = Double.parseDouble(obj.toString());
			} catch(java.lang.NumberFormatException nfe) {
				//ignore
			}
		}
		return result;		
	}
	
	public byte[] getBytes(String pColName) {
		byte[] result = null;
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try {
				result = (byte[]) obj;
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
		
	public String getKbyte(String pColName) {
		String result = "";
		try {
			long temp = getLong(pColName)/1000;
			result = NumberFormat.getInstance().format(temp);
		} catch(java.lang.NumberFormatException nfe) {
			//ignore
		}
		return result;
	}
	
	public void setObject(String pColName, Object pObj) {
		if(pColName == null) throw new java.lang.NullPointerException();
		try {
			if(row == null)	row = new Hashtable();
			row.put(pColName.toLowerCase().trim(), pObj);
		} catch(java.lang.NullPointerException e) {
			//ignore
		}
	}
	
	public void setString(String pColName, String pValue) {
		if(pColName == null) throw new java.lang.NullPointerException();
		try {
			if(row == null) row = new Hashtable();
			row.put(pColName.toLowerCase().trim(), pValue);
		} catch(Exception e) {
			//ignore
		}
	}

	public void setEncoding(String pColName, String pValue, String pSecret) {
		if(pColName == null) throw new java.lang.NullPointerException();
		if(!pSecret.equals("1")) 
			setString(pColName, pValue);
		else {
			try {
				if(row == null) row = new Hashtable();
				pValue=new String(org.apache.commons.codec.binary.Base64.encodeBase64(pValue.getBytes()));
				row.put(pColName.toLowerCase().trim(), pValue);
			} catch(Exception e) {
				//ignore
			}
		}
	}

	public void setInt(String pColName, int pValue) {
		if(pColName == null) throw new java.lang.NullPointerException();
		try {
			if(row == null) row = new Hashtable();
			row.put(pColName.toLowerCase().trim(), pValue);
		} catch(Exception e) {
			//ignore
		}
	}
	public void setLong(String pColName, long pValue) {
		if(pColName == null) throw new java.lang.NullPointerException();
		try {
			if(row == null) row = new Hashtable();
			row.put(pColName.toLowerCase().trim(), pValue);
		} catch(Exception e) {
			//ignore
		}
	}

	public void setDouble(String pColName, double pValue) {
		if(pColName == null) throw new java.lang.NullPointerException();
		try {
			if(row == null) row = new Hashtable();
			row.put(pColName.toLowerCase().trim(), pValue);
		} catch(Exception e) {
			//ignore
		}
	}
	
	public void setCount(int count) throws java.lang.NullPointerException {
		this.count = count;
	}
	
	public void setArrayList(ArrayList list) throws java.lang.NullPointerException {
		this.a_list = list;
	}
	
	public void setList(LinkedList list) throws java.lang.NullPointerException {
		this.list = list;
	}
	
	public void setRelList(LinkedList rel_list) throws java.lang.NullPointerException {
		this.rel_list = rel_list;
	}
	
	public static String toHtml(String pStr, boolean xml) {
		if (pStr == null) return	null;
		char lt = '<';
		char gt = '>';
		char sp = ' ';
		char cr = '\r';
		String gt_str = "&gt;";
		String lt_str = "&lt;";
		String sp_str = "&nbsp;";
		String cr_str = "<br/>";
		if(xml) {
			gt_str = "&amp;gt;";
			lt_str = "&amp;lt;";
			sp_str = "&amp;nbsp;";
		}
		StringBuffer sb = new StringBuffer();

		char ch = '\u0000';

		for (int i = 0; i < pStr.length(); i++) {
			ch = pStr.charAt(i);
			switch (ch) {
				case ('<') :
					sb.append(lt_str);
					break;
				case ('>') :
					sb.append(gt_str);
					break;
				case (' ') :
					sb.append(sp_str);
					break;
				case ('\r') :
					sb.append(cr_str);
					break;
			//	case ('\n') :
			//		sb.append(cr_str);
			//		break;	
				default :
					sb.append(ch);
			}
		}
		return	sb.toString();
	}
	
	
	
	public String getClobString(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		/*
		if(obj != null) {
			try {
				CLOB clob = (CLOB)obj;
				java.io.Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int nchars = 0; // Number of characters read
				char[] buffer = new char[10]; // Buffer holding characters being transferred
				while( (nchars = reader.read(buffer)) != -1 ) // Read from Clob
					sb.append(buffer, 0, nchars); // Write to StringBuffer
				result = sb.toString();
			} catch(Exception e) {
				//ignore
			}
		}
		*/
		return result;
	}

	public String getClobHtml(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		/*
		if(obj != null) {
			try {
			//	CLOB clob = (CLOB)obj;
				java.io.Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int nchars = 0; // Number of characters read
				char[] buffer = new char[10]; // Buffer holding characters being transferred
				while( (nchars = reader.read(buffer)) != -1 ) // Read from Clob
					sb.append(buffer, 0, nchars); // Write to StringBuffer
				result = toHtml(sb.toString());
			} catch(Exception e) {
				//ignore	
			}
		}
		*/
		return result;
	}
	
	
	public String getTextHtml(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		if(obj != null) {
			try	{
				result = toHtml(obj.toString(), false);
				result = result.replaceAll("&amp;", "&");
				result = result.replaceAll("&nbsp;", " ");
				result = result.replaceAll("&lt;", "<");
				result = result.replaceAll("&gt;", ">");
			} catch(java.lang.NullPointerException e) {
				//ignore	
			}
		}
		return result;
	}
	
	public String getClobTextHtml(String pColName) {
		String result = "";
		if(pColName == null) throw new java.lang.NullPointerException();
		Object obj = getObject(pColName);
		/*
		if(obj != null) {
			try {
			//	CLOB clob = (CLOB)obj;
				java.io.Reader reader = clob.getCharacterStream();
				StringBuffer sb = new StringBuffer();
				int nchars = 0; // Number of characters read
				char[] buffer = new char[10]; // Buffer holding characters being transferred
				while( (nchars = reader.read(buffer)) != -1 ) // Read from Clob
					sb.append(buffer, 0, nchars); // Write to StringBuffer
				result = toHtml(sb.toString());
				result = StringEdit.replace(result,"&amp;","&");
				result = StringEdit.replace(result,"&nbsp;"," ");
				result = StringEdit.replace(result,"&lt;","<");
				result = StringEdit.replace(result,"&gt;",">");
			} catch(Exception e) {
				//ignore	
			}
		}
		*/
		return result;
	}
}
