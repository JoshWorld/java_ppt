package builder.web;

import java.io.*;
import java.util.*;
import java.util.zip.*;
import java.lang.reflect.Field;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.FileSeekableStream;

public class Utility {

	public static String toHtml(String Doc) {
		return Doc.replace("&","&amp;").replaceAll("<","&lt").replaceAll(">","&gt").replace("\"","&quot;");
	}
	
	public static String Encoding(String pValue, String pSecret) {
		String str = null;
		try {
			if(!pSecret.equals("1")) 
				str=pValue;
			else
				str = new String(org.apache.commons.codec.binary.Base64.encodeBase64(pValue.getBytes()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	public static String Decoding(String pValue, String pSecret) {
		String str = null;
		try {
			if(!pSecret.equals("1")) 
				str=pValue;
			else
				str = new String(org.apache.commons.codec.binary.Base64.decodeBase64(pValue));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}

	public static String encode(String Unicodestr, String from, String to) { // ���ڼº�ȯ
		String str = null;
		try {
			if (Unicodestr == null) {
				return	null;
			}
			str = new String(Unicodestr.getBytes(from), to);
		} catch (java.io.UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return str;
	}

	public int Current_Page(ClassParameter row) {
		int 				Current_Page		= 	0;
		Current_Page = (row.getString("page") == null)?1:Utility.Check_Number(row.getString("page"), 1);
		return Current_Page;
	}

	public static int Check_Number(String num, int init)
	{
		int value = 0;
		try 
		{
			value = Integer.valueOf(num).intValue();
		}
		catch(Exception e){	value = init;	}	
		return value;
	}  
	
  	public static String string_cut(String value, int size)
	{
		if(value == null) {		return "";		}
		if(value.length() > size){
			value = value.substring(0,size)+"...";
		}
		return value;
	}
  
  	public static String format_date(String data_s) 
	{
    	if(data_s != null){
     		if(data_s.length() > 7 ){
      			data_s = data_s.substring(0,4) +"-"+ data_s.substring(4,6) +"-"+ data_s.substring(6,8);
      		}else{
      			return "";  
      		}
      	}else{
        	return "";  
      	} 
      	return data_s;  
  	} 
 
  	public static String format_time(String data_t) 
	{
    	if(data_t != null){
     		if(data_t.length() > 5 ){
     			data_t = data_t.substring(0,2) +":"+ data_t.substring(2,4) +":"+ data_t.substring(4,6);
      		}else{
      			return "";  
      		}
      	}else{
        	return "";  
      	} 
      	return data_t;  
  	} 
	
	public String toInfoString() {
		StringBuffer buf = new StringBuffer();
		String[] fields = getPropertyNames();
		for(int i=0; i<fields.length; i++) {
			try {
				buf.append("<br>\n");
				buf.append(fields[i] + "=" + getValue(fields[i]));
				buf.append("\n<br>\n");
			}catch(Exception e) {	}
		}
		return buf.toString();
	}

	//��ü�� ������ �ִ� ����ʵ� ���� ���
	public String[] getPropertyNames() {
		Field[] fs = getClass().getDeclaredFields();
		String[] names = new String[fs.length];
		for(int i=0; i<fs.length; i++) {
			names[i] = fs[i].getName();	
		}
		return names;
	}

	//��ü�� ������ �ִ� ����ʵ��� �� ���
	public Object getValue(String prop_name) throws Exception {
		Field fd = getClass().getDeclaredField(prop_name);
		try {
			return fd.get(this);
		}catch(Exception e) {
			throw new Exception(e.toString() + "\nprop_name=" + prop_name);
		}
	}

	// 페이지 수 계산
	public static int TotalPage(int max_num,  int list_num ) {
		int page_cnt = 0;
		if(list_num>0) {
			page_cnt=max_num/list_num;
			if((max_num % list_num) > 0) page_cnt=page_cnt+1;
		}
		if(page_cnt==0) page_cnt=1;
  		return page_cnt;
  	}  

	// 3자릿수마다 콤마찍기
	public static String addComma(String value) {
		StringBuffer result= new StringBuffer(15);
		int index = value.indexOf(".");
		if(index<0) index=value.length();
		int cnt = 0;
		for(int i=index-1; i>=0; i--) {
			result.insert(0, value.charAt(i));
			if(i>1 && cnt%3==1) result.insert(0, ",") ;
			cnt++;
		}
		result.append(value.substring(index));
		return result.toString();
	}

	// CLOB 가져오기
	public static String ClobString(Reader str) {
		StringBuffer sb = new StringBuffer();
		int readcnt;
		try {
			Reader rd = str;
			char[] buf = new char[1024];
			while((readcnt=rd.read(buf, 0, 1024)) != -1) sb.append(buf, 0, readcnt);
		} catch(Exception e) {
			
		} finally {
			return sb.toString();
		}
	}		
	
	public static String saveFile(String org_file, String org_file_name, String save_directory) { 
		return CopyFile(org_file, org_file_name, save_directory, true);
	}
	public static String CopyFile(String org_file, String org_file_name, String save_directory, boolean delete) { 
		return CopyFile(org_file, org_file_name, save_directory, "", delete);
	}
	public static String CopyFile(String org_file, String org_file_name, String save_directory, String save_file_name, boolean delete) { 
		InputStream in = null;
		OutputStream out = null;
		File f = null;
		String new_file_name = "";
		
		try {     
			String sFilenameTemp = null ; 		    
			int lm_iIndex = -2;    
			String sFilenameNoExt, sExt;
			
			lm_iIndex = org_file_name.lastIndexOf('.');
			
			if(lm_iIndex > -1)  {
				sFilenameNoExt = org_file_name.substring(0, lm_iIndex ); 
				sExt = org_file_name.substring(lm_iIndex); 
			} else  {
				sFilenameNoExt = org_file_name;
				sExt = "" ;             
			}
			
			int countfilename  = 0;
			if(save_file_name.equals(""))
				sFilenameTemp = org_file_name ;
			else
				sFilenameTemp = save_file_name ;
			boolean bExist = true;
			
			while(bExist) {	
				f = new File(save_directory + File.separator + sFilenameTemp); 
				if (f.exists()) {
					countfilename++;
					sFilenameTemp = sFilenameNoExt + countfilename + sExt;	
				} else { 
					bExist = false;
				}
			}
			
			new_file_name = sFilenameTemp;
			
			f = new File(org_file);
			in = new FileInputStream(f);
			
			File f2 = new File(save_directory + File.separator + new_file_name);
			out = new BufferedOutputStream(new FileOutputStream(f2), 8 * 1024); 
			
			byte b[] = new byte[(int)f.length()];
			int leng = 0;
			
			if(f.exists()) {			 
				while( (leng = in.read(b)) > 0 ) {
				out.write(b,0,leng);
				}	
			}
			out.close();
			in.close();
			if(delete && f.exists()) f.delete();			
			
		} catch(Exception e) {
			System.err.println(e.toString());
		}
		return new_file_name;
	}
	 
	public static boolean deleteFile(String fullname) {
		boolean result = false;
		try {
			File f = new File(fullname);
			result = f.delete();
		} catch(Exception e) {
			//throw new UploadFileException(e.toString());
		}
		return result;
	}
	
	public static String getOriName(String filename) {
		String ori_filename = null;
		try {
			if(filename.length() > 21) {
				ori_filename = filename.substring(21);
			} else {
				ori_filename = filename;	
			}
		} catch(Exception e) {
			//throw new UploadFileException(e.toString());
		}
		return ori_filename;
	}
	
/*
	public static String getSaveFormat() {
		return	getFormatDate("yyyyMMddHHmmssSSS", 0, 0) + (int)(Math.random() * 10) + 
		(int)(Math.random() * 10) + (int)(Math.random() * 10);
	}
	
	public static String getFormatDate(String format, int field, int offset) {
		SimpleTimeZone stz = new SimpleTimeZone(rawOffset, "KST");
		Calendar rightNow = Calendar.getInstance(stz);
		
		if (offset != 0) {
			rightNow.add(field, offset);
		}

		Date rightDate = rightNow.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setTimeZone(stz);
		
		return	sdf.format(rightDate);
	}
*/
	public static boolean isDirectory(String path, String directory_name) {
		boolean flag = false;
		try {
			File f = new File(path);
		 	
		 	if(f != null) {
				String[] directory = f.list();
				 
				for(int i=0; i<directory.length; i++)
				{
					if(directory_name.equals(directory[i]))
					{
						flag = true;
						break;
					} 
				}			
			}
		} catch(Exception e) {
			System.err.println(e.toString());
		}
						
		return flag;
	}
	
	public static boolean mkDir(String path, String directory_name) {
		boolean flag = false;
		
		try {			 
			File f = new File(path + File.separatorChar + directory_name);
		 	
		 	if(!f.exists()) {			 
				flag = f.mkdir();	
			}			
		} catch(Exception e) {
			System.err.println(e.toString());
		}
		
		return flag;
	}
	
	public static boolean deleteDir(String path, String directory_name) { 
 		boolean flag = false; 
		try {     
			File f = new File(path + File.separatorChar + directory_name);
			if(f.exists()) {	
				if(f != null) {
					String[] directory = f.list();
					 
					for(int i=0; i<directory.length; i++) {						 
						 File f2 = new File(path + File.separatorChar + directory_name + File.separatorChar + directory[i]);
						 
						 if(f2.isDirectory()) {
						 	String[] directory2 = f2.list();
						 	
						 	for(int j=0; j<directory2.length; j++) {
							 	File f3 = new File(path + File.separatorChar + directory_name + File.separatorChar + directory[i] + File.separatorChar + directory2[j]);
							 	
							 	if(f3.isDirectory()) {
							    	String[] directory3 = f3.list();
							    	
							    	for(int l=0; l<directory3.length; l++) {
								 		File f4 = new File(path + File.separatorChar + directory_name + File.separatorChar + directory[i] + File.separatorChar + directory2[j] + File.separatorChar + directory3[l]);
								 		f4.delete();						 	
							 		}
							 	}	
							 	f3.delete();	
						 	}						 	
						 }
						 f2.delete();
					}
					flag = f.delete();
				}
			}	
			f.delete();				 
		} catch(Exception e) {
			System.err.println(e.toString());
		}
		return flag;
	}	

	public static boolean Decompress(String strPath, String strRoot) {
		try {
			ZipFile  zf = new ZipFile(strPath);
			Enumeration e = zf.entries();
			
			while(e.hasMoreElements()) {
				ZipEntry ze   =(ZipEntry)e.nextElement();
				String  strEntry =ze.getName();
				int   nStartIndex =0;
				int   nEndIndex =0;
				boolean  bDirectory =false;
				
				while(true) {
					nEndIndex =strEntry.indexOf('/', nStartIndex);
					if(nEndIndex!=-1) {      
						String strDirectory =strEntry.substring(0, nEndIndex);
						File fileDirectory =new File(strRoot+"/"+strDirectory);
						
						if(fileDirectory.exists()==false) {
							fileDirectory.mkdir();
						}
						nStartIndex =nEndIndex+1;
					} else {
						break;
					}
					
					if(nEndIndex+1==strEntry.length()) {
						bDirectory =true;
					}
				}
				
				if(bDirectory==false) {     
					InputStream    is    =zf.getInputStream(zf.getEntry(strEntry));
					ByteArrayOutputStream baos  =new ByteArrayOutputStream();
					byte[]     byteBuffer =new byte[1024];
					byte[]     byteData =null;
					FileOutputStream  fos   =null;
					int      nLength  =0;
					
					while((nLength=is.read(byteBuffer))>0) {
						baos.write(byteBuffer, 0, nLength);
					}
					is.close();
					byteData =baos.toByteArray();
					
					fos =new FileOutputStream(strRoot+"/"+strEntry);
					fos.write(byteData);
					fos.close();
				}
			}
			
			zf.close();
			
			return true;
		} catch(IOException e) {
			e.getStackTrace();
		}
		return false;
	}
	public static String getExtenstion(String filename) {
		String [] exe = filename.split("[.]");
		if(exe != null && exe.length > 1) 
			return exe[exe.length-1];
		else 
			return "";
	}
	public static boolean getDecoderCheck(String filename) {
		SeekableStream 	ss 	   = null;
		File 			file   = null;
		String[]		ext	   = null;
		String[]		images = {"gif","jpe","png","tiff","bmp"};
		boolean 		check  = false;
		try	{
			file = new File(filename);
			ss   = new FileSeekableStream(file);
			ext  = ImageCodec.getDecoderNames(ss);
			
			for(int i=0; i<ext.length; i++) {
				for(int j=0; j<images.length; j++) {
					if(ext[i].indexOf(images[j]) > -1) {
						check = true;
						break;
					}
				}
			}
			 
		} catch(Exception e) {}		
		return check;
	}
	
	public static boolean createImage(String loadFile, String saveFile, int tw, int th, boolean border, String bdColor) {	
		boolean result = false;
		try {
			if(getDecoderCheck(loadFile) == true) {
				File 	    save = new File(saveFile);
				RenderedOp    op = JAI.create("fileload", loadFile);
				BufferedImage im = op.getAsBufferedImage();
				
				if(im.getWidth()  < tw) tw = im.getWidth();
				if(im.getHeight() < th) th = im.getHeight();
				
				BufferedImage thumb = new BufferedImage(tw, th, BufferedImage.TYPE_INT_RGB);
				Graphics2D 	  g2d   = thumb.createGraphics();
							
				g2d.drawImage(im, 0, 0, tw, th, null);
				
				if(border == true) {
					g2d.setColor(Color.decode(bdColor));
					g2d.drawRect(0, 0, --tw, --th);
				}
							
				ImageIO.write(thumb, "png", save);
				result = true;
			}
		} catch(Exception e) {
			//throw new UploadFileException(e.toString());
		}
		return result;
	}
	

}
