package builder.web;

import java.util.*;
import java.util.Date;
import java.io.*;

public class StringEdit1
{
	public static String replace(String strTarget, String strSearch, String strReplace) 
	{
		String strCheck = new String(strTarget);
		StringBuffer strBuf = new StringBuffer();
		while(strCheck.length() != 0) 
		{
			int begin = strCheck.indexOf(strSearch);
			if(begin == -1) 
			{
				strBuf.append(strCheck);
				break;
			} 
			else 
			{
				int end = begin + strSearch.length();
				strBuf.append(strCheck.substring(0, begin));
				strBuf.append(strReplace);
				strCheck = strCheck.substring(end);
			}
		}
		return new String(strBuf);
	}

	public static String insert(String strTarget, int loc, String strInsert)
	{
		StringBuffer strBuf = new StringBuffer();
		int lengthSize = strTarget.length();
		if(loc >= 0)
		{
			if(lengthSize < loc)
			{
				loc = lengthSize;
			}			
			strBuf.append(strTarget.substring(0,loc));
			strBuf.append(strInsert);
			strBuf.append(strTarget.substring(loc+strInsert.length()));
		}
		else
		{
			if(lengthSize < Math.abs(loc))
			{
				loc = lengthSize * (-1);				
			}
			strBuf.append(strTarget.substring(0,(lengthSize - 1) + loc));
			strBuf.append(strInsert);
			strBuf.append(strTarget.substring((lengthSize - 1) + loc + strInsert.length()));
		}
		return new String(strBuf);
	}
	
	public static String delete(String strTarget, String strDelete)
	{
		return replace(strTarget,strDelete,"");
	}

	public static String[] split(String strTarget, String strDelim, boolean bContainNull)
	{
		int index = 0;
		String[] resultStrArray = new String[search(strTarget,strDelim)+1];
		String strCheck = new String(strTarget);
		while(strCheck.length() != 0) 
		{
			int begin = strCheck.indexOf(strDelim);
			if(begin == -1) 
			{
				resultStrArray[index] = strCheck;
				break;
			} 
			else 
			{
				int end = begin + strDelim.length();
				if(bContainNull)
				{
					resultStrArray[index++] = strCheck.substring(0, begin);
				}
				strCheck = strCheck.substring(end);
				if(strCheck.length()==0 && bContainNull)
				{
					resultStrArray[index] = strCheck;
					break;
				}
			}
		}
		return resultStrArray;
	}
	
	public static int search(String strTarget, String strSearch)
	{
		int result=0;
		String strCheck = new String(strTarget);
		for(int i = 0; i < strTarget.length(); )
		{
			int loc = strCheck.indexOf(strSearch);		
			if(loc == -1) 
			{
				break;
			} 
			else 
			{
				result++;
				i = loc + strSearch.length();
				strCheck = strCheck.substring(i);
			}		
		}
		return result;	
	}
     
     public static String stringCheck(String strData) throws Exception
	{
		String method_name = "stringCheck";
		 
	        try { 
	        	
			if(strData == null)
			{
				strData = "";
			}
		} catch(Exception ex)
                {
                       System.out.println(ex.toString());
                }
                
		return strData;
	}
	
	public static String addComma(String value)
	{
		if(value==null || "".equals(value)) 
			return "";
		String str1="",str2="",str3="";
		StringBuffer result= new StringBuffer(15);		
		int ind = value.indexOf('.');
		if( ind == -1){
			str1 = value;
		}else{
			str1 = value.substring(0,ind);
			str2 = value.substring(ind);
		}
		if(str1.charAt(0)=='-') {
			str1 = str1.substring(1);
			str3 = "-";
		}
		for(int i=0; i < str1.length() ; i++){
			result.append(str1.charAt(i));
			if( (str1.length()-i)%3==1 && i!=(str1.length()-1) ) result.append(",") ;
		}
		return str3+result.toString()+str2; 
	}

	public static String addCommaInteger(String value)
	{
		if(value==null || "".equals(value)) 
			return "";
		String str1="",str2="",str3="";
		StringBuffer result= new StringBuffer(15);		
		int ind = value.indexOf('.');
		if( ind == -1){
			str1 = value;
		}else{
			str1 = value.substring(0,ind);
			str2 = value.substring(ind);
		}
		if(str1.charAt(0)=='-') {
			str1 = str1.substring(1);
			str3 = "-";
		}
		for(int i=0; i < str1.length() ; i++){
			result.append(str1.charAt(i));
			if( (str1.length()-i)%3==1 && i!=(str1.length()-1) ) result.append(",") ;
		}
		return str3+result.toString(); 
	}
		
	public static Vector token(String str, String simbol)
	{
		Vector v = new Vector();
		String token = null;
		
		if (str == null)
		{
			return null;
		}
		
		StringTokenizer st = new StringTokenizer(str, simbol, false);
		
		while (st.hasMoreTokens())
		{
			v.addElement(st.nextToken());
		}
		
		return v;
	}
	
	public static String getTitleSubString(String value,int size)
	{
		String str = "";
		int len = value.length();
		
		if(size > len)
		{
			return value;	
		}
		else
		{
			str = value.substring(0,size) + "...";	
		}
		
		return str;	 
	}
	public static String getSubString(String value, int size) {
		String str = "";
		int len = value.length();
		if(size > len) {
			return value;	
		} else {
			str = value.substring(0,size);	
		}
		return str;	 
	}
	
	public static String getJuminToSex(String value)
	{
		String str = "";
		String temp = "";
		
		if(value == null)
		{
			return str;
		}
		
		if(value.length() != 7)
		{
			return str;	
		}	
		
		temp = value.substring(0,1);
		
		if("1".equals(temp))
		{
			str = "����";	
		}
		else
		{
			str = "����";
		}	
		
		return str;	 
	}

	public static String getJuminFirst(String value)
	{
		String jumin_no = "";
		
		if(value == null)
		{
			return jumin_no;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 13)
		{
			return jumin_no;	
		}	
		
		jumin_no = value.substring(0,6);
		
				
		return jumin_no;	 
	}
	
	public static String getJuminSecond(String value)
	{
		String jumin_no = "";
		
		if(value == null)
		{
			return jumin_no;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 13)
		{
			return jumin_no;	
		}	
		
		jumin_no = value.substring(6);
		
				
		return jumin_no;	 
	}
	
	public static String getComRegNo(String value)
	{
		String str = "";
		String reg_no1 = "";
		String reg_no2 = "";
		String reg_no3 = "";
		
		if(value == null)
		{
			return str;
		}
		
		if(value.length() != 10)
		{
			return str;	
		}	
		
		reg_no1 = value.substring(0,3);
		reg_no2 = value.substring(3,5);
		reg_no3 = value.substring(5);
		
		str = reg_no1 + "-" + reg_no2 + "-" + reg_no3;
		
		
		return str;	 
	}
	
	public static String getComRegNoFirst(String value)
	{
		String reg_no = "";
		
		if(value == null)
		{
			return reg_no;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 10)
		{
			return reg_no;	
		}	
		
		reg_no = value.substring(0,3);
		
				
		return reg_no;	 
	}
	
	public static String getComRegNoSecond(String value)
	{
		String reg_no = "";
		
		if(value == null)
		{
			return reg_no;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 10)
		{
			return reg_no;	
		}	
		
		reg_no = value.substring(3,5);
		
				
		return reg_no;	 
	}
	
	public static String getComRegNoThird(String value)
	{
		String reg_no = "";
		
		if(value == null)
		{
			return reg_no;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 10)
		{
			return reg_no;	
		}	
		
		reg_no = value.substring(5);
		
				
		return reg_no;	 
	}
	
	public static String getTelNo(String value)
	{
		String str = "";
		String tel_no1 = "";
		String tel_no2 = "";
		String tel_no3 = "";
		
		if(value == null)
		{
			return str;
		}
		
		if(value.length() < 9)
		{
			return value;	
		}	
		
		if("010".equals(value.substring(0,3)) || "011".equals(value.substring(0,3)) || "016".equals(value.substring(0,3)) || "017".equals(value.substring(0,3)) || "018".equals(value.substring(0,3)) || "019".equals(value.substring(0,3)))
		{
			tel_no1 = value.substring(0,3);
			
			if(value.length() == 10)
			{
				tel_no2 = value.substring(3,6);
				tel_no3 = value.substring(6);
			}
			else
			{
				tel_no2 = value.substring(3,7);
				tel_no3 = value.substring(7);
			}
		}		
		else if("02".equals(value.substring(0,2)))
		{
			if(value.length() == 9)
			{
				tel_no1 = value.substring(0,2);
				tel_no2 = value.substring(2,5);
				tel_no3 = value.substring(5);
			}
			else
			{
				tel_no1 = value.substring(0,2);
				tel_no2 = value.substring(2,6);
				tel_no3 = value.substring(6);
			}
		}
		else
		{
			tel_no1 = value.substring(0,3);
			
			if(value.length() == 10)
			{
				tel_no2 = value.substring(3,6);
				tel_no3 = value.substring(6);
			}
			else
			{
				tel_no2 = value.substring(3,7);
				tel_no3 = value.substring(7);
			}
		}
		
		
		str = tel_no1 + "-" + tel_no2 + "-" + tel_no3;
		
		
		return str;	 
	}
	
	public static String getTelNoFirst(String value)
	{
		String str = "";
		String tel_no = "";
		
		if(value == null)
		{
			return str;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() < 9)
		{
			return "";	
		}	
		
		if("02".equals(value.substring(0,2)))
		{
			tel_no = value.substring(0,2);
		}
		else
		{
			tel_no = value.substring(0,3);
		}
				
		return tel_no;	 
	}
	
	public static String getTelNoSecond(String value)
	{
		String str = "";
		String tel_no = "";
		
		if(value == null)
		{
			return str;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() < 9)
		{
			return "";	
		}
		
		if("010".equals(value.substring(0,3)) || "011".equals(value.substring(0,3)) || "016".equals(value.substring(0,3)) || "017".equals(value.substring(0,3)) || "018".equals(value.substring(0,3)) || "019".equals(value.substring(0,3)))
		{
			
			if(value.length() == 10)
			{
				tel_no = value.substring(3,6);				
			}
			else
			{
				tel_no = value.substring(3,7);				
			}
		}		
		else if("02".equals(value.substring(0,2)))
		{
			if(value.length() == 9)
			{
				tel_no = value.substring(2,5);
				
			}
			else
			{
				tel_no = value.substring(2,6);
			}
		}
		else
		{
			if(value.length() == 10)
			{
				tel_no = value.substring(3,6);
			}
			else
			{
				tel_no = value.substring(3,7);
			}
		}
			
		return tel_no;	 
	}
	
	public static String getTelNoThird(String value)
	{
		String str = "";
		String tel_no = "";
		
		if(value == null)
		{
			return str;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() < 9)
		{
			return "";	
		}
		
		if("010".equals(value.substring(0,3)) || "011".equals(value.substring(0,3)) || "016".equals(value.substring(0,3)) || "017".equals(value.substring(0,3)) || "018".equals(value.substring(0,3)) || "019".equals(value.substring(0,3)))
		{
			
			if(value.length() == 10)
			{
				tel_no = value.substring(6);
			}
			else
			{
				tel_no = value.substring(7);
			}
		}		
		else if("02".equals(value.substring(0,2)))
		{
			if(value.length() == 9)
			{
				tel_no = value.substring(5);
			}
			else
			{
				tel_no = value.substring(6);
			}
		}
		else
		{			
			if(value.length() == 10)
			{
				tel_no = value.substring(6);
			}
			else
			{
				tel_no = value.substring(7);
			}
		}
			
		return tel_no;	 
	}
	
	public static String getZipCodeFirst(String value)
	{
		String zipcode = "";
		
		if(value == null)
		{
			return zipcode;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 6)
		{
			return zipcode;	
		}	
		
		zipcode = value.substring(0,3);
		
				
		return zipcode;	 
	}
	
	public static String getZipCodeSecond(String value)
	{
		String zipcode = "";
		
		if(value == null)
		{
			return zipcode;
		}
		
		value = value.replaceAll("-","");
		
		if(value.length() != 6)
		{
			return zipcode;	
		}	
		
		zipcode = value.substring(3);
		
				
		return zipcode;	 
	} 
	
	public static String ClobString(Reader str)
	{
		StringBuffer sb = null;
		int readcnt;
		
		if(str == null)
		{
		//	return sb.toString();	
			return "";
		}
		
		try
		{
			sb = new StringBuffer();
			
			Reader rd = str;
			char[] buf = new char[1024];

		    	while ((readcnt = rd.read(buf, 0, 1024)) != -1) 
		    	{
		        	// ��Ʈ�����κ��� �о ��Ʈ�� ���ۿ� �ִ´�.
		        	sb.append(buf, 0, readcnt);
		    	}	
		}
		catch(Exception e) 
		{
			//throw new StringUtilException(e.toString());	
		}
		
		
		return sb.toString();
	}	
	
	public static long getFileSize(String file_path, String file_name)
	{
		long file_size = 0;
		
		try
		{
			File f = new File(file_path + System.getProperty("file.separator") + file_name);
			
			if(f.exists())
			{
				file_size = f.length();
			}
		}
		catch(Exception e)
		{
		
		}	
		return file_size;
	}
	
	public static boolean deleteFile(String fullname)
	{
		
		boolean result = false;
		try
		{
			File f = new File(fullname);
			result = f.delete();
		}
		catch(Exception e)
		{
			//throw new StringUtilException(e.toString());	
		}
		return result;
	} 
	
	public static String getDateFormat(String value,String symbol)
	{
		String str = ""; 
		
		if(value == null)
		{
			return str;
		}
		  
		if(value.length() < 8)
		{
			return value;
		}	
		
		str = value.substring(0,4) + symbol + value.substring(4,6) + symbol + value.substring(6);
				
		return str;	 
	}
	
	public static String getChecked(String value, String flag)
	{
		String str = "";
		
		if(value == null || flag == null)
		return "";
		
		if(flag.equals(value))
		{
			str = "checked";
		}		
		return str;			
	} 
	
	public static String getSelected(String value, String flag)
	{
		String str = "";
		
		if(value == null || flag == null)
		return "";
		
		if(flag.equals(value))
		{
			str = "selected";
		}		
		return str;			
	} 
	
	public static String getDateInterval(String start_dt, String end_dt)
	{ 
		String str = "";
		long d1 = 0;
		long d2 = 0;
		long dt = 0;
		long t_1 = 0;
		long t_2 = 0;
		
	 	try
	 	{
	 		 if(start_dt == null || end_dt == null)
	 		 {
	 		 	return str;	
	 		 }
	 		 
	 		 if(start_dt.length() < 14 || end_dt.length() < 14)
	 		 {
	 		 	return str;	
	 		 }
	 		   
	 		 d1 = Date.UTC(Integer.parseInt(start_dt.substring(0,4)),Integer.parseInt(start_dt.substring(4,6)),Integer.parseInt(start_dt.substring(6,8)),Integer.parseInt(start_dt.substring(8,10)),Integer.parseInt(start_dt.substring(10,12)),Integer.parseInt(start_dt.substring(12)));
	 		 d2 = Date.UTC(Integer.parseInt(end_dt.substring(0,4)),Integer.parseInt(end_dt.substring(4,6)),Integer.parseInt(end_dt.substring(6,8)),Integer.parseInt(end_dt.substring(8,10)),Integer.parseInt(end_dt.substring(10,12)),Integer.parseInt(end_dt.substring(12)));
	 		 
	 		 dt = (d2 - d1)/1000;
	 		 
	 		 if(31536000 <= dt)
			 {
			 	t_1 = dt/31536000;
			 	
			 	dt = dt%31536000; 
			 	
			 	str += t_1 + "�� ";	
			 } 	 
			 if(86400 <= dt)
			 {
			 	t_1 = dt/86400;
			 	
			 	dt = dt%86400; 
			 	
			 	str += t_1 + "�� ";	
			 } 	 
			 if(3600 <= dt)
			 {
			 	t_1 = dt/3600;
			 	
			 	dt = dt%3600; 
			 	
			 	str += t_1 + ":";	
			 } 	  	 
			 if(60 <= dt)
			 {
		 		 t_1 = dt/60;	 		 	
		 		 dt = dt%60; 	 		 	
		 		 str += t_1 + "";	
		 	}	 
	 		 
	 		 
		}
		catch(Exception e)
		{
			
		}
		return str;			
	} 
	
	public static int getTimeInterval(String start_dt, String end_dt)
	{ 
		String str = "";
		long d1 = 0;
		long d2 = 0;
		int dt = 0; 
		
	 	try
	 	{
	 		 if(start_dt == null || end_dt == null)
	 		 {
	 		 	return dt;	
	 		 }
	 		 
	 		 if(start_dt.length() < 14 || end_dt.length() < 14)
	 		 {
	 		 	return dt;	
	 		 }
	 		   
	 		 d1 = Date.UTC(Integer.parseInt(start_dt.substring(0,4)),Integer.parseInt(start_dt.substring(4,6)),Integer.parseInt(start_dt.substring(6,8)),Integer.parseInt(start_dt.substring(8,10)),Integer.parseInt(start_dt.substring(10,12)),Integer.parseInt(start_dt.substring(12)));
	 		 d2 = Date.UTC(Integer.parseInt(end_dt.substring(0,4)),Integer.parseInt(end_dt.substring(4,6)),Integer.parseInt(end_dt.substring(6,8)),Integer.parseInt(end_dt.substring(8,10)),Integer.parseInt(end_dt.substring(10,12)),Integer.parseInt(end_dt.substring(12)));
	 		 
	 		 dt = (int)(d2 - d1)/1000;
	 		 
	 		 
		}
		catch(Exception e)
		{
			
		}
		return dt;			
	} 
}