package builder;

import java.sql.Connection;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Logger;
import java.sql.PreparedStatement;

import builder.web.*;

public class Builder {
	public static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";

	public String G_Str_Err = "";
	public String G_Str_Msg = "";
	public final String _blank = " ";
	public final char _quat = '\'';
	public final char _comma = ',';
	
	public String logging = Get_Property("log");
	
	public void Show_Msg(String Msg) throws Exception { if(logging.equals("debug")) System.out.println(Msg); }
	public void Show_Err(String Err) throws Exception { if(logging.equals("debug") || logging.equals("error")) System.out.println(Err); }
	
	public Logger logger = Logger.getLogger(Builder.class.getSimpleName());
	
	public String Get_Property(String pName) {
		String Value = "";
		try {
			Value = SystemProperty.getInstance().getProperty(pName);
			if(Value==null) Value="";
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			return Value;
  		}
	}

 	// Connection Close
	public void Close_Con(Connection con) {
		if(con != null) {
			try {
				con.close();
			} catch(Exception e) {
 				G_Str_Err+="Close_Con:"+e.toString()+"<br/>";
			}			
		}	
	}	

	// RecordSet Close
	public void Close_RS(ResultSet rs) {
		if(rs != null) {
			try {
				rs.close();
			} catch(Exception e) {
 				G_Str_Err+="Close_RS:"+e.toString()+"<br/>";
			}
		}	
	}

	// PreparedStatement Close
	public void Close_PS(PreparedStatement pstmt) {		 
		if(pstmt != null) {
			try	{
				pstmt.close();
			} catch(Exception e) {
 				G_Str_Err+="Close_PS:"+e.toString()+"<br/>";
			}
		}		 
	}
	
	public String moneyToString(int money){
		return NumberFormat.getNumberInstance(Locale.US).format(money);
	}
	public String moneyToString(String money){
		return NumberFormat.getNumberInstance(Locale.US).format(Integer.parseInt(money));
	}
	public String getNow(){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    String stoday = formatter.format(today);
	    return stoday;
	}
}