package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Locale;

import builder.*;
import builder.web.*;
import builder.database.*;
import jiat.model.*;

public class jump extends Builder {
	public static final int NUM_PER_PAGE = 10;
	
	public final String RMS_TABLE;
	private final String _blank = " ";
	private final String PART_TABLE = Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix");
	
	public jump(){
		this.RMS_TABLE = Get_Property("rmsdb.prefix")+"V$RESEARCH_INFO"+Get_Property("rmsdb.suffix");
	}
	public String getRmsName(String rmsCode){
		String				result		=  	"";
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			SQL.append("Select NAME from ").append(this.RMS_TABLE).append(_blank).append("WHERE").append(_blank).append("CODE").append(_blank).append("like '%").append(rmsCode).append("%'");
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			if(rs.next()){
				result = rs.getString(1);
			}
		} catch(Exception e) {
			if(con != null) con.rollback();
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	public int getTableCount(String tableName){
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();

			SQL.append("Select count(1) from ").append(tableName);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
			if(con != null) con.rollback();
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	
	public int getUserCount(){
		final String TABLE_NAME = Get_Property("jumpdb.prefix")+"JA4000_VIEW"+Get_Property("jumpdb.suffix");
		
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select count(USER_IDNT) from ").append(TABLE_NAME);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	public int getRmsSearchCount(String query, int pageNum){
		int			 		result		=	0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT COUNT(1) FROM (SELECT x.*, CEIL(rownum/")
				.append(NUM_PER_PAGE)
				.append(") AS PNUM").append(_blank)
				.append("FROM (SELECT A.CODE, A.NAME FROM").append(_blank)
				.append(RMS_TABLE).append(" A").append(_blank);
			if(query != null && query.length()>0){
				SQL.append("WHERE A.NAME LIKE '%").append(query).append("%'").append(_blank);
			}
			SQL.append("order by A.CODE) x) WHERE PNUM=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pageNum);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				result = rs.getInt(1);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public int getRmsCount(String query){
		int					result		=	0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT COUNT(1) FROM ").append(RMS_TABLE).append(_blank).append("WHERE NAME LIKE '%").append(query).append("%'");
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			if(rs.next()){
				result = rs.getInt(1);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<Rms> getRmsList(String query, int pageNum){
		ArrayList<Rms> 		result		=	null;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT * FROM (SELECT x.*, CEIL(rownum/")
				.append(NUM_PER_PAGE)
				.append(") AS PNUM").append(_blank)
				.append("FROM (SELECT A.CODE, A.NAME, A.CURR_PERIOD FROM").append(_blank)
				.append(RMS_TABLE).append(" A").append(_blank);
			if(query != null && query.length()>0){
				SQL.append("WHERE A.NAME LIKE '%").append(query).append("%'").append(_blank);
			}
			SQL.append("order by A.CODE) x) WHERE PNUM=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pageNum);
			rs = pstmt.executeQuery();
			
			result = new ArrayList<Rms>();
			while(rs.next()){
				Rms rms = new Rms();
				rms.setCode(rs.getString(Rms.CODE_TAG));
				rms.setName(rs.getString(Rms.NAME_TAG));
				rms.setCurPeriod(rs.getString(Rms.CUR_PERIOD));
				result.add(rms);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	public ArrayList<User> getUserList(int from, int to){
		ArrayList<User>	list	=	getUserList();
		ArrayList<User> result 	=	new ArrayList<User>();
		
		for(;from<=to; from++){
			result.add(list.get(from));
		}		
		
		return result;
	}
	private ArrayList<User> getUserList(){
		final String TABLE_NAME = Get_Property("jumpdb.prefix")+"JA4000_VIEW"+Get_Property("jumpdb.suffix");
		ArrayList<User> 	result		=	null;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT USER_IDNT, USER_KNAM, PART_NAME, PART_CODE, USER_HPNO, USER_MAIL FROM ")
				.append(TABLE_NAME).append(" order by USER_IDNT");
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			
			result = new ArrayList<User>();
			while(rs.next()){
				User user = new User();
				user.setUserIdnt(rs.getString(User.USER_IDNT));
				user.setkName(rs.getString(User.USER_KNAM));
				user.setPartName(rs.getString(User.PART_NAME));
				user.setPartCode(rs.getString(User.PART_CODE));
				user.setUserHpno(rs.getString(User.USER_HPNO));
				user.setUserMail(rs.getString(User.USER_MAIL));
				result.add(user);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	// 회원정보 가져오기 
	public ClassParameter getMember(String ID) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, USER_LOID, USER_LOPW, USER_KNAM, PART_CODE, PART_NAME, DUTY_CODE, DUTY_NAME ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA4000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("WHERE RETR_FLAG='N' AND USER_LOID=?");
//			Show_Msg("getMember:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, ID);		
    		rs = pstmt.executeQuery();
			
    		if(rs.next()) {
    			result.setString(User.USER_IDNT,rs.getString(User.USER_IDNT)); //식별번호	
    			result.setString(User.USER_LOID,rs.getString(User.USER_LOID)); //아이디	
    			result.setString(User.USER_LOPW,rs.getString(User.USER_LOPW)); //비밀번호
    			result.setString(User.USER_KNAM,rs.getString(User.USER_KNAM)); //성명
    			result.setString(User.PART_CODE,rs.getString(User.PART_CODE)); //부서코드
    			result.setString(User.PART_NAME,rs.getString(User.PART_NAME)); //부서명
    			result.setString(User.DUTY_CODE,rs.getString(User.DUTY_CODE)); //직책코드
    			result.setString(User.DUTY_NAME,rs.getString(User.DUTY_NAME)); //직책명
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<Part> getChildParts(int curPartCode){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<Part> 	list		=	new ArrayList<Part>();
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT * FROM").append(_blank)
				.append(PART_TABLE).append(_blank)
				.append("WHERE UPPR_PART =").append(curPartCode).append(_blank)
				.append("OR PART_CODE=").append(curPartCode).append(_blank)
				.append("AND USAG_FLAG='N'");
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
    		
    		while(rs.next()) {
    			Part part = new Part();
    			
    			part.setPartCode(rs.getString(Part.P_CODE_TAG)); 	//부서코드
    			part.setPartName(rs.getString(Part.P_NAME_TAG)); 	//부서명
    			part.setUpperPart(rs.getString(Part.UPPR_PART));
    			
    			list.add(part);
    		}
		} catch(Exception e) {
			Show_Err("getUpperPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}
	public ArrayList<Integer> getChildPartCode(int curPartCode){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<Integer> 	result		=	new ArrayList<Integer>();
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT PART_CODE FROM").append(_blank)
				.append(PART_TABLE).append(_blank)
				.append("WHERE UPPR_PART =").append(curPartCode).append(_blank)
				.append("OR PART_CODE=").append(curPartCode).append(_blank)
				.append("AND USAG_FLAG='N'");
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
    		
    		while(rs.next()) {
    			result.add(rs.getInt(1));
    		}
		} catch(Exception e) {
			Show_Err("getUpperPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	private int getUpperPartCode(int curPartCode){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result		=	0;
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT UPPR_PART FROM").append(_blank)
				.append(PART_TABLE).append(_blank)
				.append("WHERE PART_CODE =").append(curPartCode).append(_blank)
				.append("AND USAG_FLAG='N'");
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
    		
    		while(rs.next()) {
    			result = rs.getInt(1);
    		}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	public ArrayList<Integer> getUpperPartList(int currentPartCode){
		ArrayList<Integer>	result		=	new ArrayList<Integer>();
		
		while(currentPartCode > 0){
			if(currentPartCode>99){
				result.add(currentPartCode);
			}
			currentPartCode = getUpperPartCode(currentPartCode);
		}
		return result;
	}
	
	// 부서목록 가져오기 
	public LinkedList getPartList() {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT PART_CODE, PART_NAME, LENGTH(UPPR_PART) AS LEN").append(_blank);
			SQL.append("FROM "+PART_TABLE+" ");
			SQL.append("WHERE USAG_FLAG='N' ORDER BY PART_ORDR");
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter 		result 		= 	new ClassParameter();
    			result.setString("PART_CODE",rs.getString("PART_CODE")); 	//부서코드
    			result.setString("PART_NAME",rs.getString("PART_NAME")); 	//부서명
    			result.setString("LEN",rs.getString("LEN")); 				//부서레벨(2:최상위부서,3:하위부서)
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	public ArrayList<Part> getSiblingParts(int myPartCode){
		Connection			con 		=	null;
		ArrayList<Part> 	list 		= 	new ArrayList<Part>();
		DBConnection 		DBCon 		= 	new DBConnection();
		
		try{
			con = DBCon.getConnection();
			list = getSiblingParts(con, myPartCode);
		} catch(Exception e) {
			Show_Err("getSiblingParts:"+e.toString());
		} finally {
			Close_Con(con);
			return list;
		}
	}
	private ArrayList<Part> getSiblingParts(Connection con, int myPartCode){
		ResultSet 			rs 			= 	null;
		PreparedStatement 	pstmt 		= 	null;
		ArrayList<Part>		list 		= 	new ArrayList<Part>();
		StringBuffer 		SQL 		= 	new StringBuffer();
		final String TABLE_NAME = Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix");
		
		try{
			SQL.append("SELECT *").append(_blank)
			.append("FROM").append(_blank).append(TABLE_NAME).append(_blank)
			.append("WHERE UPPR_PART=").append(_blank)
			.append("(SELECT UPPR_PART FROM").append(_blank)
			.append(TABLE_NAME).append(_blank)
			.append("WHERE PART_CODE =?)").append(_blank)
			.append("AND USAG_FLAG='N' ORDER BY PART_ORDR");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, myPartCode);
    		rs = pstmt.executeQuery();
    		
    		while(rs.next()) {
//    			ClassParameter result =	new ClassParameter();
    			Part part = new Part();
    			
    			part.setPartCode(rs.getString(Part.P_CODE_TAG)); 	//부서코드
    			part.setPartName(rs.getString(Part.P_NAME_TAG)); 	//부서명
    			part.setUpperPart(rs.getString(Part.UPPR_PART));
    			
    			list.add(part);
    		}
		} catch(Exception e) {
			Show_Err("getSiblingParts:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
		}
	}
	// 부서목록 가져오기 하위부서만!
	public LinkedList getPartList2() {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();
		
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT PART_CODE, PART_NAME, LENGTH(UPPR_PART) AS LEN ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("WHERE LENGTH(UPPR_PART)=3 AND USAG_FLAG='N' ORDER BY PART_ORDR");
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result =	new ClassParameter();
    			
    			result.setString("PART_CODE",rs.getString("PART_CODE")); 	//부서코드
    			result.setString("PART_NAME",rs.getString("PART_NAME")); 	//부서명
    			result.setString("LEN",rs.getString("LEN")); 				//부서레벨(2:최상위부서,3:하위부서)
    			
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	// 부서목록 가져오기 상위부서만!
	public LinkedList getPartList3() {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT PART_CODE, PART_NAME, LENGTH(UPPR_PART) AS LEN ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("WHERE LENGTH(UPPR_PART)=2 AND USAG_FLAG='N' ORDER BY PART_ORDR");
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter 		result 		= 	new ClassParameter();
    			result.setString("PART_CODE",rs.getString("PART_CODE")); //부서코드	
    			result.setString("PART_NAME",rs.getString("PART_NAME")); //부서명
    			result.setString("LEN",rs.getString("LEN")); //부서레벨(2:최상위부서,3:하위부서)
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		
	
	// 업체목록 가져오기 
	public LinkedList getCompanyList() {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, COMP_KNAM, PRSN_NAME, COMP_LOCN, COMP_PHON ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix")+" ");
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter 		result 		= 	new ClassParameter();
    			result.setString("USER_IDNT",rs.getString("USER_IDNT")); //업체코드	
    			result.setString("COMP_KNAM",rs.getString("COMP_KNAM")); //업체명
    			result.setString("PRSN_NAME",rs.getString("PRSN_NAME")); //담당자
    			result.setString("COMP_LOCN",rs.getString("COMP_LOCN")); //도내,도외구분
    			result.setString("COMP_PHON",rs.getString("COMP_PHON")); //전화번호
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}
	public HashMap<String, Part> getPartHashMap() {
		Connection				con 		=	null;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		StringBuffer 			SQL 		= 	new StringBuffer();
		HashMap<String, Part> 	result 		= 	new HashMap<String, Part>();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT PART_CODE, PART_NAME, LENGTH(UPPR_PART) AS LEN ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("WHERE USAG_FLAG='N' ORDER BY PART_ORDR");
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
//	    			ClassParameter 		result 		= 	new ClassParameter();
    			Part part = new Part();
    			part.setPartCode(rs.getString(Part.P_CODE_TAG));
    			part.setPartName(rs.getString(Part.P_NAME_TAG));
    			part.setDepth(rs.getString("LEN"));
    			
//	    			result.setString(Part.P_CODE_TAG, rs.getString(Part.P_CODE_TAG)); //부서코드	
//	    			result.setString(Part.P_NAME_TAG, rs.getString(Part.P_NAME_TAG)); //부서명
//	    			result.setString("LEN", rs.getString("LEN")); //부서레벨(2:최상위부서,3:하위부서)
    			result.put(part.getPartCode(), part);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}	
		
}
