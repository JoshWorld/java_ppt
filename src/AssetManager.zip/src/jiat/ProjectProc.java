package jiat;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Logger;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;

import jiat.model.Menu;
import jiat.model.Project;

/**
 * 장비 활용 Database 접근 객체
 * @author leehg
 */
public class ProjectProc  extends Builder {
	static Logger 					logger 					=	Logger.getLogger(ProjectProc.class.getSimpleName());
	public static final int 		ITEM_PER_PAGE 			= 	20;					// 장비활용 리스트 한 페이지당 보여지는 아이템갯수
	private final String 			TABLE_NAME 				= 	"T_PROJECT";		// Database 에서 테이블 명
	private int						currentSearchCount		=	0;
	
	public int getCurrentSearchCount() {
		return currentSearchCount;
	}
	public void setCurrentSearchCount(int currentSearchCount) {
		this.currentSearchCount = currentSearchCount;
	}
	public HashMap<Integer, String> getOptions(final String TABLE){
		HashMap<Integer, String> 	result		=	new HashMap<Integer, String>();
		Connection					con 		=	null;
		PreparedStatement 			pstmt 		= 	null;
		ResultSet 					rs 			= 	null;
		DBConnection 				DBCon 		= 	new DBConnection();
		StringBuffer 				SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select * from ").append(TABLE);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				result.put(rs.getInt(Project.INX_TAG), rs.getString(Project.STATE_TAG));
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	/**
	 * 
	 * @return 현재 활용 갯수
	 */
	public int getProjectCount(){
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select count(INX) from ").append(TABLE_NAME);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
			
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	/**
	 * 프로젝트 정보를 업데이트
	 * 
	 * @param con
	 * @param project
	 * @return 수정 성공 여부
	 */
	private int updateProject(Connection con, Project project){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update ")
			.append(TABLE_NAME)
			.append(" set ").append(Project.NUM_TAG).append("=?,")
			.append(Project.PARTCODE_TAG).append("=?,")
			.append(Project.PDATE_TAG).append("=?,")
			.append(Project.KOLAS_TAG).append("=?,")
			.append(Project.TYPE_TAG).append("=?,")
			.append(Project.KIND_TAG).append("=?,")
			.append(Project.PARTNAME_TAG).append("=?,")
			.append(Project.CONTENT_TAG).append("=?,")
			.append(Project.C_COMPANY_TAG).append("=?,")
			.append(Project.C_NAME_TAG).append("=?,")
			.append(Project.C_PHONE_TAG).append("=?,")
			.append(Project.C_MAIL_TAG).append("=?,")
			.append(Project.SECURE_TAG).append("=?,")
			.append(Project.INSIDE_TAG).append("=?,")
			.append(Project.RMSCODE_TAG).append("=?,")
			.append(Project.RMSNAME_TAG).append("=?,")
			.append(Project.TITLE_TAG).append("=?")
			.append(" where ").append(Project.INX_TAG).append("=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			pstmt.setString(index++, project.getNum());
			pstmt.setString(index++, project.getPartCode());
			pstmt.setString(index++, project.getPdate());
			pstmt.setInt(index++, project.getKolas());
			pstmt.setInt(index++, project.getType());
			pstmt.setInt(index++, project.getKind());
			pstmt.setString(index++, project.getPartName());
			pstmt.setString(index++, project.getContent());
			pstmt.setString(index++, project.getC_company());
			pstmt.setString(index++, project.getC_name());
			pstmt.setString(index++, project.getC_phone());
			pstmt.setString(index++, project.getC_mail());
			pstmt.setInt(index++, project.getSecure());
			pstmt.setInt(index++, project.getInside());
			pstmt.setString(index++, project.getRmsCode());
			pstmt.setString(index++, project.getRmsName());
			pstmt.setString(index++, project.getTitle());
			pstmt.setInt(index++, project.getInx());			
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	/**
	 * 받아온 객체 정보를 Database 에 저장
	 * @param search
	 * @return
	 */
	public int updateProject(ClassParameter search){
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int					result 		= 	0;
		try {
			Project project = Project.parseProject(search);
			con = DBCon.getConnection();
			result = updateProject(con, project);			
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
		}
	}
	/**
	 * 상태를 수정
	 * 
	 * @param state 등록/계약승인요청/계약승인완료/결과보고/계산서발행요청/계산서발행완료
	 * @param pNum 활용넘버
	 * @return 성공여부
	 */
	public int updateProjectState(int state, int pNum){
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int					result 		= 	0;
		try {
			con = DBCon.getConnection();
			result = updateProjectState(con, state, pNum);			
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
		}
	}
	/**
	 * 
	 * @param con
	 * @param state
	 * @param pNum
	 * @return
	 */
	private int updateProjectState(Connection con, int state, int pNum){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update ")
			.append(TABLE_NAME)
			.append(" set ").append(Project.STATE_TAG).append("=?")
			.append(" where ").append(Project.INX_TAG).append("=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			pstmt.setInt(index++, state);
			pstmt.setInt(index++, pNum);			
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	/**
	 * 현재 시퀀스 의 가장 마지막 번호
	 * @return
	 */
	public int getLastSequenceNumber(){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		
		try {
			SQL.append("SELECT T_PROJECT_INX_SEQ.NEXT_VAL from dual");
			con = DBCon.getConnection();
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				result = rs.getInt("LAST_NUMBER");
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	/**
	 * project 를 추가함 
	 * 22개의 항목 insert
	 * 
	 * @param search
	 * @return
	*/
	public int addProject(ClassParameter search){
		Project project = Project.parseProject(search);
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		
		try {
			 SQL.append("Insert into T_PROJECT ")
				.append("(NUM, PART_CODE, PDATE, C_CODE, KOLAS, TYPE, KIND, STATE, SECURE, INSIDE, CONTENT, C_COMPANY, C_NAME, C_PHONE, C_MAIL, PART_NAME, TITLE, RMS_CODE, RMS_NAME, WRITER, WRITE, WRITERID) ")
				.append("VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			con = DBCon.getConnection();
			String cols[] = {"INX"};
			pstmt = con.prepareStatement(SQL.toString(), cols);
			
			int index=1;
			pstmt.setString(index++, project.getNum());
			pstmt.setString(index++, project.getPartCode());
			pstmt.setString(index++, project.getPdate());
			pstmt.setString(index++, project.getcCode());
			pstmt.setInt(index++, project.getKolas());
			pstmt.setInt(index++, project.getType());
			pstmt.setInt(index++, project.getKind());
			pstmt.setInt(index++, project.getState());
			pstmt.setInt(index++, project.getSecure());
			pstmt.setInt(index++, project.getInside());
			pstmt.setString(index++, project.getContent());
			pstmt.setString(index++, project.getC_company());
			pstmt.setString(index++, project.getC_name());
			pstmt.setString(index++, project.getC_phone());
			pstmt.setString(index++, project.getC_mail());
			pstmt.setString(index++, project.getPartName());
			pstmt.setString(index++, project.getTitle());
			pstmt.setString(index++, project.getRmsCode());
			pstmt.setString(index++, project.getRmsName());
			pstmt.setString(index++, project.getWriter());
			pstmt.setString(index++, getNow());
			pstmt.setString(index, project.getWriterId());
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	/**
	 * 장비활용 리스트 에서 검색 결과를 받아온다.
	 * @param param
	 * @return
	 */
	public int searchProject(ClassParameter param){
		Menu menu = new Menu();
		
		int searchType 	= param.getInt(Menu.SEARCH_TYPE);
		int partType 	= param.getInt(Menu.PART_TYPE);
		int yearType 	= param.getInt(Menu.YEAR_TYPE);
		int stateType	= param.getInt(Menu.STATE_TYPE);
		
		String query = param.getString(Menu.QUERY);
		menu.setSearchType(searchType);
		menu.setPartType(partType);
		menu.setYearType(yearType);
		menu.setStateType(stateType);
		
		try {
			menu.setQuery(URLDecoder.decode(query, "UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		int					result 	=	0;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = searchProject(con, menu);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	/**
	 * 장비활용 리스트 에서 검색 결과를 받아온다.
	 * 단, 페이지 별로 받아온다.
	 * @param param
	 * @param pageNum
	 * @return
	 */
	public ArrayList<Project> searchProject(ClassParameter param, int pageNum){
		int stateType = param.getInt(Menu.STATE_TYPE);		//	상태
		int searchType = param.getInt(Menu.SEARCH_TYPE);	//	업체명 or 제목 or 접수번호
		int partType = param.getInt(Menu.PART_TYPE);		//	선택한 부서
		int yearType = param.getInt(Menu.YEAR_TYPE);		//	선택한 연도
		String query = param.getString(Menu.QUERY);			//	키보드로 입력한 검색어

		Menu menu = new Menu();
		menu.setSearchType(searchType);
		menu.setPartType(partType);
		menu.setYearType(yearType);
		menu.setStateType(stateType);
		try {
			// 검색어 디코딩 (한글로 입력 할 경우가 많기 때문에 특별히 인코딩 한다.)
			menu.setQuery(URLDecoder.decode(query, "UTF-8"));
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		ArrayList<Project> result 		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = searchProject(con, menu, pageNum);
			
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int countSearchResult(Connection con, String query){
		PreparedStatement 	pstmt 			= 	null;
		ResultSet 			rs 				= 	null;
		int					result			=	0;
		try{
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if(rs.next())result = rs.getInt(1);
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	/**
	 * 
	 * @param con
	 * @param menu -> 검색 옵션 (연도별/부서별/상태별/제목별..)
	 * @param pageNum
	 * @return
	 */
	private ArrayList<Project> searchProject(Connection	con, Menu menu, int pageNum){
		PreparedStatement 	pstmt 			= 	null;
		ResultSet 			rs 				= 	null;
		StringBuffer 		SQL 			= 	new StringBuffer();
		ArrayList<Project>	result			=	new ArrayList<Project>();
		StringBuffer		innerSql		=	new StringBuffer();
		StringBuffer		countSql		=	new StringBuffer();
		StringBuffer		getAllSql		=	new StringBuffer();
		try{
			result=	new ArrayList<Project>();
			
			SQL.setLength(0);
			SQL.append("SELECT * FROM( SELECT x.*, CEIL(rownum/?) AS PNUM FROM(");
			
			countSql.append("SELECT count(*)").append(_blank);
			getAllSql.append("SELECT *").append(_blank);
			
			innerSql.append("FROM T_PROJECT where NVL(STATE,'0')<>'9'");
			if(menu.getSearchType() > 0){
				String where = getWhereClause(con, menu.getSearchType(), 2, menu.getQuery());
				innerSql.append("AND").append(_blank).append(where);
			}
			if(menu.getYearType() > 0){
				String where = getWhereClause(con, menu.getYearType(), 0, null);
				innerSql.append("AND").append(_blank);
				innerSql.append(where);
			}
			if(menu.getStateType() >= 0){
				innerSql.append("AND").append(_blank);
				innerSql.append("STATE = ").append(menu.getStateType()).append(_blank);
			}
			jump Jump = new jump();
			if(menu.getPartType() > 0){
				boolean hasPrePartCode = false;
				ArrayList<Integer> parts = Jump.getChildPartCode(menu.getPartType());
				
				Iterator<Integer> iter = parts.iterator();
				while(iter.hasNext()){
					int currentPartCode = iter.next();
					if(hasPrePartCode){
						innerSql.append("OR").append(_blank);
					}else{
						innerSql.append("AND").append(_blank).append("(");
					}
					innerSql.append(Project.PARTCODE_TAG).append(_blank)
					.append("=").append(currentPartCode).append(_blank);
					hasPrePartCode = true;
				}
				innerSql.append(")");
			}
			innerSql.append(" order by NUM DESC").append(_blank);
			
			countSql.append(innerSql);
			getAllSql.append(innerSql);
			
			SQL.append(getAllSql);
			SQL.append(")x) WHERE PNUM=?");
			
			setCurrentSearchCount(countSearchResult(con, countSql.toString()));
			
			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, ITEM_PER_PAGE);
			pstmt.setInt(index, pageNum);
			rs = pstmt.executeQuery();
			while(rs.next()){
				Project project = new Project();
				project.setInx(rs.getInt(Project.INX_TAG));
				project.setNum(rs.getString(Project.NUM_TAG));
				project.setPartCode(rs.getString(Project.PARTCODE_TAG));
				project.setPdate(rs.getString(Project.PDATE_TAG));
				project.setKolas(rs.getInt(Project.KOLAS_TAG));
				project.setType(rs.getInt(Project.TYPE_TAG));
				project.setKind(rs.getInt(Project.KIND_TAG));
				project.setState(rs.getInt(Project.STATE_TAG));
				project.setSecure(rs.getInt(Project.SECURE_TAG));
				project.setContent(rs.getString(Project.CONTENT_TAG));
				project.setC_company(rs.getString(Project.C_COMPANY_TAG));
				project.setC_name(rs.getString(Project.C_NAME_TAG));
				project.setC_phone(rs.getString(Project.C_PHONE_TAG));
				project.setC_mail(rs.getString(Project.C_MAIL_TAG));
				project.setTitle(rs.getString(Project.TITLE_TAG));
				project.setRmsCode(rs.getString(Project.RMSCODE_TAG));
				project.setRmsName(rs.getString(Project.RMSNAME_TAG));
				result.add(project);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	/**
	 * 
	 * @param con
	 * @param menu -> 검색 옵션 (연도별/부서별/상태별/제목별..)
	 * @return
	 */
	private int searchProject(Connection con, Menu menu){
		PreparedStatement 	pstmt 			= 	null;
		ResultSet 			rs 				= 	null;
		StringBuffer 		SQL 			= 	new StringBuffer();
		int					result			=	0;
		try{
			SQL.setLength(0);
			SQL.append("SELECT COUNT(1) FROM T_PROJECT where NVL(STATE,'0')<>'9'").append(_blank);
			if(menu.getSearchType() > 0){
				String where = getWhereClause(con, menu.getSearchType(), 2, menu.getQuery());
				SQL.append("AND").append(_blank).append(where).append(_blank);
			}
			if(menu.getYearType() > 0){
				String where = getWhereClause(con, menu.getYearType(), 0, null);
				SQL.append("AND").append(_blank);
				SQL.append(where).append(_blank);
			}
			if(menu.getStateType() >= 0){
				SQL.append("AND").append(_blank);
				SQL.append("STATE = ").append(menu.getStateType()).append(_blank);
			}
			jump Jump = new jump();
			if(menu.getPartType() > 0){
				boolean hasPrePartCode = false;
				ArrayList<Integer> parts = Jump.getChildPartCode(menu.getPartType());
				
				Iterator<Integer> iter = parts.iterator();
				while(iter.hasNext()){
					int currentPartCode = iter.next();
					if(hasPrePartCode){
						SQL.append("OR").append(_blank);
					}else{ 
						SQL.append("AND").append(_blank).append("(");
					}
					SQL.append(Project.PARTCODE_TAG).append(_blank)
					.append("=").append(currentPartCode).append(_blank);
					hasPrePartCode = true;
				}
				SQL.append(")");
			}
			
//			logger.info(SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				result = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	/**
	 * 검색 옵션 (연도별/부서별/상태별/제목별..) 을 value 와 type 으로 구분하여
	 * 쿼리를 만들어 낸다.
	 * 
	 * @param con
	 * @param value
	 * @param type
	 * @param query
	 * @return
	 */
	private String getWhereClause(Connection con, int value, int type, String query){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		String				result		=	null;
		StringBuffer 		whereQuery	=	new StringBuffer();
		String				name		=	null;
		try{
			SQL.append("SELECT * FROM OPTION_SELECT WHERE TYPE = ? AND VALUE=?");
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, type);
			pstmt.setInt(2, value);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				result	= rs.getString("TABLE_WHERE");
				name	= rs.getString("NAME");
			}
			
			if(type == 0)whereQuery.append(result).append(_blank).append("like '%").append(name).append("%'");
			else if(type == 2)whereQuery.append(result).append(_blank).append("like '%").append(query).append("%'");
			
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return whereQuery.toString();
  		}
	}
	/**
	 * 장비 활용 리스트 받아오기
	 * 인덱스 from -> to
	 * 
	 * @param from 
	 * @param to
	 * @return
	 */
	public ArrayList<Project> getProjects(int from, int to){
		ArrayList<Project>	list	=	getProjects();
		ArrayList<Project> result 	=	new ArrayList<Project>();
		
		for(;from<=to; from++){
			result.add(list.get(from));
		}		
		
		return result;
	}
	/**
	 * 모든 장비활용 결과 가져오기
	 */
	public ArrayList<Project> getProjects(){
		ArrayList<Project>	list	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getProjects(con);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	/**
	 * 모든 장비활용 결과 가져오기
	 * @param con
	 * @return
	 */
	private ArrayList<Project> getProjects(Connection con){
		ArrayList<Project>	list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_PROJECT ORDER BY INX DESC");
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			list = new ArrayList<Project>();
			
			while(rs.next()){
				Project  project = new Project();
				project.setInx(rs.getInt(Project.INX_TAG));
				project.setNum(rs.getString(Project.NUM_TAG));
				project.setPartCode(rs.getString(Project.PARTCODE_TAG));
				project.setPdate(rs.getString(Project.PDATE_TAG));
				project.setKolas(rs.getInt(Project.KOLAS_TAG));
				project.setType(rs.getInt(Project.TYPE_TAG));
				project.setKind(rs.getInt(Project.KIND_TAG));
				project.setState(rs.getInt(Project.STATE_TAG));
				project.setContent(rs.getString(Project.CONTENT_TAG));
				project.setC_company(rs.getString(Project.C_COMPANY_TAG));
				project.setC_name(rs.getString(Project.C_NAME_TAG));
				project.setC_phone(rs.getString(Project.C_PHONE_TAG));
				project.setC_mail(rs.getString(Project.C_MAIL_TAG));
				project.setTitle(rs.getString(Project.TITLE_TAG));
				project.setRmsCode(rs.getString(Project.RMSCODE_TAG));
				project.setRmsName(rs.getString(Project.RMSNAME_TAG));
				project.setPartName(rs.getString(Project.PARTNAME_TAG));
				
				list.add(project);
			}
		}catch(Exception e) {
			Show_Err("02: "+e.toString());
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
			
	}
	/**
	 * 모든 장비활용 결과 가져오기
	 * @param con
	 * @return
	 */
	public ArrayList<Project> getProjectsAllList(){
		ArrayList<Project>	list	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getProjectsAllList(con);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	/**
	 * 모든 장비활용 결과 가져오기
	 * @param con
	 * @return
	 */
	private ArrayList<Project> getProjectsAllList(Connection con){
		ArrayList<Project>	list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT INX,NUM,TITLE,PART_CODE,STATE,C_COMPANY,C_NAME,INSIDE FROM T_PROJECT ORDER BY INX DESC");
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			list = new ArrayList<Project>();
			
			while(rs.next()){
				Project  project = new Project();
				project.setInx(rs.getInt(Project.INX_TAG));
				project.setNum(rs.getString(Project.NUM_TAG));
				project.setPartCode(rs.getString(Project.PARTCODE_TAG));
				project.setInside(Integer.parseInt(rs.getString(Project.INSIDE_TAG)));
				project.setState(rs.getInt(Project.STATE_TAG));
				project.setC_company(rs.getString(Project.C_COMPANY_TAG));
				project.setC_name(rs.getString(Project.C_NAME_TAG));
				project.setTitle(rs.getString(Project.TITLE_TAG));
				
				list.add(project);
			}
		}catch(Exception e) {
			Show_Err("02: "+e.toString());
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	/**
	 * num 값을 이용한 특정 장비활용(Project) 가져오기
	 * @param num
	 * @return
	 */
	public Project getProject (int num){
		Project result = null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getProject(con, num);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	/**
	 * num 값을 이용한 특정 장비활용(Project) 가져오기
	 * @param con
	 * @param num
	 * @return
	 */
	private Project getProject(Connection con, int num){
		Project result = new Project();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		try{
			SQL.append("SELECT * FROM T_PROJECT WHERE INX =").append(num);
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				result.setInx(rs.getInt(Project.INX_TAG));
				result.setNum(rs.getString(Project.NUM_TAG));
				result.setPartCode(rs.getString(Project.PARTCODE_TAG));
				result.setPdate(rs.getString(Project.PDATE_TAG));
				result.setKolas(rs.getInt(Project.KOLAS_TAG));
				result.setType(rs.getInt(Project.TYPE_TAG));
				result.setKind(rs.getInt(Project.KIND_TAG));
				result.setState(rs.getInt(Project.STATE_TAG));
				result.setContent(rs.getString(Project.CONTENT_TAG));
				result.setC_company(rs.getString(Project.C_COMPANY_TAG));
				result.setC_name(rs.getString(Project.C_NAME_TAG));
				result.setC_phone(rs.getString(Project.C_PHONE_TAG));
				result.setC_mail(rs.getString(Project.C_MAIL_TAG));
				result.setSecure(rs.getInt(Project.SECURE_TAG));
				result.setWriter(rs.getString(Project.WRITER_TAG));
				result.setWriterId(rs.getString(Project.WRITERID_TAG));
				result.setWrite(rs.getString(Project.WRITE_TAG));
				result.setInside(rs.getInt(Project.INSIDE_TAG));
				result.setPartName(rs.getString(Project.PARTNAME_TAG));
				result.setRmsCode(rs.getString(Project.RMSCODE_TAG));
				result.setRmsName(rs.getString(Project.RMSNAME_TAG));
				result.setcCode(rs.getString(Project.C_CODE_TAG));
				result.setTitle(rs.getString(Project.TITLE_TAG));
			}
		}catch(Exception e) {
			Show_Err("02: "+e.toString());
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	/**
	 * 글을 열람 가능한 사람인지 판별한다.
	 * 
	 * @param project
	 * @param myUserIdnt
	 * @param childPartList
	 * @param leaderList
	 * @return
	 */
	public boolean hasPermissionView(Project project, String myUserIdnt, ArrayList<Integer> childPartList, ArrayList<String> leaderList){
		// 1. secure 모드 인지 확인 하자
		// 2. 글쓴이 인지 확인하자.
		// 3. 부서 사람인지 아닌지 확인 하자.
		// 4. 부서 장인지 확인 하자.
		// 5. 
		if(project.getSecure() == 0){
			// 1. secure 모드 아님
			if(myUserIdnt!=null && myUserIdnt.equalsIgnoreCase(project.getWriterId())){
				// 2. 글쓴이
				return true;
			}else if(childPartList!=null && childPartList.contains(Integer.parseInt(project.getPartCode()))){
				// 3. 부서 사람
				return true;
			}else if(leaderList!=null && leaderList.contains(myUserIdnt)){
				// 4. 부서 장
				return true;
			}
		}else{
			// 1. secure 모드
			if(myUserIdnt!=null && myUserIdnt.equalsIgnoreCase(project.getWriterId())){
				// 2. 글쓴이
				return true;
			}else if(leaderList!=null && leaderList.contains(myUserIdnt)){
				// 4. 부서장
				return true;
			}else if(childPartList!=null && childPartList.contains(Integer.parseInt(project.getPartCode()))){
				// 3. 부서 사람
				return true;
			}
		}
		return false;
	}
	/**
	 * 글을 수정 가능한 사람인지 판별한다.
	 * 
	 * @param project
	 * @param myUserIdnt
	 * @param childPartList
	 * @param leaderList
	 * @return
	 */
	public boolean hasPermissionView(Project project, String myUserIdnt, ArrayList<Integer> childPartList, ArrayList<String> leaderList, int authPartCode){
		// 1. 글쓴이 인지 확인하자.
		// 2. 부서 사람인지 아닌지 확인 하자.
		// 3. 부서 장인지 확인 하자.
		// 4. 부서 권한 위임 받았는지 확인하자.
		
		if(myUserIdnt!=null && myUserIdnt.equalsIgnoreCase(project.getWriterId())){
			// 1. 글쓴이
			return true;
		}else if(childPartList!=null && childPartList.contains(Integer.parseInt(project.getPartCode()))){
			// 2. 부서 사람
			return true;
		}else if(leaderList!=null && leaderList.contains(myUserIdnt)){
			// 3. 부서 장
			return true;
		}else if(authPartCode > 0){
			// 4. 부서 권한 위임 받았는지 확인하자.
			ArrayList<Integer> childrenParts = new jump().getChildPartCode(authPartCode);
			int projectPartCode = (project.getPartCode()!=null)?Integer.parseInt(project.getPartCode()):0;
			if(childrenParts.contains(projectPartCode)){
				return true;
			}
		}
		return false;
	}
	/**
	 * 
	 * @param project
	 * @param myUserIdnt
	 * @param childPartList
	 * @param currentAuthPart
	 * @return
	 */
	public boolean hasReadPermission(Project project, String myUserIdnt, ArrayList<Integer> childPartList, int currentAuthPart){
		// 1. secure 모드 인지 확인 하자
		// 2. 글쓴이 인지 확인하자.
		// 3. 부서 사람인지 아닌지 확인 하자.
		// 4. Auth Part 를 지정 했는지 확인 하자.
		
		if(project.getSecure() == 0){
			return true;
		}else if(myUserIdnt!=null && myUserIdnt.equalsIgnoreCase(project.getWriterId())){
			return true;
		}else if(childPartList !=null && project.getPartCode()!=null && childPartList.contains(Integer.parseInt(project.getPartCode()))){
			return true;
		}else if(currentAuthPart > 0){
			ArrayList<Integer> childrenParts = new jump().getChildPartCode(currentAuthPart);
			int projectPartCode = (project.getPartCode()!=null)?Integer.parseInt(project.getPartCode()):0;
			if(childrenParts.contains(projectPartCode)){
				return true;
			}else{
				return false;
			}
			
		}else{
			return false;
		}
	}
}
