package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import builder.*;
import builder.web.*;
import builder.database.*;

public class statistics extends Builder {

	public LinkedList Get_1(ClassParameter search) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append(" 	SELECT V1.*, V2.*, COUNT(1) OVER(PARTITION BY V1.UPPR_PART) AS CNT FROM (	 ");
			SQL.append(" 	SELECT X.*, JP1.PART_NAME AS UPPR_NAME, JP2.PART_NAME FROM (	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" 	 ");
			SQL.append(" 	WHERE UPPR_PART IS NOT NULL AND LENGTH(UPPR_PART)=3 ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	ORDER BY UPPR_PART, PART_CODE) X, 	 ");
			SQL.append(" 	"+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP1, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP2 	 ");
			SQL.append(" 	WHERE X.UPPR_PART=JP1.PART_CODE(+) AND X.PART_CODE=JP2.PART_CODE(+)	 ");
			SQL.append(" 	) V1, 	 ");
			SQL.append(" 	(	 ");
			SQL.append(" 	SELECT * FROM ( 	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE, COUNT(1) AS CNT1, NVL(SUM(MONEY),0) AS MONEY1, 	 ");
			for(int i=0;i<=6;i++) {
				SQL.append(" 	NVL(SUM(C_"+i+"),0) AS C1_"+i+", NVL(SUM(M_"+i+"),0) AS M1_"+i+", 	 ");
			}
			SQL.append(" 	NVL(SUM(C_9),0) AS C1_9, NVL(SUM(M_9),0) AS M1_9 	 ");
			SQL.append(" 	FROM ( 	 ");
			SQL.append(" 	SELECT JP.UPPR_PART, JP.PART_CODE, MONEY, 	 ");
			for(int i=0;i<=6;i++) {
				SQL.append(" 	  CASE WHEN TYPE = '"+i+"' THEN 1 END AS C_"+i+",   	 ");
				SQL.append(" 	  CASE WHEN TYPE = '"+i+"' THEN MONEY END AS M_"+i+",   	 ");
			}
			SQL.append(" 	  CASE WHEN INSIDE = '0' THEN 1 END AS C_9,   	 ");
			SQL.append(" 	  CASE WHEN INSIDE = '0' THEN MONEY END AS M_9  	 ");
			SQL.append(" 	FROM T_CONTRACT C, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP 	 ");
			SQL.append(" 	WHERE C.P_NUM=P.INX AND P.STATE<>'9' AND C.STATE<>'9' AND P.PART_CODE=JP.PART_CODE ");
			if(!search.getString("search_year").equals("")) SQL.append(" AND TO_CHAR(TO_DATE(C.CDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	) X, 	 ");
			SQL.append(" 	( 	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART2, NVL(PART_CODE,0) AS PART_CODE2, COUNT(1) AS CNT2, NVL(SUM(MONEY),0) AS MONEY2, 	 ");
			for(int i=0;i<=6;i++) {
				SQL.append(" 	NVL(SUM(C_"+i+"),0) AS C2_"+i+", NVL(SUM(M_"+i+"),0) AS M2_"+i+", 	 ");
			}
			SQL.append(" 	NVL(SUM(C_9),0) AS C2_9, NVL(SUM(M_9),0) AS M2_9 	 ");
			SQL.append(" 	FROM ( 	 ");
			SQL.append(" 	SELECT JP.UPPR_PART, JP.PART_CODE , PMONEY AS MONEY, 	 ");
			for(int i=0;i<=6;i++) {
				SQL.append(" 	  CASE WHEN TYPE = '"+i+"' THEN 1 END AS C_"+i+",   	 ");
				SQL.append(" 	  CASE WHEN TYPE = '"+i+"' THEN PMONEY END AS M_"+i+",   	 ");
			}
			SQL.append(" 	  CASE WHEN INSIDE = '0' THEN 1 END AS C_9,   	 ");
			SQL.append(" 	  CASE WHEN INSIDE = '0' THEN PMONEY END AS M_9   	 ");
			SQL.append(" 	FROM T_TAX T, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP  	 ");
			SQL.append(" 	WHERE T.P_NUM=P.INX AND P.STATE<>'9' AND T.STATE<>'9' AND P.PART_CODE=JP.PART_CODE ");
			if(!search.getString("search_year").equals("")) SQL.append(" AND TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE)	 ");
			SQL.append(" 	) Y WHERE X.UPPR_PART=Y.UPPR_PART2(+) AND X.PART_CODE=Y.PART_CODE2(+) 	 ");
			SQL.append(" 	ORDER BY X.UPPR_PART ASC, X.PART_CODE ASC	 ");
			SQL.append(" 	) V2 	 ");
			SQL.append(" 	WHERE V1.UPPR_PART=V2.UPPR_PART(+) AND V1.PART_CODE=V2.PART_CODE(+)	 ");
			SQL.append(" 	ORDER BY TO_NUMBER(V1.UPPR_PART) ASC, TO_NUMBER(V1.PART_CODE) ASC	 ");

			
			//Show_Msg("Get_1:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("UPPR_PART", rs.getString("UPPR_PART"));
    			result.setString("UPPR_NAME", rs.getString("UPPR_NAME"));
    			result.setString("PART_CODE", rs.getString("PART_CODE"));
    			result.setString("PART_NAME", rs.getString("PART_NAME"));
				result.setInt("CNT", rs.getInt("CNT"));
				result.setInt("CNT1", rs.getInt("CNT1"));
				result.setLong("MONEY1", rs.getLong("MONEY1"));
				result.setInt("CNT2", rs.getInt("CNT2"));
				result.setLong("MONEY2", rs.getLong("MONEY2"));
    			for(int i=0;i<=6;i++) {
    				result.setInt("C1_"+i, rs.getInt("C1_"+i));
    				result.setLong("M1_"+i, rs.getLong("M1_"+i));
    				result.setInt("C2_"+i, rs.getInt("C2_"+i));
    				result.setLong("M2_"+i, rs.getLong("M2_"+i));
    			}
				result.setInt("C1_9", rs.getInt("C1_9"));
				result.setLong("M1_9", rs.getLong("M1_9"));
				result.setInt("C2_9", rs.getInt("C2_9"));
				result.setLong("M2_9", rs.getLong("M2_9"));
    			list.add(result);	
			}
		} catch(Exception e) {
			Show_Err("Get_1:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	public LinkedList Get_2_(ClassParameter search) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL1 		= 	new StringBuffer();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL1.append(" 	SELECT T1.*,	 ");
			SQL1.append(" 	CASE WHEN NVL(OPTIME,"+search.getInt("OPTIME_DEFAULT")+") = -1 THEN "+search.getInt("OPTIME_DEFAULT")+" ELSE NVL(OPTIME,"+search.getInt("OPTIME_DEFAULT")+") END  AS OPTIME ");
			SQL1.append(" 	FROM ( 	 ");
			SQL1.append(" 	SELECT JASN_NUMB, JASN_NAME, NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE, NVL(SUM(HOUR),0) AS MONEY1,	 ");
			for(int i=1;i<=12;i++) {
				SQL1.append(" 	NVL(SUM(M_"+i+"),0) AS M1_"+i+" 	 ");
				if(i<12) SQL1.append(",");
			}
			SQL1.append(" 	FROM ( 	 ");
			SQL1.append(" 	SELECT JA.JASN_NUMB, JA.JASN_NAME, JP.UPPR_PART, JP.PART_CODE, (UHOUR+EHOUR) AS HOUR, ");
			for(int i=1;i<=12;i++) {
				SQL1.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(SDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN (UHOUR+EHOUR) END AS M_"+i+"   	 ");
				if(i<12) SQL1.append(",");
			}
			SQL1.append(" 	FROM T_RESULT R, T_RESULT_DETAIL RD, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP, "+Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" JA  	 ");
			SQL1.append(" 	WHERE RD.R_NUM=R.INX AND R.P_NUM=P.INX AND P.STATE<>'9' AND P.PART_CODE=JP.PART_CODE AND RD.A_NUM=JA.JASN_NUMB ");
			if(!search.getString("search_year").equals("")) SQL1.append(" AND TO_CHAR(TO_DATE(R.SDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL1.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL1.append(" 	) GROUP BY UPPR_PART, PART_CODE,JASN_NUMB, JASN_NAME	 ");
			SQL1.append(" 	) T1, T_OPTIME O WHERE T1.JASN_NUMB=O.A_CODE(+)	 ");
			//System.out.print("\n\n\n"+SQL1+"\n\n\n");
			SQL.append(" 	SELECT V1.*, V2.*, COUNT(1) OVER(PARTITION BY V1.UPPR_PART) AS CNT1, COUNT(1) OVER(PARTITION BY V1.PART_CODE) AS CNT2 FROM (	 ");
			SQL.append(" 	SELECT X.*, JP1.PART_NAME AS UPPR_NAME, JP2.PART_NAME FROM (	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" 	 ");
			SQL.append(" 	WHERE UPPR_PART IS NOT NULL AND LENGTH(UPPR_PART)=3 	 ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	ORDER BY UPPR_PART, PART_CODE) X, 	 ");
			SQL.append(" 	"+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP1, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP2 	 ");
			SQL.append(" 	WHERE X.UPPR_PART=JP1.PART_CODE(+) AND X.PART_CODE=JP2.PART_CODE(+)	 ");
			SQL.append(" 	) V1, 	 ");
			SQL.append(" 	( 	 ");
			SQL.append(SQL1.toString());
			SQL.append(" 	UNION ALL	 ");
			SQL.append(" 	SELECT '0' AS JASN_NUMB, '0' AS JASN_NAME, NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE, NVL(SUM(MONEY1),0) AS MONEY1, ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	NVL(SUM(M1_"+i+"),0) AS M1_"+i+", 	 ");
			}
			SQL.append(" 	NVL(SUM(OPTIME),0) AS OPTIME  	 ");
			SQL.append(" 	FROM ( 	 ");
			SQL.append(SQL1.toString());
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE)	 ");
//			SQL.append(" 	ORDER BY UPPR_PART ASC, PART_CODE ASC	 ");
			SQL.append(" 	) V2 	 ");
			SQL.append(" 	WHERE V1.UPPR_PART=V2.UPPR_PART(+) AND V1.PART_CODE=V2.PART_CODE(+)	 ");
			SQL.append(" 	ORDER BY TO_NUMBER(V1.UPPR_PART) ASC, TO_NUMBER(V1.PART_CODE) ASC, NVL(JASN_NUMB,0) ASC	 ");

			Show_Msg("Get_2:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("UPPR_PART", rs.getString("UPPR_PART"));
    			result.setString("UPPR_NAME", rs.getString("UPPR_NAME"));
    			result.setString("PART_CODE", rs.getString("PART_CODE"));
    			result.setString("PART_NAME", rs.getString("PART_NAME"));
    			result.setString("JASN_NUMB", rs.getString("JASN_NUMB"));
    			result.setString("JASN_NAME", rs.getString("JASN_NAME"));
    			result.setString("CNT1", rs.getString("CNT1"));
    			result.setString("CNT2", rs.getString("CNT2"));
    			result.setLong("MONEY1", rs.getLong("MONEY1"));
    			result.setString("OPTIME", rs.getString("OPTIME"));
    			for(int i=1;i<=12;i++) {
    				result.setLong("M1_"+i, rs.getLong("M1_"+i));
    			}
    			list.add(result);	
			}
		} catch(Exception e) {
			Show_Err("Get_2:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		
	public LinkedList Get_2(ClassParameter search) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL1 		= 	new StringBuffer();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();
			
			SQL1.append(" 	SELECT JA.JASN_NUMB, JA.JASN_NAME,JP.UPPR_PART, JA.PART_CODE, T1.*, ");
			SQL1.append(" 	CASE WHEN NVL(OPTIME,"+search.getInt("OPTIME_DEFAULT")+") = -1 THEN "+search.getInt("OPTIME_DEFAULT")+" ELSE NVL(OPTIME,"+search.getInt("OPTIME_DEFAULT")+") END  AS OPTIME ");
			SQL1.append(" 	FROM  ");
			//SQL1.append(" 	"+Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL1.append(" ( SELECT * FROM "+Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix") + " WHERE JASN_NUMB IN (SELECT A_NUM FROM T_MA_ASSET)	) ");
			SQL1.append(" JA, (");
			SQL1.append(" 	SELECT A_NUM, NVL(SUM(HOUR),0) AS MONEY1,	 ");
			for(int i=1;i<=12;i++) {
				SQL1.append(" 	NVL(SUM(M_"+i+"),0) AS M1_"+i+" 	 ");
				if(i<12) SQL1.append(",");
			}
			SQL1.append(" 	FROM ( 	 ");
			SQL1.append(" 	SELECT A_NUM, (UHOUR+EHOUR) AS HOUR, ");
			for(int i=1;i<=12;i++) {
				SQL1.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(YM,'YYYY-MM'),'MM')) = "+i+" THEN (UHOUR+EHOUR) END AS M_"+i+"   	 ");
				if(i<12) SQL1.append(",");
			}
			SQL1.append(" 	FROM T_RESULT R, T_PROJECT P ");
			SQL1.append(" 	WHERE R.P_NUM=P.INX AND P.STATE<>'9' ");
			if(!search.getString("search_year").equals("")) SQL1.append(" AND TO_CHAR(TO_DATE(R.YM,'YYYY-MM'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL1.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL1.append(" 	) GROUP BY A_NUM	 ");
			SQL1.append(" 	) T1, T_OPTIME O, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP ");
			SQL1.append(" WHERE JA.JASN_NUMB=T1.A_NUM(+) AND JA.JASN_NUMB=O.A_CODE(+) AND JA.PART_CODE=JP.PART_CODE	 ");
			//System.out.print("\n\n\n"+SQL1+"\n\n\n");

			
			
			SQL.append(" 	SELECT V1.*, V2.*, COUNT(1) OVER(PARTITION BY V1.UPPR_PART) AS CNT1, COUNT(1) OVER(PARTITION BY V1.PART_CODE) AS CNT2 FROM (	 ");
			SQL.append(" 	SELECT X.*, JP1.PART_NAME AS UPPR_NAME, JP2.PART_NAME FROM (	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" 	 ");
			SQL.append(" 	WHERE UPPR_PART IS NOT NULL AND LENGTH(UPPR_PART)=3 	 ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	ORDER BY UPPR_PART, PART_CODE) X, 	 ");
			SQL.append(" 	"+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP1, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP2 	 ");
			SQL.append(" 	WHERE X.UPPR_PART=JP1.PART_CODE(+) AND X.PART_CODE=JP2.PART_CODE(+)	 ");
			SQL.append(" 	) V1, 	 ");
			SQL.append(" 	( 	 ");
			SQL.append(SQL1.toString());
			SQL.append(" 	UNION ALL	 ");
			SQL.append(" 	SELECT '0' AS JASN_NUMB, '0' AS JASN_NAME, NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE, '0' AS A_NUM, NVL(SUM(MONEY1),0) AS MONEY1, ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	NVL(SUM(M1_"+i+"),0) AS M1_"+i+", 	 ");
			}
			SQL.append(" 	NVL(SUM(OPTIME),0) AS OPTIME  	 ");
			SQL.append(" 	FROM ( 	 ");
			SQL.append(SQL1.toString());
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE)	 ");
//			SQL.append(" 	ORDER BY UPPR_PART ASC, PART_CODE ASC	 ");
			SQL.append(" 	) V2 	 ");
			SQL.append(" 	WHERE V1.UPPR_PART=V2.UPPR_PART(+) AND V1.PART_CODE=V2.PART_CODE(+)	 ");
			SQL.append(" 	ORDER BY TO_NUMBER(V1.UPPR_PART) ASC, TO_NUMBER(V1.PART_CODE) ASC, NVL(JASN_NUMB,0) ASC	 ");

//			Show_Msg("Get_2:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("UPPR_PART", rs.getString("UPPR_PART"));
    			result.setString("UPPR_NAME", rs.getString("UPPR_NAME"));
    			result.setString("PART_CODE", rs.getString("PART_CODE"));
    			result.setString("PART_NAME", rs.getString("PART_NAME"));
    			result.setString("JASN_NAME", rs.getString("JASN_NAME"));
    			result.setString("JASN_NUMB", rs.getString("JASN_NUMB"));
    			result.setString("CNT1", rs.getString("CNT1"));
    			result.setString("CNT2", rs.getString("CNT2"));
    			result.setLong("MONEY1", rs.getLong("MONEY1"));
    			result.setString("OPTIME", rs.getString("OPTIME"));
    			for(int i=1;i<=12;i++) {
    				result.setLong("M1_"+i, rs.getLong("M1_"+i));
    			}
    			
//    			String opTime = getOpTime(result.getString("JASN_NUMB"));
//    			result.setString("OPTIME", opTime);
    			
    			list.add(result);	
			}
		} catch(Exception e) {
			Show_Err("Get_2:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	public LinkedList Get_3(ClassParameter search) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append(" 	SELECT V1.*, V2.*, COUNT(1) OVER(PARTITION BY V1.UPPR_PART) AS CNT FROM (	 ");
			SQL.append(" 	SELECT X.*, JP1.PART_NAME AS UPPR_NAME, JP2.PART_NAME FROM (	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" 	 ");
			SQL.append(" 	WHERE UPPR_PART IS NOT NULL AND LENGTH(UPPR_PART)=3 	 ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	ORDER BY UPPR_PART, PART_CODE) X, 	 ");
			SQL.append(" 	"+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP1, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP2 	 ");
			SQL.append(" 	WHERE X.UPPR_PART=JP1.PART_CODE(+) AND X.PART_CODE=JP2.PART_CODE(+)	 ");
			SQL.append(" 	) V1, 	 ");
			SQL.append(" 	(SELECT X.*, Y.*, MONEY1-MONEY2 AS MONEY3 FROM ( 	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE, COUNT(1) AS CNT1, NVL(SUM(MONEY),0) AS MONEY1, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	NVL(SUM(C_"+i+"),0) AS C1_"+i+", NVL(SUM(M_"+i+"),0) AS M1_"+i+" 	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM ( 	 ");
			SQL.append(" 	SELECT JP.UPPR_PART, JP.PART_CODE, RMONEY AS MONEY, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(RDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN 1 END AS C_"+i+",   	 ");
				SQL.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(RDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN RMONEY END AS M_"+i+"   	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM T_TAX T, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP  	 ");
			SQL.append(" 	WHERE T.P_NUM=P.INX AND P.STATE<>'9' AND T.STATE<>'9' AND P.PART_CODE=JP.PART_CODE	 ");
			if(!search.getString("search_year").equals("")) SQL.append(" AND TO_CHAR(TO_DATE(T.RDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE)	 ");
			SQL.append(" 	) X, 	 ");
			SQL.append(" 	( 	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART2, NVL(PART_CODE,0) AS PART_CODE2, COUNT(1) AS CNT2, NVL(SUM(MONEY),0) AS MONEY2, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	NVL(SUM(C_"+i+"),0) AS C2_"+i+", NVL(SUM(M_"+i+"),0) AS M2_"+i+" 	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM ( 	 ");
			SQL.append(" 	SELECT JP.UPPR_PART, JP.PART_CODE, PMONEY AS MONEY, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN 1 END AS C_"+i+",   	 ");
				SQL.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN PMONEY END AS M_"+i+"   	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM T_TAX T, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP  	 ");
			SQL.append(" 	WHERE T.P_NUM=P.INX AND P.STATE<>'9' AND T.STATE<>'9' AND P.PART_CODE=JP.PART_CODE	 ");
			if(!search.getString("search_year").equals("")) SQL.append(" AND TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE)	 ");
			SQL.append(" 	) Y WHERE X.UPPR_PART=Y.UPPR_PART2(+) AND X.PART_CODE=Y.PART_CODE2(+) 	 ");
			SQL.append(" 	ORDER BY X.UPPR_PART ASC, X.PART_CODE ASC	 ");
			SQL.append(" 	) V2 	 ");
			SQL.append(" 	WHERE V1.UPPR_PART=V2.UPPR_PART(+) AND V1.PART_CODE=V2.PART_CODE(+)	 ");
			SQL.append(" 	ORDER BY TO_NUMBER(V1.UPPR_PART) ASC, TO_NUMBER(V1.PART_CODE) ASC	 ");

//			Show_Msg("Get_3:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("UPPR_PART", rs.getString("UPPR_PART"));
    			result.setString("UPPR_NAME", rs.getString("UPPR_NAME"));
    			result.setString("PART_CODE", rs.getString("PART_CODE"));
    			result.setString("PART_NAME", rs.getString("PART_NAME"));
				result.setInt("CNT", rs.getInt("CNT"));
				result.setInt("CNT1", rs.getInt("CNT1"));
				result.setLong("MONEY1", rs.getLong("MONEY1"));
				result.setInt("CNT2", rs.getInt("CNT2"));
				result.setLong("MONEY2", rs.getLong("MONEY2"));
    			for(int i=1;i<=12;i++) {
    				result.setInt("C1_"+i, rs.getInt("C1_"+i));
    				result.setLong("M1_"+i, rs.getLong("M1_"+i));
    				result.setInt("C2_"+i, rs.getInt("C2_"+i));
    				result.setLong("M2_"+i, rs.getLong("M2_"+i));
    			}
				result.setLong("MONEY3", rs.getLong("MONEY3"));
    			list.add(result);	
			}
		} catch(Exception e) {
			Show_Err("Get_3:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	public LinkedList Get_4(ClassParameter search) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append(" 	SELECT V1.*, V2.*, COUNT(1) OVER(PARTITION BY V1.UPPR_PART) AS CNT FROM (	 ");
			SQL.append(" 	SELECT X.*, JP1.PART_NAME AS UPPR_NAME, JP2.PART_NAME FROM (	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE FROM "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" 	 ");
			SQL.append(" 	WHERE UPPR_PART IS NOT NULL AND LENGTH(UPPR_PART)=3 ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	ORDER BY UPPR_PART, PART_CODE) X, 	 ");
			SQL.append(" 	"+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP1, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP2 	 ");
			SQL.append(" 	WHERE X.UPPR_PART=JP1.PART_CODE(+) AND X.PART_CODE=JP2.PART_CODE(+)	 ");
			SQL.append(" 	) V1, 	 ");
			SQL.append(" 	(	 ");
			SQL.append(" 	SELECT * FROM ( 	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART, NVL(PART_CODE,0) AS PART_CODE, COUNT(1) AS CNT1, NVL(SUM(MONEY),0) AS MONEY1, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	NVL(SUM(C_"+i+"),0) AS C1_"+i+", NVL(SUM(M_"+i+"),0) AS M1_"+i+" 	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM ( 	 ");
			SQL.append(" 	SELECT JP.UPPR_PART, JP.PART_CODE, MONEY, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	  CASE WHEN  TO_NUMBER(TO_CHAR(TO_DATE(C.CDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN 1 END AS C_"+i+",   	 ");
				SQL.append(" 	  CASE WHEN  TO_NUMBER(TO_CHAR(TO_DATE(C.CDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN MONEY END AS M_"+i+"   	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM T_CONTRACT C, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP 	 ");
			SQL.append(" 	WHERE C.P_NUM=P.INX AND P.STATE<>'9' AND C.STATE<>'9' AND P.PART_CODE=JP.PART_CODE ");
			if(!search.getString("search_year").equals("")) SQL.append(" AND TO_CHAR(TO_DATE(C.CDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE) 	 ");
			SQL.append(" 	) X, 	 ");
			SQL.append(" 	( 	 ");
			SQL.append(" 	SELECT NVL(UPPR_PART,0) AS UPPR_PART2, NVL(PART_CODE,0) AS PART_CODE2, COUNT(1) AS CNT2, NVL(SUM(MONEY),0) AS MONEY2, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	NVL(SUM(C_"+i+"),0) AS C2_"+i+", NVL(SUM(M_"+i+"),0) AS M2_"+i+" 	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM ( 	 ");
			SQL.append(" 	SELECT JP.UPPR_PART, JP.PART_CODE , PMONEY AS MONEY, 	 ");
			for(int i=1;i<=12;i++) {
				SQL.append(" 	  CASE WHEN TO_NUMBER(TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN 1 END AS C_"+i+",   	 ");
				SQL.append(" 	  CASE WHEN  TO_NUMBER(TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'MM')) = "+i+" THEN PMONEY END AS M_"+i+"   	 ");
				if(i<12) SQL.append(",");
			}
			SQL.append(" 	FROM T_TAX T, T_PROJECT P, "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" JP  	 ");
			SQL.append(" 	WHERE T.P_NUM=P.INX AND P.STATE<>'9' AND T.STATE<>'9' AND P.PART_CODE=JP.PART_CODE ");
			if(!search.getString("search_year").equals("")) SQL.append(" AND TO_CHAR(TO_DATE(T.PDATE,'YYYY-MM-DD'),'YYYY')='"+search.getString("search_year")+"' ");
			if(!search.getString("part_code").equals("")) SQL.append(" AND UPPR_PART='"+search.getString("part_code")+"' ");
			SQL.append(" 	) GROUP BY ROLLUP(UPPR_PART, PART_CODE)	 ");
			SQL.append(" 	) Y WHERE X.UPPR_PART=Y.UPPR_PART2(+) AND X.PART_CODE=Y.PART_CODE2(+) 	 ");
			SQL.append(" 	ORDER BY X.UPPR_PART ASC, X.PART_CODE ASC	 ");
			SQL.append(" 	) V2 	 ");
			SQL.append(" 	WHERE V1.UPPR_PART=V2.UPPR_PART(+) AND V1.PART_CODE=V2.PART_CODE(+)	 ");
			SQL.append(" 	ORDER BY TO_NUMBER(V1.UPPR_PART) ASC, TO_NUMBER(V1.PART_CODE) ASC	 ");

			
//			Show_Msg("Get_4:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("UPPR_PART", rs.getString("UPPR_PART"));
    			result.setString("UPPR_NAME", rs.getString("UPPR_NAME"));
    			result.setString("PART_CODE", rs.getString("PART_CODE"));
    			result.setString("PART_NAME", rs.getString("PART_NAME"));
				result.setInt("CNT", rs.getInt("CNT"));
				result.setInt("CNT1", rs.getInt("CNT1"));
				result.setLong("MONEY1", rs.getLong("MONEY1"));
				result.setInt("CNT2", rs.getInt("CNT2"));
				result.setLong("MONEY2", rs.getLong("MONEY2"));
    			for(int i=1;i<=12;i++) {
    				result.setInt("C1_"+i, rs.getInt("C1_"+i));
    				result.setLong("M1_"+i, rs.getLong("M1_"+i));
    				result.setInt("C2_"+i, rs.getInt("C2_"+i));
    				result.setLong("M2_"+i, rs.getLong("M2_"+i));
    			}
    			list.add(result);	
			}
		} catch(Exception e) {
			Show_Err("Get_4:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	private String getOpTime(String jasnNumb){
		String 				result		=	"2000";
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try{
			con = DBCon.getConnection();
			SQL.append("SELECT OPTIME").append(_blank)
				.append("FROM T_OPTIME").append(_blank)
				.append("WHERE A_CODE=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, jasnNumb);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				int optime = rs.getInt(1);
				if(optime>0)result = String.valueOf(optime);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
}
