package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedList;

import builder.*;
import builder.web.*;
import jiat.model.Machine;
import jiat.model.MachineTest;
import builder.database.*;

public class machine extends Builder {

	public String Search_String(ClassParameter pRow) { 
		String rtn = "";
		if(!pRow.getString("part_code").equals("")) {
			rtn += "AND A.PART_CODE='" + pRow.getString("part_code")+"'";
		}
		if(!pRow.getString("search_text").equals("")) {
			if(pRow.getString("search_type").equals("2")) {
				rtn += "AND CONCAT(JASN_NUMB,JASN_NAME) LIKE '%" + pRow.getString("search_text")+"%'";
			} else {
				rtn += "AND CONCAT(CODE,NAME) LIKE '%" + pRow.getString("search_text")+"%'";
			}
		}
		return rtn; 
	}
	
	public int Current_Page(ClassParameter pRow) {
		int Current_Page = 0;
		Current_Page = (pRow.getString("page")==null)?1:Utility.Check_Number(pRow.getString("page"), 1);
		return Current_Page;
	}

	public ClassParameter Get_Total(ClassParameter pRow, String mSQL, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		ClassParameter 		result 		= 	new ClassParameter();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				max_num		= 	0; // 총수량
		try {
			SQL.append("SELECT COUNT(1) FROM (");
			SQL.append(mSQL);
			SQL.append(")");
			Show_Msg("Get_Total:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());	
			rs = pstmt.executeQuery();
			if(rs.next()) max_num = rs.getInt(1);
  			result.setInt("total_count", max_num);	
  			result.setInt("total_page", Utility.TotalPage(max_num, pRow.getInt("list_count")));	
  			if(Current_Page(pRow) > result.getInt("total_page")) {
				result.setString("current_page", result.getString("total_page"));	
			} else if(Current_Page(pRow) < 1) {
				result.setInt("current_page", 1);	
			} else {
				result.setInt("current_page", Current_Page(pRow));	
			}
		} catch(Exception e) {
			Show_Err("Get_Total:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
  			return result;
  		}
	}
	public LinkedList Get_Machine_List_0(ClassParameter pRow) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_Machine_List_0(pRow, con);	
		} catch(Exception e) {
			Show_Err("Get_Machine_List_0:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}

	public LinkedList Get_Machine_List_0(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {

			SQL.append("SELECT A.*, B.PART_NAME FROM T_MACHINE A,   "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" B ");
			SQL.append("WHERE A.PART_CODE=B.PART_CODE AND A.STATE='0' ");
			SQL.append(Search_String(pRow));
			SQL.append("ORDER BY A.INX ASC");

			Show_Msg("Get_Machine_List_0:"+SQL.toString());
					
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("M_NUM", rs.getObject("INX"));	
	  			result.setObject("CODE", rs.getObject("CODE"));	
	  			result.setObject("NAME", rs.getObject("NAME"));	
	  			result.setObject("PART_CODE", rs.getObject("PART_CODE"));	
	  			result.setObject("PART_NAME", rs.getObject("PART_NAME"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
	  			result.setObject("ORATE", rs.getObject("ORATE"));	
	  			result.setObject("STATE", rs.getObject("STATE"));
	  			result.setObject("ASSET", Get_Machine_Asset_List(result, con));	
	  			if(pRow.getString("APPLY").equals("1")) result.setString("APPLY", "1"); // 적용일자별로 시험항목 가져오기
	  			result.setObject("TEST", Get_Machine_Test_List(result, con));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_List_0:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		
	// 장비에 따른 자산 목록 가져오기
	public LinkedList Get_Machine_List_1(ClassParameter pRow) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_Machine_List_1(pRow, con);	
		} catch(Exception e) {
			Show_Err("Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	public LinkedList Get_Machine_List_1(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {

			SQL.append("SELECT A.*, B.PART_NAME FROM T_MACHINE A,   "+Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix")+" B ");
			SQL.append("WHERE A.PART_CODE=B.PART_CODE AND A.STATE='0' ");
			SQL.append(Search_String(pRow));
			SQL.append("ORDER BY A.INX ASC");

			ClassParameter pRow_page = Get_Total(pRow, SQL.toString(), con);
			
			SQL.insert(0, "SELECT * FROM (SELECT x.*, ceil(rownum/?) as PNUM FROM (");
			SQL.append(")x) WHERE PNUM=?");
			
			Show_Msg("Get_Machine_List_1:"+SQL.toString());
					
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pRow.getInt("list_count"));
			pstmt.setInt(2, pRow_page.getInt("current_page"));
			rs = pstmt.executeQuery();
			list = new LinkedList();
			list.add(pRow_page);
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("M_NUM", rs.getObject("INX"));	
	  			result.setObject("CODE", rs.getObject("CODE"));	
	  			result.setObject("NAME", rs.getObject("NAME"));	
	  			result.setObject("PART_CODE", rs.getObject("PART_CODE"));	
	  			result.setObject("PART_NAME", rs.getObject("PART_NAME"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
	  			result.setObject("STATE", rs.getObject("STATE"));
	  			//result.setObject("ASSET", Get_Machine_Asset_List(result, con));	
	  			if(pRow.getString("APPLY").equals("1")) result.setString("APPLY", "1"); // 적용일자별로 시험항목 가져오기
	  			result.setObject("TEST", Get_Machine_Test_List(result, con));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		

	public LinkedList Get_Machine_List_3(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			SQL.append("SELECT A.* FROM T_MACHINE A, T_MA_ASSET B WHERE A.INX=B.M_NUM AND A.STATE='0' AND B.A_NUM=? ORDER BY A.INX ASC");
			Show_Msg("Get_Machine_List_3:"+SQL.toString());
					
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setString(1, pRow.getString("JASN_NUMB"));
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("CODE", rs.getObject("CODE"));	
	  			result.setObject("PART_CODE", rs.getObject("PART_CODE"));	
	  			result.setObject("NAME", rs.getObject("NAME"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
	  			result.setObject("STATE", rs.getObject("STATE"));
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_List_3:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		
	
	// 자산에 따른 장비 목록 가져오기 
	public LinkedList Get_Machine_List_2(ClassParameter pRow) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
	
			SQL.append("SELECT * ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" A ");
			SQL.append("WHERE JASN_NUMB IN ( SELECT A_NUM FROM T_MACHINE B, T_MA_ASSET C WHERE B.INX=C.M_NUM AND B.STATE='0' AND C.STATE='0') ");
			SQL.append(Search_String(pRow));
			SQL.append("ORDER BY JASN_NUMB ASC");
			
			ClassParameter pRow_page = Get_Total(pRow, SQL.toString(), con);
			
			SQL.insert(0, "SELECT * FROM (SELECT x.*, ceil(rownum/?) as PNUM FROM (");
			SQL.append(")x) WHERE PNUM=?");
			
			Show_Msg("Get_Machine_List_2:"+SQL.toString());
					
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pRow.getInt("list_count"));
			pstmt.setInt(2, pRow_page.getInt("current_page"));
			rs = pstmt.executeQuery();
			list = new LinkedList();
			list.add(pRow_page);
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("JASN_NUMB", rs.getObject("JASN_NUMB"));	
	  			result.setObject("JASN_NAME", rs.getObject("JASN_NAME"));	
	  			result.setObject("MACHINE", Get_Machine_List_3(result, con));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_List_2:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
  		}
	}		
	
	// 장비정보 가져오기 
	public ClassParameter Get_Machine_Row(ClassParameter pRow) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_MACHINE WHERE INX=?");
			Show_Msg("Get_Machine_Row:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1,pRow.getString("M_NUM"));		
    		rs = pstmt.executeQuery();
			
    		if(rs.next()) {
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("CODE", rs.getObject("CODE"));	
	  			result.setObject("PART_CODE", rs.getObject("PART_CODE"));	
	  			result.setObject("NAME", rs.getObject("NAME"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
	  			result.setObject("ORATE", rs.getObject("ORATE"));	
	  			result.setObject("STATE", rs.getObject("STATE"));	
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_Row:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}		
	// 장비정보 가져오기 
	public Machine Get_Machine_Row(String mNum) {
		Machine result = new Machine();
		
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_MACHINE WHERE INX=?");
			Show_Msg("Get_Machine_Row:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1,mNum);		
			rs = pstmt.executeQuery();

			if(rs.next()) {
				result.setInx(rs.getInt("INX"));
				result.setCode(rs.getString("CODE"));
				result.setName(rs.getString("NAME"));
				result.setWriter(rs.getString("WRITER"));	
				result.setWriterID(rs.getString("WRITERID"));	
				result.setWrite(rs.getString("WRITE"));
				result.setOrate(rs.getInt("ORATE"));	
				result.setState(rs.getString("STATE"));
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_Row:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 장비정보 가져오기 
	public MachineTest Get_Machine_Test_Row(String tNum) {
		MachineTest result = new MachineTest();
		
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT A.*, B.NAME AS E_NAME, B.COST AS E_COST FROM T_MA_TEST A, T_ENGINEER B WHERE A.E_NUM=B.INX AND A.INX=?");
			Show_Msg("Get_Machine_Test_Row:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1,tNum);		
			rs = pstmt.executeQuery();

			if(rs.next()) {
				result.setInx(rs.getInt("INX"));
				result.setCode(rs.getString("CODE"));
				result.setName(rs.getString("NAME"));
				result.setCost(rs.getInt("COST"));	
				result.seteNum(rs.getInt("E_NUM"));
				result.seteName(rs.getString("E_NAME"));
				result.seteCost(rs.getInt("E_COST"));
				result.setState(rs.getString("STATE"));
				result.setWriter(rs.getString("WRITER"));	
				result.setWriterID(rs.getString("WRITERID"));	
				result.setWrite(rs.getString("WRITE"));	
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_Row:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	// 장비에 따른 자산 목록 가져오기
	public LinkedList Get_Machine_Asset_List(ClassParameter pRow) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_Machine_Asset_List(pRow, con);
		} catch(Exception e) {
			Show_Err("Get_Machine_Asset_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	public LinkedList Get_Machine_Asset_List(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			SQL.append("SELECT A.*, B.JASN_NAME AS A_NAME, B.PART_NAME AS PART_NAME, B.ISTL_NAME AS ISTL_NAME FROM T_MA_ASSET A, ");
			SQL.append(Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append(" B WHERE A.A_NUM=B.JASN_NUMB AND A.M_NUM=? ");
			if(!pRow.getString("STATE").equals("")) SQL.append(" AND A.STATE=? ");
			SQL.append("ORDER BY INX ASC");
			Show_Msg("Get_Machine_Asset_List:"+SQL.toString()+pRow.getString("M_NUM")+pRow.getInt("STATE"));
					
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setString(1, pRow.getString("M_NUM"));
			if(!pRow.getString("STATE").equals("")) pstmt.setInt(2, pRow.getInt("STATE"));
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("M_NUM", rs.getObject("M_NUM"));	
	  			result.setObject("A_NUM", rs.getObject("A_NUM"));	
	  			result.setObject("A_NAME", rs.getObject("A_NAME"));	
	  			result.setObject("PART_NAME", rs.getObject("PART_NAME"));	
	  			result.setObject("ISTL_NAME", rs.getObject("ISTL_NAME"));	
	  			result.setObject("STATE", rs.getObject("STATE"));	
	  			result.setObject("LOG", rs.getObject("LOG"));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_Asset_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		

	// 장비에 따른 시험항목 목록 가져오기
	public LinkedList Get_Machine_Test_List(ClassParameter pRow) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_Machine_Test_List(pRow, con);
		} catch(Exception e) {
			Show_Err("Get_Machine_Test_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	/**
	 * 
	 * @param mNum
	 * @return
	 */
	public ArrayList<MachineTest> getMachineTest(int mNum){
		ArrayList<MachineTest> result = new ArrayList<MachineTest>();
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();

		try {
			con = DBCon.getConnection();
			result = getMachineTest(con, mNum);
		} catch(Exception e) {
			Show_Err("getMachineTest:"+e.toString());
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	
	/**
	 * 
	 * @param con
	 * @param mNum
	 * @return
	 */
	public ArrayList<MachineTest> getMachineTest(Connection con, int mNum){
		PreparedStatement 			pstmt 		= 	null;
		ResultSet 					rs 			= 	null;
		StringBuffer 				SQL 		= 	new StringBuffer();
		ArrayList<MachineTest> 		result		=	new ArrayList<MachineTest>();
		try {
			SQL.append("SELECT * FROM T_MA_TEST WHERE M_NUM=? ");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, mNum);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				MachineTest test = new MachineTest();
				test.setInx(rs.getInt(MachineTest.INX_TAG));
				test.setApply(rs.getString(MachineTest.APPLY_TAG));
				test.setCode(rs.getString(MachineTest.CODE_TAG));
				test.setCost(rs.getInt(MachineTest.COST_TAG));
				test.seteNum(rs.getInt(MachineTest.E_NUM_TAG));
				test.setmNum(rs.getInt(MachineTest.M_NUM_TAG));
				test.setName(rs.getString(MachineTest.NAME_TAG));
				test.setState(rs.getString(MachineTest.STATE_TAG));
				
				result.add(test);
			}
		} catch(Exception e) {
			Show_Err("getMachineTest:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	// 시험항목리스트
	public LinkedList Get_Machine_Test_List(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			SQL.append("SELECT A.*, B.NAME AS ENGINEER_NAME FROM T_MA_TEST A, T_ENGINEER B WHERE A.E_NUM=B.INX AND A.M_NUM=? ");
			if(!pRow.getString("STATE").equals("")) SQL.append(" AND STATE=? ");
			if(pRow.getString("APPLY").equals("1")) { //적용일자 적용된 목록 가져오기
				SQL.append(" AND (APPLY,M_NUM,CODE) IN(SELECT MAX(APPLY), M_NUM,CODE  FROM T_MA_TEST WHERE APPLY<=TO_CHAR(SYSDATE,'YYYY-MM-DD')  GROUP BY M_NUM,CODE)");
			}
			SQL.append("ORDER BY A.STATE ASC, A.INX ASC");
			Show_Msg("Get_Machine_Test_List:"+SQL.toString());
					
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pRow.getInt("M_NUM"));
			if(!pRow.getString("STATE").equals("")) pstmt.setInt(2, pRow.getInt("STATE"));
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("M_NUM", rs.getObject("M_NUM"));	
	  			result.setObject("CODE", rs.getObject("CODE"));	
	  			result.setObject("NAME", rs.getObject("NAME"));	
	  			result.setObject("COST", rs.getObject("COST"));	
	  			result.setObject("E_NUM", rs.getObject("E_NUM"));	
	  			result.setObject("ENGINEER_NAME", rs.getObject("ENGINEER_NAME"));	
	  			result.setObject("APPLY", rs.getObject("APPLY"));	
	  			result.setObject("STATE", rs.getObject("STATE"));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Machine_Test_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		

	// 장비등록
	public int Insert_Machine(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("INSERT INTO T_MACHINE(CODE,NAME,PART_CODE,WRITER,WRITERID,WRITE,ORATE,STATE) ");
			SQL.append("VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
			Show_Msg("Insert_Machine:"+SQL.toString());

			int index = 1;
			String cols[] = {"INX"};
			pstmt = con.prepareStatement(SQL.toString(), cols);
			pstmt.setString(index++, pRow.getString("CODE"));		
			pstmt.setString(index++, pRow.getString("NAME"));		
			pstmt.setString(index++, pRow.getString("PART_CODE"));		
			pstmt.setString(index++, pRow.getString("WRITER"));		
			pstmt.setString(index++, pRow.getString("WRITERID"));		
			pstmt.setString(index++, pRow.getString("WRITE"));		
			pstmt.setString(index++, pRow.getString("ORATE"));		
			pstmt.setString(index++, pRow.getString("STATE"));		
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if(rs.next()) result = rs.getInt(1);

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Insert_Machine:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}

	// 장비수정
	public int Update_Machine(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("UPDATE T_MACHINE SET CODE=?,NAME=?,ORATE=?,PART_CODE=? WHERE INX=?");
			Show_Msg("Update_Machine:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("CODE"));		
			pstmt.setString(index++, pRow.getString("NAME"));		
			pstmt.setString(index++, pRow.getString("ORATE"));		
			pstmt.setString(index++, pRow.getString("PART_CODE"));		
			pstmt.setString(index++, pRow.getString("INX"));		
			result = pstmt.executeUpdate();

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Update_Machine:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}

	// 장비삭제
	public int Delete_Machine(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("UPDATE T_MACHINE SET STATE=? WHERE INX=?");
			Show_Msg("Delete_Machine:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("STATE"));		
			pstmt.setString(index++, pRow.getString("INX"));		
			result = pstmt.executeUpdate();

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Delete_Machine:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}
	
	// 시험항목등록
	public int Insert_Machine_Test(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("INSERT INTO T_MA_TEST(M_NUM,CODE,NAME,COST,APPLY,E_NUM,STATE) ");
			SQL.append("VALUES(?, ?, ?, ?, ?, ?, ?)");
			Show_Msg("Insert_Machine_Test:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("M_NUM"));		
			pstmt.setString(index++, pRow.getString("CODE"));		
			pstmt.setString(index++, pRow.getString("NAME"));		
			pstmt.setString(index++, pRow.getString("COST"));		
			pstmt.setString(index++, pRow.getString("APPLY"));		
			pstmt.setString(index++, pRow.getString("E_NUM"));		
			pstmt.setString(index++, pRow.getString("STATE"));		
			result = pstmt.executeUpdate();

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Insert_Machine_Test:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}	

	// 자산항목등록
	public int Insert_Machine_Asset(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("INSERT INTO T_MA_ASSET(M_NUM,A_NUM,STATE,LOG) ");
			SQL.append("VALUES(?, ?, ?, ?)");
			Show_Msg("Insert_Machine_Asset:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("M_NUM"));		
			pstmt.setString(index++, pRow.getString("A_NUM"));		
			pstmt.setString(index++, pRow.getString("STATE"));		
			pstmt.setString(index++, pRow.getString("LOG"));		
			result = pstmt.executeUpdate();

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Insert_Machine_Asset:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}	

	// 시험학목삭제
	public int Delete_Machine_Test(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("UPDATE T_MA_TEST SET STATE=9 WHERE INX=?");
			Show_Msg("Delete_Machine_Test:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("INX"));		
			result = pstmt.executeUpdate();

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Delete_Machine_Test:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}	

	// 자산항목삭제
	public int Delete_Machine_Asset(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("UPDATE T_MA_ASSET SET STATE=?, LOG=CONCAT(LOG,?) WHERE INX=?");
			Show_Msg("Delete_Machine_Asset:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("STATE"));		
			pstmt.setString(index++, pRow.getString("LOG"));		
			pstmt.setString(index++, pRow.getString("INX"));		
			result = pstmt.executeUpdate();

		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Delete_Machine_Asset:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}	
	
}
