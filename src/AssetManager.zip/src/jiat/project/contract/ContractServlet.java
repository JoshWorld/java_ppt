package jiat.project.contract;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import jiat.ProjectProc;
import jiat.model.Contract;
import jiat.util.JumpServlet;
import twitter4j.internal.org.json.JSONObject;

@WebServlet("/project/ContractServlet")
public class ContractServlet extends JumpServlet {
	private static final long serialVersionUID = 1L;
	Logger logger = Logger.getLogger(this.getClass().getSimpleName());

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/plain; charset=UTF-8");
		int result = -1;
		try {
			String contextRootPath = this.getServletContext().getRealPath("/");
			final String savePath = contextRootPath + "/upload";
			Contract contract = new Contract();

			DiskFileItemFactory diskFactory = new DiskFileItemFactory(); 
			//임시 저장폴더
			diskFactory.setRepository(new File(savePath));
			ServletFileUpload upload = new ServletFileUpload(diskFactory); 
			upload.setSizeMax(10 * 1024 * 1024); //10MB : 전체 최대 업로드 파일 크기
			List<FileItem> items = upload.parseRequest(req); 

			for(FileItem item : items) {				
				//5. FileItem이 폼입력 항목인지 여부에 따라 알맞은 처리
				if (item.isFormField()) { //파일이 아닌경우					
					processFormField(contract, item);							
				} else { //파일인 경우
					if(item.getSize()!=0) { //업로드된 파일이 있을경우에만 처리
						//						processUploadFile(model, item, contextRootPath);
					}														
				}			
			}
			
			ContractProc proc = new ContractProc();
			result = proc.updateContract(contract);
			
			req.setAttribute(MESSAGE_TAG, SUCCESS_CODE);
		} catch(Exception e) {	
			e.printStackTrace();
			req.setAttribute(MESSAGE_TAG, FAIL_CODE);
		}
		getServletContext().getRequestDispatcher("/project/add_contract.jsp").forward(req, resp);
	}
	//일반 양식 처리
	private void processFormField(Contract cont, FileItem item) throws Exception{
		String name = item.getFieldName();
		String value = item.getString("UTF-8");
		
		if(name.equalsIgnoreCase("c_num")){
			cont.setInx(Integer.parseInt(value));
		} else if(name.equalsIgnoreCase(Contract.P_NUM_TAG)){
			cont.setP_num(Integer.parseInt(value));
		} else if(name.equalsIgnoreCase(Contract.C_DATE_TAG)){
			cont.setCdate(value);
		} else if(name.equalsIgnoreCase(Contract.GRANTOR_TAG)){
			cont.setGrantor(value);
		} else if(name.equalsIgnoreCase(Contract.MONEY_TAG)){
			cont.setMoney(Integer.parseInt(value));
		} else if(name.equalsIgnoreCase(Contract.CONTENT_TAG)){
			cont.setContent(value);
		}
	}
}
