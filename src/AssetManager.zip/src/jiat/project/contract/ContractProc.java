package jiat.project.contract;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import org.json.JSONObject;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.ProjectResult;
import jiat.model.Contract;
import jiat.model.Estimate;
import jiat.model.FileInfo;

public class ContractProc extends Builder {

	public int getContractsCount(int pNum){
		int result = 0;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getContractsCount(con, pNum);
		}catch(Exception e) {
			Show_Err("getEstimates:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int getContractsCount(Connection con, int pNum){
		int 				result		=	0;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT COUNT(*) FROM T_CONTRACT WHERE P_NUM = ? AND NVL(STATE,'0')<>'9'");
	
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				result = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	public Estimate getEstimateRecent(int pNum){
		Estimate			result 		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getEstimateRecent(con, pNum);
		}catch(Exception e) {
			Show_Err("getEstimates:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private Estimate getEstimateRecent(Connection con, int pNum){
		Estimate			result 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			result = new Estimate();
			
			SQL.append("SELECT * FROM T_ESTIMATE WHERE P_NUM=? AND NVL(STATE,'0')<>'9' ORDER BY INX DESC");

			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				result.setMoney(rs.getInt(Estimate.MONEY_TAG));
				result.setUnit(rs.getString(Estimate.UNIT_TAG));
				break;
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	public int updateContract(Contract contract){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = updateContract(con, contract);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int updateContract(Connection con, Contract contract){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update T_CONTRACT set ")
				.append(Contract.C_DATE_TAG).append("= ?, ")
				.append(Contract.APPROVAL_TAG).append("= ?, ")
				.append(Contract.APPROVAL_ID_TAG).append("= ?, ")
				.append(Contract.APPROVAL2_TAG).append("= ?, ")
				.append(Contract.APPROVAL_ID2_TAG).append("= ?, ")
				.append(Contract.MONEY_TAG).append("= ?, ")
				.append(Contract.CONTENT_TAG).append("=? ")
				.append(" where INX = ?");
			
			int index =1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, contract.getCdate());
			
			pstmt.setString(index++, contract.getApproval());
			pstmt.setString(index++, contract.getApprovalId());
			pstmt.setString(index++, contract.getApproval2());
			pstmt.setString(index++, contract.getApprovalId2());
			
			pstmt.setInt(index++, contract.getMoney());
			pstmt.setString(index++, contract.getContent());
			pstmt.setInt(index++, contract.getInx());
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public int changeContractState(int cNum, int state){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = changeContractState(con, cNum, state);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	public JSONObject changeContractStateReturn(int cNum, int state, String grantorId, String grantorName){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		JSONObject result = new JSONObject();
		
		try {
			con = DBCon.getConnection();
			int changeLog = changeContractState(con, cNum, state, grantorId, grantorName);
			
			result.put("result", changeLog);
			result.put("contract", Contract.toJSONObject(getContract(cNum)));
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	public JSONObject changeContractStateReturn2(int cNum, int state, String grantorId2, String grantorName2){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		JSONObject result = new JSONObject();
		
		try {
			con = DBCon.getConnection();
			int changeLog = changeContractState2(con, cNum, state, grantorId2, grantorName2);
			
			result.put("result", changeLog);
			result.put("contract", Contract.toJSONObject(getContract(cNum)));
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	public Contract getContract(int cNum){
		Contract result = null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getContract(con, cNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private Contract getContract(Connection con, int cNum){
		Contract 			result 		= 	null;	
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_CONTRACT WHERE INX = ?");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, cNum);
			rs = pstmt.executeQuery();
			
			result = new Contract();
			while(rs.next()){
				result.setInx(rs.getInt(Contract.INX_TAG));
				result.setP_num(rs.getInt(Contract.P_NUM_TAG));
				result.setCdate(rs.getString(Contract.C_DATE_TAG));
				result.setMoney(rs.getInt(Contract.MONEY_TAG));
				result.setApproval(rs.getString(Contract.APPROVAL_TAG));
				result.setRdate(rs.getString(Contract.RDATE_TAG));
				result.setGrantor(rs.getString(Contract.GRANTOR_TAG));
				result.setGdate(rs.getString(Contract.G_DATE_TAG));
				result.setState(rs.getInt(Contract.STATE_TAG));
				result.setContent(rs.getString(Contract.CONTENT_TAG));
				result.setApprovalId(rs.getString(Contract.APPROVAL_ID_TAG));
				result.setApproval2(rs.getString(Contract.APPROVAL2_TAG));
				result.setApprovalId2(rs.getString(Contract.APPROVAL_ID2_TAG));
				result.setGrantor2(rs.getString(Contract.GRANTOR2_TAG));
				result.setGrantorId2(rs.getString(Contract.GRANTOR_ID2_TAG));
				result.setGdate2(rs.getString(Contract.G_DATE2_TAG));
				result.setWriter(rs.getString(Contract.WRITER_TAG));
				result.setWriterId(rs.getString(Contract.WRITERID_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	public ArrayList<Contract> getContracts(int pNum){
		ArrayList<Contract>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getContracts(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	public Contract getContractWithFiles(int cNum){
		Contract result = null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getContractWithFiles(con, cNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private Contract getContractWithFiles(Connection con, int cNum){
		Contract 			result 		= 	null;	
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT ")
				.append("contract.INX, contract.P_NUM, contract.CDATE, contract.MONEY, contract.APPROVAL, contract.RDATE, contract.GRANTOR,contract.GDATE, contract.STATE,")
				.append("contract.APPROVAL2,contract.GRANTOR2, contract.GDATE2, tFile.fname ")
				.append("from T_CONTRACT contract, T_FILE tFile ")
				.append("WHERE contract.INX = ? and contract.INX = tFile.C_NUM");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, cNum);
			rs = pstmt.executeQuery();
			
			result = new Contract();
			ArrayList<FileInfo> fileInfos = new ArrayList<FileInfo>();
			
			while(rs.next()){
				if(result.getInx() != rs.getInt(Contract.INX_TAG)){
					result.setInx(rs.getInt(Contract.INX_TAG));
					result.setP_num(rs.getInt(Contract.P_NUM_TAG));
					result.setCdate(rs.getString(Contract.C_DATE_TAG));
					result.setMoney(rs.getInt(Contract.MONEY_TAG));
					result.setApproval(rs.getString(Contract.APPROVAL_TAG));
					result.setRdate(rs.getString(Contract.RDATE_TAG));
					result.setGrantor(rs.getString(Contract.GRANTOR_TAG));
					result.setGdate(rs.getString(Contract.G_DATE_TAG));
					result.setState(rs.getInt(Contract.STATE_TAG));
					
					result.setApproval2(rs.getString(Contract.APPROVAL2_TAG));
					result.setGrantor2(rs.getString(Contract.GRANTOR2_TAG));
					result.setGdate2(rs.getString(Contract.G_DATE2_TAG));
				}
				FileInfo fileInfo = new FileInfo();
				fileInfo.setfName(rs.getString(FileInfo.FNAME_TAG));
				fileInfos.add(fileInfo);
			}
			result.setFileInfos(fileInfos);
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	private ArrayList<Contract> getContracts(Connection con, int pNum){
		ArrayList<Contract> list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_CONTRACT WHERE ")
				.append(P_NUM_TAG)
				.append("=? AND NVL(STATE,'0')<>'9'")
				.append("order by INX desc");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Contract>();
			while(rs.next()){
				Contract contract = new Contract();
				contract.setInx(rs.getInt(Contract.INX_TAG));
				contract.setP_num(rs.getInt(Contract.P_NUM_TAG));
				contract.setCdate(rs.getString(Contract.C_DATE_TAG));
				contract.setMoney(rs.getInt(Contract.MONEY_TAG));
				contract.setRdate(rs.getString(Contract.RDATE_TAG));
				contract.setState(rs.getInt(Contract.STATE_TAG));
				contract.setContent(rs.getString(Contract.CONTENT_TAG));
				contract.setWriterId(rs.getString(Contract.WRITERID_TAG));
				contract.setApprovalId(rs.getString(Contract.APPROVAL_ID_TAG));
				contract.setApproval(rs.getString(Contract.APPROVAL_TAG));
				contract.setApproval2(rs.getString(Contract.APPROVAL2_TAG));
				contract.setApprovalId2(rs.getString(Contract.APPROVAL_ID2_TAG));
				
				if(contract.getApprovalId()!=null && contract.getApproval()==null){
					// 만일 ApprovalId 만 있고 Approval(Name) 은 없을 경우
					contract.setApproval(getUserKnam(con, contract.getApprovalId()));
				}
				if(contract.getApprovalId2()!=null && contract.getApproval2()==null){
					// 만일 ApprovalId2 만 있고 Approval2(Name) 은 없을 경우
					contract.setApproval2(getUserKnam(con, contract.getApprovalId2()));
				}
				list.add(contract);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	private String getUserKnam(Connection con, String userIdnt){
		final String USER_TABLE = Get_Property("jumpdb.prefix")+"JA4000_VIEW"+Get_Property("jumpdb.suffix");
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		String				result 		= 	"";
		try {
			SQL.append("SELECT USER_KNAM FROM").append(_blank)
				.append(USER_TABLE).append(_blank)
				.append("WHERE USER_IDNT=?");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setString(1, userIdnt);
			rs = pstmt.executeQuery();
			if(rs.next()){
				result = rs.getString(1);
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	public int addContract(Contract contract){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    String stoday = formatter.format(today);
	    
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO T_CONTRACT (P_NUM, CDATE, MONEY, CONTENT, APPROVALID, WRITER, WRITERID, WRITE, APPROVALID2")
				.append(", APPROVAL, APPROVAL2 ")
				.append(")")
				.append(_blank);
			SQL.append("VALUES(?,?,?,?,?,?,?,?,?,?,?").append(_blank)
//				.append(", (SELECT USER_KNAM FROM ").append(USER_TABLE).append(_blank)
//				.append("WHERE USER_IDNT=?),").append(_blank)
//				.append("(SELECT USER_KNAM FROM ").append(USER_TABLE).append(_blank)
//				.append("WHERE USER_IDNT=?)").append(_blank)
				.append(")");
			int index=1;
			String cols[] = {"INX"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			
			pstmt.setInt(index++, contract.getP_num());
			pstmt.setString(index++, contract.getCdate());
			pstmt.setInt(index++, contract.getMoney());
			pstmt.setString(index++, contract.getContent());
			pstmt.setString(index++, contract.getApprovalId());
			pstmt.setString(index++, contract.getWriter());
			pstmt.setString(index++, contract.getWriterId());
			pstmt.setString(index++, stoday);
			pstmt.setString(index++, contract.getApprovalId2());
			pstmt.setString(index++, contract.getApproval());
			pstmt.setString(index++, contract.getApproval2());
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public int addContract(ClassParameter param){
		String cDate = param.getString(Contract.C_DATE_TAG);
		String cName = param.getString(Contract.GRANTOR_TAG);
		String cName2 = param.getString(Contract.GRANTOR2_TAG);
		String cBudget = param.getString(Contract.MONEY_TAG);
		
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO T_CONTRACT (P_NUM, CDATE, MONEY, APPROVAL, GRANTOR, APPROVAL2, GRANTOR2) ");
			SQL.append("VALUES(?,?,?,?,?,?,?)");
			
			int index=1;
			String cols[] = {"INX"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			
			pstmt.setInt(index++, 217);
			
			pstmt.setString(index++, cDate);
			pstmt.setInt(index++, Integer.parseInt(cBudget));
			pstmt.setString(index++, cName);
			pstmt.setString(index++, "승인자");	
			pstmt.setString(index++, cName2);
			pstmt.setString(index++, "승인자");
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	private int changeContractState(Connection con, int cNum, int state, String grantorId, String grantorName){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    String stoday = formatter.format(today);
	    
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("update T_CONTRACT set STATE = ?, GRANTORID=?, GRANTOR=?");
			
			if(state == 1){
				SQL.append(",RDATE=?");
			}else if(state ==2){
				SQL.append(",GDATE=?");
			}else if(state ==3){
				SQL.append(",RDATE=?");
				SQL.append(",GDATE=?");
			}
			
			SQL.append("where INX = ?");
			int index = 1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, state);
			pstmt.setString(index++, grantorId);
			pstmt.setString(index++, grantorName);
			if(state == 1){
				pstmt.setString(index++, stoday);
			}else if(state ==2){
				pstmt.setString(index++, stoday);
			}else if(state ==3){
				pstmt.setString(index++, stoday);
				pstmt.setString(index++, stoday);
			}
			pstmt.setInt(index++, cNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	
	private int changeContractState2(Connection con, int cNum, int state, String grantorId2, String grantorName2){
		Date today = Calendar.getInstance().getTime();
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	    String stoday = formatter.format(today);
	    
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("update T_CONTRACT set STATE = ?, GRANTORID2=?, GRANTOR2=?");
			if(state == 3)	SQL.append(", GDATE2=? ");
			
			SQL.append("where INX = ?");
			int index = 1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, state);
			pstmt.setString(index++, grantorId2);
			pstmt.setString(index++, grantorName2);
			if(state == 3)	pstmt.setString(index++, stoday);
			pstmt.setInt(index++, cNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	
	private int changeContractState(Connection con, int cNum, int state){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update T_CONTRACT set STATE = ?, GRANTORID=?").append("where INX = ?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, state);
			pstmt.setInt(2, cNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
		
	public int deleteContract(int cNum){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = deleteContract(con, cNum);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int deleteContract(Connection con, int cNum){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update T_CONTRACT set STATE = '9' where INX = ?");
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, cNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
}
