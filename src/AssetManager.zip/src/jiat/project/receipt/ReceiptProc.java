package jiat.project.receipt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import builder.Builder;
import builder.database.DBConnection;
import jiat.model.Receipt;

public class ReceiptProc extends Builder {
	HashMap<String,String> stateMap;
	/**
	 * 생성자
	 */
	public ReceiptProc(){
		stateMap = new HashMap<String,String>();
		stateMap.put("T", "임시저장");
		stateMap.put("P", "결재대기");
		stateMap.put("F", "결재완료");
		stateMap.put("N", "미등록");
	}
	
	/**
	 * 
	 * @param input
	 * @return 
	 */
	public int addReceipt(Receipt input){
		int		 			result		=	-1;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		
		try {
			con = DBCon.getConnection();
			result = addReceipt(con, input);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	
	/**
	 * 
	 * @param con
	 * @param input
	 * @return
	 */
	private int addReceipt(Connection con, Receipt input){
		int		 			result		=	-1;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("Insert into T_DOC ")
			.append("(P_NUM, NUM, TITLE, WRITERID, WRITER, WRITE, STATE) ")
			.append("VALUES (?,?,?,?,?,?,?)");
//			
			String cols[] = {"INX"};
			pstmt = con.prepareStatement(SQL.toString(), cols);
			int index=1;
			pstmt.setInt(index++, input.getpNum());
			pstmt.setString(index++, input.getNum());
			pstmt.setString(index++, input.getTitle());
			pstmt.setString(index++, input.getWriterId());
			pstmt.setString(index++, input.getWriter());
			pstmt.setString(index++, input.getWrite());
			pstmt.setString(index++, "F");
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	
	public int getReceiptNum(int pNum){
		int					result		=	0;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getReceiptNum(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	
	private int getReceiptNum(Connection con, int pNum){
		String				tableName	=	Get_Property("jumpdb.prefix")+"JG5000"+Get_Property("jumpdb.suffix");
		int					result 		=	0;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT count(1)").append(_blank)
				.append("FROM T_DOC A,")
				.append(tableName).append(_blank)
				.append("B WHERE A.NUM=B.ELTR_NUMB(+) and A.P_NUM=?");
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			if(rs.next()){
				result = rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public ArrayList<Receipt> getReceiptList(int pNum){
		ArrayList<Receipt>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getReceiptList(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	private ArrayList<Receipt> getReceiptList(Connection con, int pNum){
		String				tableName	=	Get_Property("jumpdb.prefix")+"JG5000"+Get_Property("jumpdb.suffix");
		ArrayList<Receipt>  list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		Set<String> keySet = stateMap.keySet();
		Iterator<String> iter = keySet.iterator();
		try{
			SQL.append("SELECT A.*, DCNT_NUMB").append(_blank)
			.append(", DECODE(ELTR_STAT,").append(_blank);
			
			while(iter.hasNext()){
				final String key = iter.next();
				if(key.equals("N")){
					SQL.append(_quat).append(stateMap.get(key)).append(_quat);
				}else{
					SQL.append(_quat).append(key).append(_quat).append(_comma)
					.append(_quat).append(stateMap.get(key)).append(_quat)
					.append(_comma).append(_blank);
				}
			}
			
			SQL.append(")")
				.append("AS ELTR_STAT FROM T_DOC A,").append(_blank)
				.append(tableName).append(_blank)
				.append("B WHERE A.NUM=B.ELTR_NUMB(+) and A.P_NUM=?");
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Receipt>();
			while(rs.next()){
				Receipt receipt = new Receipt();
				receipt.setInx(rs.getInt(Receipt.INX_TAG));
				receipt.setpNum(rs.getInt(Receipt.P_NUM_TAG));
				receipt.setNum(rs.getString(Receipt.NUM_TAG));
				receipt.setTitle(rs.getString(Receipt.TITLE_TAG));
				receipt.setWriterId(rs.getString(Receipt.WRITERID_TAG));
				receipt.setWriter(rs.getString(Receipt.WRITER_TAG));
				receipt.setWrite(rs.getString(Receipt.WRITE_TAG));
				receipt.setState(rs.getString(Receipt.STATE_TAG));
				receipt.setDcntNumb(rs.getString(Receipt.DCNT_NUMB));
				receipt.setEltrState(rs.getString(Receipt.ELTR_STAT));
				list.add(receipt);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	
	public Receipt getReceipt(int rNum){
		Receipt				result		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getReceipt(con, rNum);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	
	private Receipt getReceipt(Connection con, int rNum){
		Receipt 			result 		=	new Receipt();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_DOC WHERE ")
				.append(Receipt.INX_TAG)
				.append("=? ");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, rNum);
			
			rs = pstmt.executeQuery();
			if(rs.next()){
				result.setInx(rs.getInt(Receipt.INX_TAG));
				result.setpNum(rs.getInt(Receipt.P_NUM_TAG));
				result.setNum(rs.getString(Receipt.NUM_TAG));
				result.setTitle(rs.getString(Receipt.TITLE_TAG));
				result.setWriterId(rs.getString(Receipt.WRITERID_TAG));
				result.setWriter(rs.getString(Receipt.WRITER_TAG));
				result.setWrite(rs.getString(Receipt.WRITE_TAG));
				result.setState(rs.getString(Receipt.STATE_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public ArrayList<Receipt> getReceipts(int pNum){
		ArrayList<Receipt>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getReceipts(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	private ArrayList<Receipt> getReceipts(Connection con, int pNum){
		ArrayList<Receipt> list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_DOC WHERE ")
				.append(P_NUM_TAG)
				.append("=? ")
				.append("order by INX desc");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Receipt>();
			while(rs.next()){
				Receipt receipt = new Receipt();
				receipt.setInx(rs.getInt(Receipt.INX_TAG));
				receipt.setpNum(rs.getInt(Receipt.P_NUM_TAG));
				receipt.setNum(rs.getString(Receipt.NUM_TAG));
				receipt.setTitle(rs.getString(Receipt.TITLE_TAG));
				receipt.setWriterId(rs.getString(Receipt.WRITERID_TAG));
				receipt.setWriter(rs.getString(Receipt.WRITER_TAG));
				receipt.setWrite(rs.getString(Receipt.WRITE_TAG));
				receipt.setState(rs.getString(Receipt.STATE_TAG));
								
				list.add(receipt);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
}
