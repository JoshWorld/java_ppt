package jiat.project.tax;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Logger;

import org.json.JSONObject;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.Tax;

public class TaxProc extends Builder {
	private Logger logger = Logger.getLogger(this.getClass().getSimpleName());
	private final String TABLE_NAME = "T_TAX";
	public static final int FINANCIAL_PART = 280;
	
	private Connection				con;
	private DBConnection 			DBCon;
	
	public TaxProc(){
		DBCon =	new DBConnection();
	}
	public int updateTax(Tax tax){
		int result = 0;
		
		try {
			con = DBCon.getConnection();
			result = updateTax(con, tax);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	public int changeState(Tax tax){
		int result = 0;
		
		try {
			con = DBCon.getConnection();
			result = changeState(con, tax);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int changeState(Connection con, Tax tax){
		int 					result		= 	0; 
		StringBuffer 			SQL 		= 	new StringBuffer();
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		try{
			SQL.append("update ").append(_blank)
				.append(TABLE_NAME).append(_blank)
				.append(" set ").append(_blank)
				.append(Tax.STATE_TAG).append(" = ?,").append(_blank)
				.append(Tax.P_DATE_TAG).append("= ?").append(_blank)
				.append("where INX = ?");
			int index = 1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, tax.getState());
			pstmt.setString(index++, tax.getpDate());
			pstmt.setInt(index++, tax.getInx());
			
			result = pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	private int updateTax(Connection con, Tax tax){
		int 					result		= 	0; 
		StringBuffer 			SQL 		= 	new StringBuffer();
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		try{
			SQL.append("update ")
				.append(TABLE_NAME)
				.append(" set ")
				.append(Tax.P_DATE_TAG).append(" = ?, ")
				.append(Tax.P_MONEY_TAG).append(" = ?, ")
				.append(Tax.STATE_TAG).append(" = ?, ")
				.append(Tax.C_TAXNUM_TAG).append(" = ? ")
				.append(" where INX = ?");
			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, tax.getpDate());
			pstmt.setInt(index++, tax.getpMoney());
			pstmt.setInt(index++, tax.getState());
			pstmt.setString(index++, tax.getcTaxNum());
			pstmt.setInt(index++, tax.getInx());
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public JSONObject changeTaxStateReturn(int tNum, int state){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		JSONObject result = new JSONObject();
		
		try {
			con = DBCon.getConnection();
			int changeLog = changeTaxStateReturn(con, tNum, state);
			result.put("result", changeLog);
			result.put("tax", Tax.toJSONObject(getTax(tNum)));
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	public Tax getTax(int index){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		Tax						result		=	null;
		
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("select * from ").append(TABLE_NAME).append(" where INX = ?");
			con = DBCon.getConnection();
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, index);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				result = Tax.getTaxFromDB(rs);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	private int changeTaxStateReturn(Connection con, int cNum, int state){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update ").append(TABLE_NAME).append("set STATE = ?").append("where INX = ?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, state);
			pstmt.setInt(2, cNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	
	
	public int addTax(ClassParameter param){
		int pNum = param.getInt(Tax.PNUM_TAG);
		String content = param.getString(Tax.CONTENT_TAG);
		String rDate = param.getString(Tax.R_DATE_TAG);
		String pDate = param.getString(Tax.P_DATE_TAG);
		int money = Integer.parseInt(param.getString(Tax.R_MONEY_TAG));
		String cName = param.getString(Tax.C_NAME_TAG);
		String cPhone = param.getString(Tax.C_PHONE_TAG);
		String cMail = param.getString(Tax.C_MAIL_TAG);
		String state = param.getString(Tax.STATE_TAG);
		
		String cName2 = param.getString(Tax.C_NAME2_TAG);
		String cPhone2 = param.getString(Tax.C_PHONE2_TAG);
		String cMail2 = param.getString(Tax.C_MAIL2_TAG);
		String cTaxNum = param.getString(Tax.C_TAXNUM_TAG);
		String cMemo = param.getString(Tax.C_MEMO_TAG);
		
		
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO ")
				.append(TABLE_NAME)
				.append("(P_NUM, CONTENT, PDATE, RDATE, RMONEY, STATE, C_NAME, C_PHONE, C_MAIL, C_NAME2, C_PHONE2, C_MAIL2, C_TAXNUM, C_MEMO) ")
				.append("VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			int index=1;
			String cols[] = {"INX"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			pstmt.setInt(index++, pNum);
			pstmt.setString(index++, content);
			pstmt.setString(index++, pDate);
			pstmt.setString(index++, rDate);
			pstmt.setInt(index++, money);
			pstmt.setInt(index++, 0);
			pstmt.setString(index++, cName);
			pstmt.setString(index++, cPhone);
			pstmt.setString(index++, cMail);
			
			pstmt.setString(index++, cName2);
			pstmt.setString(index++, cPhone2);
			pstmt.setString(index++, cMail2);
			pstmt.setString(index++, cTaxNum);
			pstmt.setString(index++, cMemo);
			
			pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	
	public int addTax(Tax tax){	
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO ")
				.append(TABLE_NAME)
				.append("(P_NUM, CONTENT, PDATE, RDATE, RMONEY, STATE, C_NAME, C_PHONE, C_MAIL, C_NAME2, C_PHONE2, C_MAIL2, C_TAXNUM, C_MEMO, WRITE, WRITER, WRITERID) ")
				.append("VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			
			int index=1;
			String cols[] = {"INX"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			pstmt.setInt(index++, tax.getpNum());
			pstmt.setString(index++, tax.getContent());
			pstmt.setString(index++, tax.getpDate());
			pstmt.setString(index++, tax.getrDate());
			pstmt.setInt(index++, tax.getrMoney());
			pstmt.setInt(index++, tax.getState());
			pstmt.setString(index++, tax.getcName());
			pstmt.setString(index++, tax.getcPhone());
			pstmt.setString(index++, tax.getcMail());
			
			pstmt.setString(index++, tax.getcName2());
			pstmt.setString(index++, tax.getcPhone2());
			pstmt.setString(index++, tax.getcMail2());
			pstmt.setString(index++, tax.getcTaxNum());
			pstmt.setString(index++, tax.getcMemo());
			pstmt.setString(index++, tax.getWrite());
			pstmt.setString(index++, tax.getWriter());
			pstmt.setString(index++, tax.getWriterId());
			
			pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	
	public ArrayList<Tax> getTaxList(int pNum){
		ArrayList<Tax>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getTaxList(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	private  ArrayList<Tax> getTaxList(Connection con, int pNum){
		ArrayList<Tax> 	list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM ")
				.append(TABLE_NAME)
				.append(" WHERE P_NUM = ? ")
				.append("order by INX");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Tax>();
			while(rs.next()){
				Tax tax = new Tax();
				tax.setInx(rs.getInt(Tax.INX_TAG));
				tax.setpNum(rs.getInt(Tax.PNUM_TAG));
				tax.setContent(rs.getString(Tax.CONTENT_TAG));
				tax.setcName(rs.getString(Tax.C_NAME_TAG));
				tax.setcPhone(rs.getString(Tax.C_PHONE_TAG));
				tax.setcMail(rs.getString(Tax.C_MAIL_TAG));
				tax.setrDate(rs.getString(Tax.R_DATE_TAG));
				tax.setrMoney(rs.getInt(Tax.R_MONEY_TAG));
				tax.setpDate(rs.getString(Tax.P_DATE_TAG));
				tax.setPublish(rs.getString(Tax.PUBLISH_TAG));
				tax.setpMoney(rs.getInt(Tax.P_MONEY_TAG));
				tax.setWriterId(rs.getString(Tax.WRITER_ID_TAG));
				tax.setWriter(rs.getString(Tax.WRITER_TAG));
				tax.setWrite(rs.getString(Tax.WRITE_TAG));
				tax.setState(rs.getInt(Tax.STATE_TAG));
				
				tax.setcName2(rs.getString(Tax.C_NAME2_TAG));
				tax.setcPhone2(rs.getString(Tax.C_PHONE2_TAG));
				tax.setcMail2(rs.getString(Tax.C_MAIL2_TAG));
				tax.setcTaxNum(rs.getString(Tax.C_TAXNUM_TAG));
				tax.setcMemo(rs.getString(Tax.C_MEMO_TAG));
				
				list.add(tax);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	public int deleteTax(int tNum){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = deleteTax(con, tNum);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int deleteTax(Connection con, int tNum){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("delete from T_TAX where INX = ?");
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, tNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
}
