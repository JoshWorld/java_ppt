package jiat.project.Client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import builder.Builder;
import builder.database.DBConnection;
import jiat.model.Client;

public class ClientProc extends Builder {
	public static final int NUM_PER_PAGE = 20;
	private final String _blank = " ";
	
	public HashMap<Integer, Client> getClientMap(String query, int pageNum){
		final String TABLE_NAME_A = Get_Property("jumpdb.prefix")+"JK9000"+Get_Property("jumpdb.suffix");
		final String TABLE_NAME_B = Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix");
		
		HashMap<Integer, Client>	result		=	null;
		Connection					con 		=	null;
		PreparedStatement 			pstmt 		= 	null;
		ResultSet 					rs 			= 	null;
		DBConnection 				DBCon 		= 	new DBConnection();
		StringBuffer 				SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT * FROM").append(_blank)
				.append("(SELECT x.*, ceil(rownum/?) as PNUM").append(_blank)
				.append("FROM").append(_blank)
				.append("(SELECT A.MGNR_NUMB, A.USER_IDNT, A.BSCR_IDNT, A.BSCR_NAME, A.BSCR_HPNB, A.BSCR_MAIL, B.COMP_KNAM, B.COMP_LOCN").append(_blank)
				.append("from").append(_blank)
				.append(TABLE_NAME_A).append(" A, ").append(TABLE_NAME_B).append(" B").append(_blank)
				.append("WHERE A.BSCR_IDNT=B.USER_IDNT").append(_blank);
			if(query != null && query.length()>0){
				SQL.append("and (A.BSCR_NAME LIKE '%").append(query).append("%'").append(_blank);
				SQL.append("or B.COMP_KNAM LIKE '%").append(query).append("%')").append(_blank);
			}
			SQL.append("order by A.BSCR_NAME) x)")
				.append("WHERE PNUM=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setInt(index++, NUM_PER_PAGE);
			pstmt.setInt(index++, pageNum);
			
			rs = pstmt.executeQuery();
			result = new HashMap<Integer, Client>();
			
			while(rs.next()){
				Client clnt = new Client();
				clnt.setMgnrNumb(rs.getInt(Client.MGNR_NUMB));
				clnt.setUserIdnt(rs.getString(Client.USER_IDNT));
				clnt.setBscrIdnt(rs.getString(Client.BSCR_IDNT));
				clnt.setBscrName(rs.getString(Client.BSCR_NAME));
				clnt.setBscrHpnb(rs.getString(Client.BSCR_HPNB));
				clnt.setBscrMail(rs.getString(Client.BSCR_MAIL));
				clnt.setCompKnam(rs.getString(Client.COMP_KNAM));
				clnt.setCompLocn(rs.getString(Client.COMP_LOCN));
				result.put(clnt.getMgnrNumb(), clnt);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public int getClientMapCount(String query, int pageNum){
		
		final String TABLE_NAME_A = Get_Property("jumpdb.prefix")+"JK9000"+Get_Property("jumpdb.suffix");
		final String TABLE_NAME_B = Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix");
		
		int							result		=	0;
		Connection					con 		=	null;
		PreparedStatement 			pstmt 		= 	null;
		ResultSet 					rs 			= 	null;
		DBConnection 				DBCon 		= 	new DBConnection();
		StringBuffer 				SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			
			SQL.append("SELECT COUNT(1) FROM").append(_blank)
				.append(TABLE_NAME_A).append(" A,").append(TABLE_NAME_B).append(" B").append(_blank)
				.append("WHERE A.BSCR_IDNT=B.USER_IDNT").append(_blank);
			if(query != null && query.length()>0){
				SQL.append("AND (A.BSCR_NAME LIKE '%").append(query).append("%'").append(_blank)
				.append("or B.COMP_KNAM LIKE '%").append(query).append("%' )").append(_blank);
			}
			SQL.append("order by A.BSCR_NAME");
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				result = rs.getInt(1);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<Client> getClientList(int pageNum){
		final String TABLE_NAME_A = Get_Property("jumpdb.prefix")+"JK9000"+Get_Property("jumpdb.suffix");
		final String TABLE_NAME_B = Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix");
		
		ArrayList<Client>	result		=	null;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT * FROM").append(_blank)
				.append("(SELECT x.*, ceil(rownum/?) as PNUM").append(_blank)
				.append("FROM").append(_blank)
				.append("(SELECT A.MGNR_NUMB, A.USER_IDNT, A.BSCR_IDNT, A.BSCR_NAME, A.BSCR_HPNB, A.BSCR_MAIL, B.COMP_KNAM, B.COMP_LOCN").append(_blank)
				.append("from").append(_blank)
				.append(TABLE_NAME_A).append(" A, ").append(TABLE_NAME_B).append(" B").append(_blank)
				.append("WHERE A.BSCR_IDNT=B.USER_IDNT").append(_blank)
				.append("order by A.BSCR_NAME) x)")
				.append("WHERE PNUM=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setInt(index++, NUM_PER_PAGE);
			pstmt.setInt(index++, pageNum);
			
			rs = pstmt.executeQuery();
			result = new ArrayList<Client>();
			
			while(rs.next()){
				Client clnt = new Client();
				clnt.setMgnrNumb(rs.getInt(Client.MGNR_NUMB));
				clnt.setUserIdnt(rs.getString(Client.USER_IDNT));
				clnt.setBscrIdnt(rs.getString(Client.BSCR_IDNT));
				clnt.setBscrName(rs.getString(Client.BSCR_NAME));
				clnt.setBscrHpnb(rs.getString(Client.BSCR_HPNB));
				clnt.setBscrMail(rs.getString(Client.BSCR_MAIL));
				clnt.setCompKnam(rs.getString(Client.COMP_KNAM));
				clnt.setCompLocn(rs.getString(Client.COMP_LOCN));
				result.add(clnt);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public int getClientCount(){
		final String TABLE_NAME_A = Get_Property("jumpdb.prefix")+"JK9000"+Get_Property("jumpdb.suffix");
		final String TABLE_NAME_B = Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix");
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try {
			con = DBCon.getConnection();

			SQL.append("Select count(1) from ").append(TABLE_NAME_A).append(" A, ").append(TABLE_NAME_B).append(" B WHERE A.BSCR_IDNT=B.USER_IDNT");

			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
			if(con != null) con.rollback();
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
}
