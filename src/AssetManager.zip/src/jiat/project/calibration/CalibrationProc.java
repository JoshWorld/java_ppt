package jiat.project.calibration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.json.JSONObject;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.Calibration;
import jiat.model.Estimate;
import jiat.model.FileInfo;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class CalibrationProc extends Builder {

	
	public int updateCalibration(Calibration calibration){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = updateCalibration(con, calibration);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int updateCalibration(Connection con, Calibration calibration){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update JF5300 set ")
				.append(Calibration.STRT_DATE_TAG).append("= ?, ")
				.append(Calibration.ENDS_DATE_TAG).append("= ?, ")
				.append(Calibration.COMP_NAME_TAG).append("= ?, ")
				.append(Calibration.MONY_TOTL_TAG).append("= ?, ")
				.append(Calibration.RMRK_NOTE_TAG).append("= ?, ")
				.append(Calibration.UPDT_DATE_TAG).append("=? ")
				.append(" where OPPR_CODE = ?");
			
			int index =1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, calibration.getStrtDate());
			pstmt.setString(index++, calibration.getEndsDate());
			pstmt.setString(index++, calibration.getCompName());
			pstmt.setInt(index++, calibration.getMonyTotl());
			pstmt.setString(index++, calibration.getRmrkNote());
			
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-mm-dd");
	        java.util.Calendar cal = java.util.Calendar.getInstance();
	        String strToday = sdf.format(cal.getTime());
			pstmt.setString(index++, strToday);
			
			pstmt.setInt(index++, calibration.getOpprCode());
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	
	public Calibration getCalibration(int opprCode){
		Calibration result = null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getCalibration(con, opprCode);
		}catch(Exception e) {
			Show_Err("01. Get_Calibration_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private Calibration getCalibration(Connection con, int opprCode){
		Calibration 			result 		= 	null;	
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM JF5300 WHERE OPPR_CODE = ?");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, opprCode);
			rs = pstmt.executeQuery();
			
			result = new Calibration();
			java.text.SimpleDateFormat sdfCurrent = new java.text.SimpleDateFormat ("yyyy-mm-dd");

			while(rs.next()){
				result.setOpprCode(rs.getInt(Calibration.OPPR_CODE_TAG));
				result.setOpprNumb(rs.getString(Calibration.OPPR_NUMB_TAG));
				result.setJasnCode(rs.getInt(Calibration.JASN_CODE_TAG));
				//result.setStrtDate(sdfCurrent.format(rs.getTimestamp(Calibration.STRT_DATE_TAG)));
				//result.setEndsDate(sdfCurrent.format(rs.getTimestamp(Calibration.ENDS_DATE_TAG)));
				result.setStrtDate(rs.getString(Calibration.STRT_DATE_TAG));
				result.setEndsDate(rs.getString(Calibration.ENDS_DATE_TAG));
				result.setCompName(rs.getString(Calibration.COMP_NAME_TAG));
				result.setMonyTotl(rs.getInt(Calibration.MONY_TOTL_TAG));
				result.setRmrkNote(rs.getString(Calibration.RMRK_NOTE_TAG));
				result.setWrteIdnt(rs.getString(Calibration.WRTE_IDNT_TAG));
				//result.setWrteDate(sdfCurrent.format(rs.getTimestamp(Calibration.WRTE_DATE_TAG)));
				//result.setUpdtDate(sdfCurrent.format(rs.getTimestamp(Calibration.UPDT_DATE_TAG)));
				result.setWrteDate(rs.getString(Calibration.WRTE_DATE_TAG));
				result.setUpdtDate(rs.getString(Calibration.UPDT_DATE_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	public ArrayList<Calibration> getCalibrations(int jasnCode){
		ArrayList<Calibration>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getCalibrations(con, jasnCode);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	private ArrayList<Calibration> getCalibrations(Connection con, int jasnCode){
		ArrayList<Calibration> list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM JF5300 WHERE ")
				.append("JASN_CODE")
				.append("=? ")
				.append("order by OPPR_CODE desc");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, jasnCode);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Calibration>();
			java.text.SimpleDateFormat sdfCurrent = new java.text.SimpleDateFormat ("yyyy-mm-dd");
			
			while(rs.next()){
				Calibration calibration = new Calibration();
				calibration.setOpprCode(rs.getInt(Calibration.OPPR_CODE_TAG));
				calibration.setOpprNumb(rs.getString(Calibration.OPPR_NUMB_TAG));
				calibration.setJasnCode(rs.getInt(Calibration.JASN_CODE_TAG));
				//calibration.setStrtDate(sdfCurrent.format(rs.getTimestamp(Calibration.STRT_DATE_TAG)));
				//calibration.setEndsDate(sdfCurrent.format(rs.getTimestamp(Calibration.ENDS_DATE_TAG)));
				calibration.setStrtDate(rs.getString(Calibration.STRT_DATE_TAG));
				calibration.setEndsDate(rs.getString(Calibration.ENDS_DATE_TAG));
				calibration.setCompName(rs.getString(Calibration.COMP_NAME_TAG));
				calibration.setMonyTotl(rs.getInt(Calibration.MONY_TOTL_TAG));
				calibration.setRmrkNote(rs.getString(Calibration.RMRK_NOTE_TAG));
				calibration.setWrteIdnt(rs.getString(Calibration.WRTE_IDNT_TAG));
				//calibration.setWrteDate(sdfCurrent.format(rs.getTimestamp(Calibration.WRTE_DATE_TAG)));
				//calibration.setUpdtDate(sdfCurrent.format(rs.getTimestamp(Calibration.UPDT_DATE_TAG)));
				calibration.setWrteDate(rs.getString(Calibration.WRTE_DATE_TAG));
				calibration.setUpdtDate(rs.getString(Calibration.UPDT_DATE_TAG));
				
				list.add(calibration);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	
	public int addCalibration(HttpServletRequest request,Calibration calibration){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO JF5300 ( JASN_CODE, STRT_DATE, ENDS_DATE, COMP_NAME,MONY_TOTL,RMRK_NOTE,WRTE_IDNT,WRTE_DATE,UPDT_DATE) ");
			SQL.append("VALUES(?,?,?,?,?,?,?,?,?)");
			
			int index=1;
			String cols[] = {"OPPR_CODE"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			
			//pstmt.setString(index++, calibration.getOpprNumb());
			pstmt.setInt(index++, calibration.getJasnCode());
			
			pstmt.setString(index++, calibration.getStrtDate());
			pstmt.setString(index++, calibration.getEndsDate());
			pstmt.setString(index++, calibration.getCompName());
			
			pstmt.setInt(index++, calibration.getMonyTotl());
			
			pstmt.setString(index++, calibration.getRmrkNote());
			
			HttpSession session = request.getSession();
			pstmt.setString(index++, (String)session.getAttribute("USER_NAME"));
			
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-mm-dd");
	        java.util.Calendar cal = java.util.Calendar.getInstance();
	        String strToday = sdf.format(cal.getTime());
			pstmt.setString(index++, strToday);
			
			pstmt.setString(index++, null);
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	
	public int deleteCalibration(int opprCode){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = deleteCalibration(con, opprCode);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int deleteCalibration(Connection con, int opprCode){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("delete from JF5300 where OPPR_CODE = ?");
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, opprCode);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
}
