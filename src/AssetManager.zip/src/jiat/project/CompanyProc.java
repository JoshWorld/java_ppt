package jiat.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedList;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.Company;

public class CompanyProc extends Builder {
	String TABLE_NAME;
	
	public CompanyProc(){
		TABLE_NAME = Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix");
	}
	public int getTotal(){
		int			result	=	0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			SQL.append("Select count(USER_IDNT) from ").append(TABLE_NAME);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	public int getTotal(String search){
		int			result	=	0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			SQL.append("Select count(USER_IDNT) from ").append(TABLE_NAME).append(' ')
				.append("WHERE COMP_KNAM like \'%").append(search).append("%\'");
			
//			logger.info(SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	// 업체목록 가져오기 
	public LinkedList getCompanyList(){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, COMP_KNAM, PRSN_NAME, COMP_LOCN, COMP_PHON ");
			
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("WHERE ROWNUM <= ?");
			// Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter 		result 		= 	new ClassParameter();
    			result.setString("USER_IDNT",rs.getString("USER_IDNT")); //업체코드	
    			result.setString("COMP_KNAM",rs.getString("COMP_KNAM")); //업체명
    			result.setString("PRSN_NAME",rs.getString("PRSN_NAME")); //담당자
    			result.setString("COMP_LOCN",rs.getString("COMP_LOCN")); //도내,도외구분
    			result.setString("COMP_PHON",rs.getString("COMP_PHON")); //전화번호
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}
	// 업체목록 가져오기 (페이징 버젼)
	public LinkedList getCompanyList(int from, int to){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();
//		logger.info("from: "+ from +" /to: " + to);
		try {
			con = DBCon.getConnection();
			SQL.append("SELECT * FROM(");
			SQL.append("SELECT ROWNUM as rnum, USER_IDNT, COMP_KNAM, PRSN_NAME, COMP_LOCN, COMP_PHON ");
			SQL.append("FROM ");
			SQL.append(TABLE_NAME).append(')')
//				.append("order by USER_IDNT)").append(' ')
				.append("WHERE rnum >=?").append(' ')
				.append("and rnum <=?");
			
			int index = 1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, from);
			pstmt.setInt(index++, to);
			
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter 		result 		= 	new ClassParameter();
    			result.setString("USER_IDNT",rs.getString("USER_IDNT")); //업체코드	
    			result.setString("COMP_KNAM",rs.getString("COMP_KNAM")); //업체명
    			result.setString("PRSN_NAME",rs.getString("PRSN_NAME")); //담당자
    			result.setString("COMP_LOCN",rs.getString("COMP_LOCN")); //도내,도외구분
    			result.setString("COMP_PHON",rs.getString("COMP_PHON")); //전화번호
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}
	// 업체목록 가져오기 (페이징 버젼)
		public LinkedList getCompanyList(String search, int from, int to){
			Connection			con 		=	null;
			PreparedStatement 	pstmt 		= 	null;
			ResultSet 			rs 			= 	null;
			DBConnection 		DBCon 		= 	new DBConnection();
			StringBuffer 		SQL 		= 	new StringBuffer();
			LinkedList 			list 		= 	new LinkedList();
			try {
				con = DBCon.getConnection();
				SQL.append("SELECT * FROM(");
				SQL.append("SELECT ROWNUM as rnum, USER_IDNT, COMP_KNAM, PRSN_NAME, COMP_LOCN, COMP_PHON ");
				SQL.append("FROM ");
				SQL.append(TABLE_NAME).append(' ').append("WHERE COMP_KNAM like \'%").append(search).append("%\')").append(' ')
					.append("WHERE rnum >=?").append(' ')
					.append("and rnum <=?");
				
				int index = 1;
				
				pstmt = con.prepareStatement(SQL.toString());
				pstmt.setInt(index++, from);
				pstmt.setInt(index++, to);
				
	    		rs = pstmt.executeQuery();
				
	    		while(rs.next()) {
	    			ClassParameter 		result 		= 	new ClassParameter();
	    			result.setString("USER_IDNT",rs.getString("USER_IDNT")); //업체코드	
	    			result.setString("COMP_KNAM",rs.getString("COMP_KNAM")); //업체명
	    			result.setString("PRSN_NAME",rs.getString("PRSN_NAME")); //담당자
	    			result.setString("COMP_LOCN",rs.getString("COMP_LOCN")); //도내,도외구분
	    			result.setString("COMP_PHON",rs.getString("COMP_PHON")); //전화번호
	    			list.add(result);
	    		}
			} catch(Exception e) {
//				Show_Err("getPartList:"+e.toString());
				e.printStackTrace();
			} finally {
				Close_RS(rs);
				Close_PS(pstmt);
				Close_Con(con);
				return list;
			}
		}
	// 업체목록 가져오기 
	public LinkedList getCompanyList(String query) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, COMP_KNAM, PRSN_NAME, COMP_LOCN, COMP_PHON ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("WHERE COMP_KNAM like '%").append(query).append("%'");
			
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter 		result 		= 	new ClassParameter();
    			result.setString("USER_IDNT",rs.getString("USER_IDNT")); //업체코드	
    			result.setString("COMP_KNAM",rs.getString("COMP_KNAM")); //업체명
    			result.setString("PRSN_NAME",rs.getString("PRSN_NAME")); //담당자
    			result.setString("COMP_LOCN",rs.getString("COMP_LOCN")); //도내,도외구분
    			result.setString("COMP_PHON",rs.getString("COMP_PHON")); //전화번호
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}
	// 업체목록 가져오기 
	public HashMap<String, Company> getCompanyHashMap() {
		Connection					con 		=	null;
		PreparedStatement 			pstmt 		= 	null;
		ResultSet 					rs 			= 	null;
		DBConnection 				DBCon 		= 	new DBConnection();
		StringBuffer 				SQL 		= 	new StringBuffer();
		HashMap<String, Company> 	result 		= 	new HashMap<String, Company>();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, COMP_KNAM, PRSN_NAME, COMP_LOCN, COMP_PHON ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JA3000_VIEW"+Get_Property("jumpdb.suffix")+" ");
//			Show_Msg("getPartList:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			Company company = new Company();
    			company.setUserIdnt(rs.getString("USER_IDNT"));
    			company.setKname(rs.getString("COMP_KNAM"));
    			company.setPresidentName(rs.getString("PRSN_NAME"));
    			company.setLocation(rs.getString("COMP_LOCN"));
    			company.setPhone(rs.getString("COMP_PHON"));
    			result.put(company.getUserIdnt(), company);
    		}
		} catch(Exception e) {
			Show_Err("getPartList:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
}