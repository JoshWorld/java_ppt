package jiat.project.file;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.FileInfo;

public class FileProc extends Builder{

	public int addFile(FileInfo fileInfo){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		try {
			SQL.append("INSERT INTO T_FILE (C_NUM, NAME, FNAME, TYPE, P_NUM)");
			SQL.append("VALUES (?,?,?,?,?)");
			
			con = DBCon.getConnection();
			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, fileInfo.getcNum());
			pstmt.setString(index++, fileInfo.getName());
			pstmt.setString(index++, fileInfo.getfName());
			pstmt.setInt(index++, 0);
			pstmt.setInt(index, fileInfo.getpNum());
			pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public int addFiles(ArrayList<FileInfo> fileInfos){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		try {
			SQL.append("INSERT INTO T_FILE (C_NUM, NAME, FNAME, TYPE, P_NUM)");
			SQL.append("VALUES (?,?,?,?,?)");
			
			con = DBCon.getConnection();
			for(FileInfo file: fileInfos){
				int index=1;
				pstmt = con.prepareStatement(SQL.toString());
				pstmt.setInt(index++, file.getcNum());
				pstmt.setString(index++, file.getName());
				pstmt.setString(index++, file.getfName());
				pstmt.setInt(index++, 0);
				pstmt.setInt(index, file.getpNum());
				pstmt.executeUpdate();
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	public int addFilesForTax(ArrayList<FileInfo> fileInfos){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		try {
			SQL.append("INSERT INTO T_FILE_TAX (C_NUM, NAME, FNAME, TYPE, P_NUM)");
			SQL.append("VALUES (?,?,?,?,?)");
			
			con = DBCon.getConnection();
			for(FileInfo file: fileInfos){
				int index=1;
				pstmt = con.prepareStatement(SQL.toString());
				pstmt.setInt(index++, file.getcNum());
				pstmt.setString(index++, file.getName());
				pstmt.setString(index++, file.getfName());
				pstmt.setInt(index++, 0);
				pstmt.setInt(index, file.getpNum());
				pstmt.executeUpdate();
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	
	public int addFiles(String[] files, int cNum){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		try {
			SQL.append("INSERT INTO T_FILE (C_NUM, NAME)");
			SQL.append("VALUES (?,?)");
			
			con = DBCon.getConnection();
			for(String file: files){
				int index=1;
				pstmt = con.prepareStatement(SQL.toString());
				pstmt.setInt(index++, cNum);
				pstmt.setString(index++, file);
				pstmt.executeUpdate();
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<FileInfo> getFileInfo(int cNum){
		ArrayList<FileInfo>	fileInfo	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			fileInfo = getFileInfos(con, cNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return fileInfo;
  		}
	}
	private ArrayList<FileInfo> getFileInfos(Connection con, int cNum){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<FileInfo>	result		= 	null;
		try{
			SQL.append("SELECT * FROM T_FILE WHERE C_NUM = ?");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, cNum);
			
			rs = pstmt.executeQuery();
			result=	new ArrayList<FileInfo>();
			while(rs.next()){
				FileInfo fileInfo = new FileInfo();
				
				fileInfo.setInx(rs.getInt(FileInfo.INX_TAG));
				fileInfo.setpNum(rs.getInt(FileInfo.PNUM_TAG));
				fileInfo.setType(rs.getInt(FileInfo.TYPE_TAG));
				fileInfo.setcNum(rs.getInt(FileInfo.CNUM_TAG));
				fileInfo.setName(rs.getString(FileInfo.NAME_TAG));
				fileInfo.setfName(rs.getString(FileInfo.FNAME_TAG));
				
				result.add(fileInfo);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public ArrayList<FileInfo> getTaxFileInfo(int pNum, int tNum){
		ArrayList<FileInfo>	fileInfo	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			fileInfo = getTaxFileInfo(con, pNum, tNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return fileInfo;
  		}
	}
	private ArrayList<FileInfo> getTaxFileInfo(Connection con, int pNum, int tNum){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<FileInfo>	result		= 	null;
		try{
			SQL.append("SELECT * FROM T_FILE_TAX WHERE P_NUM = ? and C_NUM=? ORDER BY INX DESC");
			pstmt 	= con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setInt(index++, pNum);
			pstmt.setInt(index++, tNum);
			
			rs = pstmt.executeQuery();
			result=	new ArrayList<FileInfo>();
			while(rs.next()){
				FileInfo fileInfo = new FileInfo();
				
				fileInfo.setInx(rs.getInt(FileInfo.INX_TAG));
				fileInfo.setpNum(rs.getInt(FileInfo.PNUM_TAG));
				fileInfo.setType(rs.getInt(FileInfo.TYPE_TAG));
				fileInfo.setcNum(rs.getInt(FileInfo.CNUM_TAG));
				fileInfo.setName(rs.getString(FileInfo.NAME_TAG));
				fileInfo.setfName(rs.getString(FileInfo.FNAME_TAG));
				
				result.add(fileInfo);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public ArrayList<FileInfo> getFileInfo2(int pNum){
		ArrayList<FileInfo>	fileInfo	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			fileInfo = getFileInfos2(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return fileInfo;
  		}
	}
	private ArrayList<FileInfo> getFileInfos2(Connection con, int pNum){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<FileInfo>	result		= 	null;
		try{
			SQL.append("SELECT * FROM T_FILE WHERE P_NUM = ? ORDER BY C_NUM DESC");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			result=	new ArrayList<FileInfo>();
			while(rs.next()){
				FileInfo fileInfo = new FileInfo();
				
				fileInfo.setInx(rs.getInt(FileInfo.INX_TAG));
				fileInfo.setpNum(rs.getInt(FileInfo.PNUM_TAG));
				fileInfo.setType(rs.getInt(FileInfo.TYPE_TAG));
				fileInfo.setcNum(rs.getInt(FileInfo.CNUM_TAG));
				fileInfo.setName(rs.getString(FileInfo.NAME_TAG));
				fileInfo.setfName(rs.getString(FileInfo.FNAME_TAG));
				
				result.add(fileInfo);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public ArrayList<FileInfo> getContractFiles(ClassParameter param){
		ArrayList<FileInfo> result 		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int pNum = param.getInt("p_num");
		try {
			con = DBCon.getConnection();
			result = getContractFiles(con, pNum);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	
	private ArrayList<Integer> getContractIds(Connection con, int pNum){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<Integer>  result		=	null;
		try{
			result =	new ArrayList<Integer>();
			
			SQL.append("SELECT INX FROM T_CONTRACT WHERE P_NUM = ?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			while(rs.next()){
				result.add(rs.getInt(INX_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	private ArrayList<FileInfo> getContractFiles(Connection con, int pNum){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<FileInfo>	result		=	null;
		try{
			result =	new ArrayList<FileInfo>();
			ArrayList<Integer> cNums = getContractIds(con, pNum);
			
			SQL.append("SELECT * FROM T_FILE WHERE");
			
			for(int i=0; i<cNums.size(); i++){
				if(i == (cNums.size()-1)){
					SQL.append(" C_NUM="+ cNums.get(i));
				}else{
					SQL.append(" C_NUM=" + cNums.get(i) +" OR");
				}
			}
			
			pstmt = con.prepareStatement(SQL.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				FileInfo fileInfo = new FileInfo();
				
				fileInfo.setInx(rs.getInt(FileInfo.INX_TAG));
				fileInfo.setpNum(rs.getInt(FileInfo.PNUM_TAG));
				fileInfo.setType(rs.getInt(FileInfo.TYPE_TAG));
				fileInfo.setcNum(rs.getInt(FileInfo.CNUM_TAG));
				fileInfo.setName(rs.getString(FileInfo.NAME_TAG));
				fileInfo.setfName(rs.getString(FileInfo.FNAME_TAG));
				
				result.add(fileInfo);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public FileInfo getFile(int fNum){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		FileInfo				result		=	new FileInfo();
		try {
			con = DBCon.getConnection();
			result = getFile(con, fNum);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private FileInfo getFile(Connection con, int fNum){
		FileInfo				result		=	null;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("select * from T_FILE where INX = ?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, fNum);
			rs = pstmt.executeQuery();
			
			result = new FileInfo();
			while(rs.next()){
				result = FileInfo.resultSetToFileInfo(rs);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	public int deleteFile(int fNum){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = deleteFile(con, fNum);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int deleteFile(Connection con, int fNum){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("delete from T_FILE where INX = ?");
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, fNum);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
}
