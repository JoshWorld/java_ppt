package jiat.project.budget;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.Estimate;
import jiat.model.Project;

public class BudgetProc extends Builder{
	private final String TABLE_NAME = "T_ESTIMATE";
	
	public int updateProject(ClassParameter search){
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int					result 		= 	0;
		try {
			Estimate estim = Estimate.parseEstimate(search);
			con = DBCon.getConnection();
			result = updateProject(con, estim);		
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
		}
	}
	private int updateProject(Connection con, Estimate estim){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update ")
			.append(TABLE_NAME)
			.append(" set ").append(Estimate.NUM_TAG).append("=?")
			.append(" where ").append(Estimate.INX_TAG).append("=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			pstmt.setString(index++, estim.getNum());
			pstmt.setInt(index++, estim.getInx());		
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
}
