package jiat.project.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Logger;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.User;

public class UserProc extends Builder {
	private final String 			TABLE_NAME;
	private final Logger 			logger;
	private final DBConnection 		DBCon;
	private final char 				_blank			=		' ';
	public static final int			NUM_PER_PAGE	=		20;
	
	public UserProc(){
		DBCon 		= 	new DBConnection();
		logger = Logger.getLogger(this.getClass().getSimpleName());
		TABLE_NAME = Get_Property("jumpdb.prefix")+"JA4000_VIEW"+Get_Property("jumpdb.suffix");
	}
	public ArrayList<String> getRootUsersIDNT(){
		ArrayList<String> 	result		=	null;
		Connection			con 		=	null;
		try{
			con = DBCon.getConnection();
			result = getRootUsersIdnt(con);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<User> getRootUser(){
		ArrayList<User> 	result		=	null;
		Connection			con 		=	null;
		try{
			con = DBCon.getConnection();
			result = getRootUserList(con);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_Con(con);
			return result;
		}
	}
	public void addRootUser(User user){
		Connection			con 		=	null;
		try{
			con = DBCon.getConnection();
			addRootUser(user, con);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_Con(con);
		}
	}
	private void addRootUser(User user, Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			SQL.append("INSERT INTO T_ROOT_USER (USER_IDNT, USER_KNAM) VALUES (?,?)");
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setString(index++, user.getUserIdnt());
			pstmt.setString(index++, user.getkName());
			pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
		}
	}
	private ArrayList<User> getRootUserList(Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<User> 	result		=	null;
		try {
			
			SQL.append("SELECT* FROM T_ROOT_USER");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			rs = pstmt.executeQuery();
			
			result = new ArrayList<User>();
			while(rs.next()){
				User user = new User();
				user.setUserIdnt(rs.getString(User.USER_IDNT));
				user.setkName(rs.getString(User.USER_KNAM));
				result.add(user);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	private ArrayList<String> getRootUsersIdnt(Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<String> 	result		=	null;
		try {
			
			SQL.append("SELECT* FROM T_ROOT_USER");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			rs = pstmt.executeQuery();
			
			result = new ArrayList<String>();
			while(rs.next()){
				result.add(rs.getString(User.USER_IDNT));
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	public ArrayList<User> getUpperUsers(String partCode){
		final String PART_TABLE = Get_Property("jumpdb.prefix")+"JA8000_VIEW"+Get_Property("jumpdb.suffix");
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<User>		result 		= 	new ArrayList<User>();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, USER_LOID, USER_KNAM, PART_CODE, PART_NAME, DUTY_CODE, DUTY_NAME ").append(_blank)
				.append("FROM "+TABLE_NAME+" ").append(_blank)
				.append("WHERE DUTY_CODE IN('81','221','281') AND RETR_FLAG='N' AND ").append(_blank)
				.append("(PART_CODE=41 ").append(_blank)
				.append("OR PART_CODE=?").append(_blank)
				.append("OR PART_CODE IN ").append(_blank)
				.append("(SELECT UPPR_PART FROM").append(_blank)
				.append(PART_TABLE).append(_blank)
				.append("WHERE PART_CODE=?))");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, partCode);
			pstmt.setString(2, partCode);	
			rs = pstmt.executeQuery();

			while(rs.next()) {
				User user = new User();
				user.setUserIdnt(rs.getString("USER_IDNT")); 	//식별번호	
				user.setUserLoid(rs.getString("USER_LOID")); 	//아이디	
				user.setkName(rs.getString("USER_KNAM")); 		//성명
				user.setPartCode(rs.getString("PART_CODE")); 	//부서코드
				user.setPartName(rs.getString("PART_NAME")); 	//부서명
				user.setDutyCode(rs.getString("DUTY_CODE")); 	//직책코드
				user.setDutyName(rs.getString("DUTY_NAME")); 	//직책명
				
				result.add(user);
			}
		} catch(Exception e) {
//			Show_Err("getMember:"+e.toString());
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	// 회원정보 가져오기 
	public User getUser(String ID) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		User		 		result 		= 	new User();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, USER_LOID, USER_LOPW, USER_KNAM, PART_CODE, PART_NAME, DUTY_CODE, DUTY_NAME ");
			SQL.append("FROM "+TABLE_NAME+" ");
			SQL.append("WHERE RETR_FLAG='N' AND USER_IDNT=?");
//			Show_Msg("getMember:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, ID);		
			rs = pstmt.executeQuery();

			if(rs.next()) {
				result.setUserIdnt(rs.getString("USER_IDNT")); //식별번호	
				result.setUserLoid(rs.getString("USER_LOID")); //아이디	
				result.setUserLopw(rs.getString("USER_LOPW")); //비밀번호
				result.setkName(rs.getString("USER_KNAM")); //성명
				result.setPartCode(rs.getString("PART_CODE")); //부서코드
				result.setPartName(rs.getString("PART_NAME")); //부서명
				result.setDutyCode(rs.getString("DUTY_CODE")); //직책코드
				result.setDutyName(rs.getString("DUTY_NAME")); //직책명
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}	
	// 회원정보 가져오기 
	public ClassParameter getMember(String ID) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT USER_IDNT, USER_LOID, USER_LOPW, USER_KNAM, PART_CODE, PART_NAME, DUTY_CODE, DUTY_NAME ");
			SQL.append("FROM "+TABLE_NAME+" ");
			SQL.append("WHERE RETR_FLAG='N' AND USER_LOID=?");
			Show_Msg("getMember:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, ID);		
			rs = pstmt.executeQuery();

			if(rs.next()) {
				result.setString("USER_IDNT",rs.getString("USER_IDNT")); //식별번호	
				result.setString("USER_LOID",rs.getString("USER_LOID")); //아이디	
				result.setString("USER_LOPW",rs.getString("USER_LOPW")); //비밀번호
				result.setString("USER_KNAM",rs.getString("USER_KNAM")); //성명
				result.setString("PART_CODE",rs.getString("PART_CODE")); //부서코드
				result.setString("PART_NAME",rs.getString("PART_NAME")); //부서명
				result.setString("DUTY_CODE",rs.getString("DUTY_CODE")); //직책코드
				result.setString("DUTY_NAME",rs.getString("DUTY_NAME")); //직책명
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<User> getUserList(int pageNum, String search){
		ArrayList<User> 	result		=	null;
		Connection			con 		=	null;
		try{
			con = DBCon.getConnection();
			result = getUserList(pageNum, con, search);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_Con(con);
			return result;
		}
	}
	public ArrayList<User> getUserList(int pageNum){
		ArrayList<User> 	result		=	null;
		Connection			con 		=	null;
		try{
			con = DBCon.getConnection();
			result = getUserList(pageNum, con);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			Close_Con(con);
			return result;
		}
	}
	private ArrayList<User> getUserList(int pageNum, Connection con, String search){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<User> 	result		=	null;
		try {
			SQL.append("SELECT* FROM(SELECT x.*, CEIL(rownum/?) AS PNUM FROM (SELECT * FROM").append(_blank)
				.append(TABLE_NAME).append(_blank).append("WHERE").append(_blank)
				.append("USER_KNAM like").append(_blank)
				.append("'%").append(search).append("%'")
				.append(" order by USER_IDNT)x ) WHERE PNUM=?");
				
			
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setInt(index++, NUM_PER_PAGE);
			pstmt.setInt(index++, pageNum);
			
			rs = pstmt.executeQuery();
			
			result = new ArrayList<User>();
			while(rs.next()){
				User user = new User();
				user.setUserIdnt(rs.getString(User.USER_IDNT));
				user.setkName(rs.getString(User.USER_KNAM));
				user.setPartName(rs.getString(User.PART_NAME));
				user.setPartCode(rs.getString(User.PART_CODE));
				user.setUserHpno(rs.getString(User.USER_HPNO));
				user.setUserMail(rs.getString(User.USER_MAIL));
				result.add(user);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	private ArrayList<User> getUserList(int pageNum, Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ArrayList<User> 	result		=	null;
		try {
			
			SQL.append("SELECT* FROM(SELECT x.*, CEIL(rownum/?) AS PNUM FROM (SELECT * FROM").append(_blank)
				.append(TABLE_NAME).append(_blank)
				.append(" order by USER_IDNT)x ) WHERE PNUM=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setInt(index++, NUM_PER_PAGE);
			pstmt.setInt(index++, pageNum);
			
			rs = pstmt.executeQuery();
			
			result = new ArrayList<User>();
			while(rs.next()){
				User user = new User();
				user.setUserIdnt(rs.getString(User.USER_IDNT));
				user.setkName(rs.getString(User.USER_KNAM));
				user.setPartName(rs.getString(User.PART_NAME));
				user.setPartCode(rs.getString(User.PART_CODE));
				user.setUserHpno(rs.getString(User.USER_HPNO));
				user.setUserMail(rs.getString(User.USER_MAIL));
				result.add(user);
			}
		} catch(Exception e) {
			Show_Err("getMember:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	public int getUserCount(){
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select count(USER_IDNT) from ").append(TABLE_NAME);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	public int getUserCount(String search){
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select count(USER_IDNT) from ").append(TABLE_NAME).append(_blank)
				.append("WHERE USER_KNAM like").append(_blank)
				.append("'%").append(search).append("%'");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
}
