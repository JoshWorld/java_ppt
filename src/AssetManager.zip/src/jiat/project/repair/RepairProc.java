package jiat.project.repair;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import org.json.JSONObject;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.Repair;
import jiat.model.Estimate;
import jiat.model.FileInfo;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;



public class RepairProc extends Builder {

	
	public int updateRepair(Repair repair){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = updateRepair(con, repair);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int updateRepair(Connection con, Repair repair){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("update JF5200 set ")
				.append(Repair.WORK_DATE_TAG).append("= ?, ")
				.append(Repair.PEPR_BODY_TAG).append("= ?, ")
				.append(Repair.CNFM_USER_TAG).append("= ?, ")
				.append(Repair.COST_MONY_TAG).append("= ?, ")
				.append(Repair.RMRK_NOTE_TAG).append("= ?, ")
				.append(Repair.UPDT_DATE_TAG).append("=? ")
				.append(" where REPR_NUMB = ?");
			
			int index =1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, repair.getWorkDate());
			pstmt.setString(index++, repair.getPeprBody());
			pstmt.setString(index++, repair.getCnfmUser());
			pstmt.setInt(index++, repair.getCostMony());
			pstmt.setString(index++, repair.getRmrkNote());
			
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-mm-dd");
	        java.util.Calendar cal = java.util.Calendar.getInstance();
	        String strToday = sdf.format(cal.getTime());
			pstmt.setString(index++, strToday);
			
			pstmt.setInt(index++, repair.getReprNumb());
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	
	
	public Repair getRepair(int reprNumb){
		Repair result = null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			result = getRepair(con, reprNumb);
		}catch(Exception e) {
			Show_Err("01. Get_Repair_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private Repair getRepair(Connection con, int reprNumb){
		Repair 			result 		= 	null;	
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM JF5200 WHERE REPR_NUMB = ?");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, reprNumb);
			rs = pstmt.executeQuery();
//			logger.info(SQL.toString() +" / reprNumb");
			result = new Repair();
			java.text.SimpleDateFormat sdfCurrent = new java.text.SimpleDateFormat ("yyyy-mm-dd");

			while(rs.next()){
				result.setReprNumb(rs.getInt(Repair.REPR_NUMB_TAG));
				result.setPeprCode(rs.getString(Repair.PEPR_CODE_TAG));
				result.setJasnCode(rs.getInt(Repair.JASN_CODE_TAG));
				//result.setWorkDate(sdfCurrent.format(rs.getTimestamp(Repair.WORK_DATE_TAG)));
				result.setWorkDate(rs.getString(Repair.WORK_DATE_TAG));
				result.setPeprBody(rs.getString(Repair.PEPR_BODY_TAG));
				result.setCnfmUser(rs.getString(Repair.CNFM_USER_TAG));
				result.setCostMony(rs.getInt(Repair.COST_MONY_TAG));
				result.setRmrkNote(rs.getString(Repair.RMRK_NOTE_TAG));
				result.setWrteIdnt(rs.getString(Repair.WRTE_IDNT_TAG));
				//result.setWrteDate(sdfCurrent.format(rs.getTimestamp(Repair.WRTE_DATE_TAG)));
				//result.setUpdtDate(sdfCurrent.format(rs.getTimestamp(Repair.UPDT_DATE_TAG)));
				result.setWrteDate(rs.getString(Repair.WRTE_DATE_TAG));
				result.setUpdtDate(rs.getString(Repair.UPDT_DATE_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	public ArrayList<Repair> getRepairs(int jasnCode){
		ArrayList<Repair>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getRepairs(con, jasnCode);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	private ArrayList<Repair> getRepairs(Connection con, int jasnCode){
		ArrayList<Repair> list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM JF5200 WHERE ")
				.append("JASN_CODE")
				.append("=? ")
				.append("order by REPR_NUMB desc");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, jasnCode);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Repair>();
			java.text.SimpleDateFormat sdfCurrent = new java.text.SimpleDateFormat ("yyyy-mm-dd");
			
			while(rs.next()){
				Repair repair = new Repair();
				
				repair.setReprNumb(rs.getInt(Repair.REPR_NUMB_TAG));
				repair.setPeprCode(rs.getString(Repair.PEPR_CODE_TAG));
				repair.setJasnCode(rs.getInt(Repair.JASN_CODE_TAG));
				//repair.setWorkDate(sdfCurrent.format(rs.getTimestamp(Repair.WORK_DATE_TAG)));
				repair.setWorkDate(rs.getString(Repair.WORK_DATE_TAG));
				repair.setPeprBody(rs.getString(Repair.PEPR_BODY_TAG));
				repair.setCnfmUser(rs.getString(Repair.CNFM_USER_TAG));
				repair.setCostMony(rs.getInt(Repair.COST_MONY_TAG));
				repair.setRmrkNote(rs.getString(Repair.RMRK_NOTE_TAG));
				repair.setWrteIdnt(rs.getString(Repair.WRTE_IDNT_TAG));
				//repair.setWrteDate(sdfCurrent.format(rs.getTimestamp(Repair.WRTE_DATE_TAG)));
				//repair.setUpdtDate(sdfCurrent.format(rs.getTimestamp(Repair.UPDT_DATE_TAG)));
				repair.setWrteDate(rs.getString(Repair.WRTE_DATE_TAG));
				repair.setUpdtDate(rs.getString(Repair.UPDT_DATE_TAG));
				
				list.add(repair);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	
	public int addRepair(HttpServletRequest request,Repair repair){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		
		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO JF5200 (JASN_CODE, WORK_DATE, PEPR_BODY,CNFM_USER,COST_MONY,RMRK_NOTE,WRTE_IDNT,WRTE_DATE,UPDT_DATE) ");
			SQL.append("VALUES(?,?,?,?,?,?,?,?,?)");
			
			int index=1;
			String cols[] = {"REPR_NUMB"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			
			//pstmt.setString(index++, repair.getPeprCode());
			pstmt.setInt(index++, repair.getJasnCode());
			
			pstmt.setString(index++, repair.getWorkDate());
			pstmt.setString(index++, repair.getPeprBody());
			pstmt.setString(index++, repair.getCnfmUser());
			
			pstmt.setInt(index++, repair.getCostMony());
			
			pstmt.setString(index++, repair.getRmrkNote());
			
			HttpSession session = request.getSession();
						
			pstmt.setString(index++, (String)session.getAttribute("USER_NAME"));
			
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-mm-dd");
	        java.util.Calendar cal = java.util.Calendar.getInstance();
	        String strToday = sdf.format(cal.getTime());
			pstmt.setString(index++, strToday);
			
			pstmt.setString(index++, null);
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	
	
	public int deleteRepair(int reprNumb){
		Connection				con 		=	null;
		DBConnection 			DBCon 		= 	new DBConnection();
		int						result		=	-1;
		try {
			con = DBCon.getConnection();
			result = deleteRepair(con, reprNumb);
		}catch(Exception e) {
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private int deleteRepair(Connection con, int reprNumb){
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		try{
			SQL.append("delete from JF5200 where REPR_NUMB = ?");
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, reprNumb);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
}
