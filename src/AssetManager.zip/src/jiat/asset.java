package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import org.json.JSONObject;

import builder.*;
import builder.web.*;
import builder.database.*;

public class asset extends Builder {
	private final String TABLE_NAME = Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix");
	public static final int NUM_PER_PAGE = 20;
	private HashMap<String,String> stateMap;
	
	public asset(){
		stateMap = new HashMap<String,String>();
		stateMap.put("T", "임시저장");
		stateMap.put("P", "결재대기");
		stateMap.put("F", "결재완료");
		stateMap.put("N", "미등록");
	}
	public String Search_String(ClassParameter pRow) { 
		String rtn = "";
		if(!pRow.getString("part_code").equals("")) {
			rtn += "AND PART_CODE='" + pRow.getString("part_code")+"'";
		}
		if(!pRow.getString("search_text").equals("")) {
			rtn += "AND CONCAT(JASN_NUMB,JASN_NAME) LIKE '%" + pRow.getString("search_text")+"%'";
		}
		return rtn; 
	}

	
	public int getTotalCount(){
		int result = 0;
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select count(1) from ").append(TABLE_NAME);
			
			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			while(rs.next()){
				if(rs.getInt(1) > 0){
					result = rs.getInt(1);
				}
			}
			
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}

	public int Current_Page(ClassParameter pRow) {
		int Current_Page = 0;
		Current_Page = (pRow.getString("page")==null)?1:Utility.Check_Number(pRow.getString("page"), 1);
		return Current_Page;
	}

	public ClassParameter Get_Total(ClassParameter pRow, String mSQL, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		ClassParameter 		result 		= 	new ClassParameter();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				max_num		= 	0; // 총수량
		try {
			SQL.append("SELECT COUNT(1) FROM (");
			SQL.append(mSQL);
			SQL.append(")");
//			Show_Msg("Get_Total:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());	
			rs = pstmt.executeQuery();
			if(rs.next()) max_num = rs.getInt(1);
  			result.setInt("total_count", max_num);	
  			result.setInt("total_page", Utility.TotalPage(max_num, pRow.getInt("list_count")));	
  			if(Current_Page(pRow) > result.getInt("total_page")) {
				result.setString("current_page", result.getString("total_page"));	
			} else if(Current_Page(pRow) < 1) {
				result.setInt("current_page", 1);	
			} else {
				result.setInt("current_page", Current_Page(pRow));	
			}
		} catch(Exception e) {
			Show_Err("Get_Total:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
  			return result;
  		}
	}

	// 자산 목록 가져오기
	public LinkedList Get_Asset_List(ClassParameter pRow) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_Asset_List(pRow, con);
		} catch(Exception e) {
			Show_Err("Get_Asset_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	public LinkedList Get_Asset_List(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;
		try {
			SQL.append("SELECT JASN_CODE, JASN_NUMB, JASN_NAME, PART_CODE, PART_NAME, TYPE_CODE, TYPE_NAME, ISTL_CODE, ISTL_NAME ");
			SQL.append("FROM "+TABLE_NAME+" WHERE 1=1 ");
			SQL.append(Search_String(pRow));
			SQL.append(" ORDER BY JASN_CODE DESC");

			ClassParameter pRow_page = Get_Total(pRow, SQL.toString(), con);
			SQL.insert(0, "SELECT * FROM (SELECT x.*, ceil(rownum/?) as PNUM FROM (");
			SQL.append(")x) WHERE PNUM=?");
			
//			Show_Msg("Get_Asset_List:"+SQL.toString());
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pRow.getInt("list_count"));
			pstmt.setInt(2, pRow_page.getInt("current_page"));
			rs = pstmt.executeQuery();
			list = new LinkedList();
			list.add(pRow_page);
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			JSONObject jo = new JSONObject();
	  			result.setObject("JASN_CODE", rs.getObject("JASN_CODE")); //자산번호	
	  			jo.put("JASN_CODE", result.getString("JASN_CODE"));
	  			result.setObject("JASN_NUMB", rs.getObject("JASN_NUMB")); //자산코드
	  			jo.put("JASN_NUMB", result.getString("JASN_NUMB"));
	  			result.setObject("JASN_NAME", rs.getObject("JASN_NAME")); //자산명
	  			jo.put("JASN_NAME", result.getString("JASN_NAME"));
	  			result.setObject("PART_CODE", rs.getObject("PART_CODE")); //부서코드	
	  			jo.put("PART_CODE", result.getString("PART_CODE"));
	  			result.setObject("PART_NAME", rs.getObject("PART_NAME")); //부서명	
	  			jo.put("PART_NAME", result.getString("PART_NAME"));
	  			result.setObject("TYPE_CODE", rs.getObject("TYPE_CODE")); //구분코드	
	  			jo.put("TYPE_CODE", result.getString("TYPE_CODE"));
	  			result.setObject("TYPE_NAME", rs.getObject("TYPE_NAME")); //구분명	
	  			jo.put("TYPE_NAME", result.getString("TYPE_NAME"));
	  			result.setObject("ISTL_CODE", rs.getObject("ISTL_CODE")); //설치장소코드	
	  			jo.put("ISTL_CODE", result.getString("ISTL_CODE"));
	  			result.setObject("ISTL_NAME", rs.getObject("ISTL_NAME")); //설치장소	
	  			jo.put("ISTL_NAME", result.getString("ISTL_NAME"));
	  			result.setObject("JSON", jo.toString());
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Asset_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		
	
	// 장비정보 가져오기 
	public ClassParameter Get_Asset_Row(ClassParameter pRow) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT A.*, NVL(B.OPTIME,-2) AS OPTIME ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" A, T_OPTIME B ");
			SQL.append("WHERE A.JASN_NUMB=B.A_CODE(+) AND JASN_CODE=?");
//			Show_Msg("Get_Asset_Row:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1,pRow.getString("JASN_CODE"));		
    		rs = pstmt.executeQuery();
			
    		if(rs.next()) {
    			result.setObject("JASN_CODE", rs.getObject("JASN_CODE")); //자산번호	
	  			result.setObject("JASN_NUMB", rs.getObject("JASN_NUMB")); //자산코드
	  			result.setObject("JASN_NAME", rs.getObject("JASN_NAME")); //자산명
	  			result.setObject("PART_CODE", rs.getObject("PART_CODE")); //부서코드	
	  			result.setObject("PART_NAME", rs.getObject("PART_NAME")); //부서명	
	  			result.setObject("TYPE_CODE", rs.getObject("TYPE_CODE")); //구분코드	
	  			result.setObject("TYPE_NAME", rs.getObject("TYPE_NAME")); //구분명	
	  			result.setObject("ISTL_CODE", rs.getObject("ISTL_CODE")); //설치장소코드	
	  			result.setObject("ISTL_DISP", rs.getObject("ISTL_DISP"));	
	  			result.setObject("SEND_DATE", rs.getObject("SEND_DATE"));	
	  			result.setObject("SEND_MONY", rs.getObject("SEND_MONY"));	
	  			result.setObject("BUBY_STOR", rs.getObject("BUBY_STOR"));	
	  			result.setObject("RGST_STAT", rs.getObject("RGST_STAT"));	
	  			result.setObject("MSGT_FRST", rs.getObject("MSGT_FRST"));	
	  			result.setObject("MSGT_SCND", rs.getObject("MSGT_SCND"));	
	  			result.setObject("JASN_TYPE_TEXT", rs.getObject("JASN_TYPE_TEXT"));	
	  			result.setObject("JASN_STND", rs.getObject("JASN_STND"));	
	  			result.setObject("WRTE_IDNT", rs.getObject("WRTE_IDNT"));	
	  			result.setObject("WRTE_DATE", rs.getObject("WRTE_DATE"));	
	  			result.setObject("UPDT_DATE", rs.getObject("UPDT_DATE"));	
	  			result.setObject("UPDT_DATE", rs.getObject("UPDT_DATE"));	
	  			result.setObject("JASN_FILE", rs.getObject("JASN_FILE"));	
	  			result.setObject("OPTIME", rs.getObject("OPTIME"));	
			}
		} catch(Exception e) {
			Show_Err("Get_Asset_Row:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	public LinkedList Get_Repair_List(ClassParameter pRow) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		Set<String> keySet = stateMap.keySet();
		Iterator<String> iter = keySet.iterator();
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT A.*, DCNT_NUMB, DECODE(ELTR_STAT, ").append(_blank);
			while(iter.hasNext()){
				final String key = iter.next();
				if(key.equals("N")){
					SQL.append(_quat).append(stateMap.get(key)).append(_quat);
				}else{
					SQL.append(_quat).append(key).append(_quat).append(_comma)
					.append(_quat).append(stateMap.get(key)).append(_quat)
					.append(_comma).append(_blank);
				}
			}
			SQL.append(") AS ELTR_STAT FROM  JF5200 A, "+Get_Property("jumpdb.prefix")+"JG5000"+Get_Property("jumpdb.suffix")+" B WHERE A.ELTR_NUMB=B.ELTR_NUMB(+) AND A.JASN_CODE=?");
			SQL.append(" ORDER BY WORK_DATE ASC");

			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setString(1, pRow.getString("JASN_CODE"));
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("REPR_NUMB", rs.getObject("REPR_NUMB")); //일련번호	
	  			result.setObject("JASN_CODE", rs.getObject("JASN_CODE")); //자산코드	
	  			result.setObject("WORK_DATE", rs.getObject("WORK_DATE")); //작업일	
	  			result.setObject("PEPR_BODY", rs.getObject("PEPR_BODY")); //작업내역	
	  			result.setObject("CNFM_USER", rs.getObject("CNFM_USER")); //검수자	
	  			result.setObject("COST_MONY", rs.getObject("COST_MONY")); //비용	
	  			result.setObject("RMRK_NOTE", rs.getObject("RMRK_NOTE")); //비고	
	  			result.setObject("WRTE_IDNT", rs.getObject("WRTE_IDNT")); //등록자	
	  			result.setObject("WRTE_DATE", rs.getObject("WRTE_DATE")); //등록일	
	  			result.setObject("UPDT_DATE", rs.getObject("UPDT_DATE")); //수정일	
	  			result.setObject("PEPR_CODE", rs.getObject("PEPR_CODE")); //일련번호	
	  			result.setObject("ELTR_NUMB", rs.getObject("ELTR_NUMB")); //수정일	
	  			result.setObject("DCNT_NUMB", rs.getObject("DCNT_NUMB")); //	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Repair_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
  		}
	}		

	public LinkedList Get_Maintenance_List(ClassParameter pRow) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		Set<String> keySet = stateMap.keySet();
		Iterator<String> iter = keySet.iterator();
		try {
			con = DBCon.getConnection();

//			SQL.append("SELECT * ");
			SQL.append("SELECT A.*, DCNT_NUMB, DECODE(ELTR_STAT,").append(_blank);
			
			while(iter.hasNext()){
				final String key = iter.next();
				if(key.equals("N")){
					SQL.append(_quat).append(stateMap.get(key)).append(_quat);
				}else{
					SQL.append(_quat).append(key).append(_quat).append(_comma)
					.append(_quat).append(stateMap.get(key)).append(_quat)
					.append(_comma).append(_blank);
				}
			}
			
			SQL.append(") AS ELTR_STAT FROM  JF5300 A, "+Get_Property("jumpdb.prefix")+"JG5000"+Get_Property("jumpdb.suffix")+" B WHERE A.ELTR_NUMB=B.ELTR_NUMB(+) AND A.JASN_CODE=?");
			//SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JF5300"+Get_Property("jumpdb.suffix")+" WHERE JASN_CODE=? ");
//			SQL.append("FROM JF5300 WHERE JASN_CODE=? ");
			SQL.append(" ORDER BY STRT_DATE ASC");

//			Show_Msg("Get_Maintenance_List:"+SQL.toString());
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setString(1, pRow.getString("JASN_CODE"));
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
				//result.setObject("INX", rs.getObject("INX"));	
				result.setObject("OPPR_CODE", rs.getObject("OPPR_CODE")); //일련번호	
	  			result.setObject("OPPR_NUMB", rs.getObject("OPPR_NUMB")); //관리번호	
	  			result.setObject("JASN_CODE", rs.getObject("JASN_CODE")); //자산코드	
	  			result.setObject("STRT_DATE", rs.getObject("STRT_DATE")); //시작일	
	  			result.setObject("ENDS_DATE", rs.getObject("ENDS_DATE")); //종료일	
	  			result.setObject("COMP_NAME", rs.getObject("COMP_NAME")); //업체명	
	  			result.setObject("MONY_TOTL", rs.getObject("MONY_TOTL")); //비용	
	  			result.setObject("RMRK_NOTE", rs.getObject("RMRK_NOTE")); //비고	
	  			result.setObject("WRTE_IDNT", rs.getObject("WRTE_IDNT")); //등록자	
	  			result.setObject("WRTE_DATE", rs.getObject("WRTE_DATE")); //등록일	
	  			result.setObject("UPDT_DATE", rs.getObject("UPDT_DATE")); //수정일	
	  			result.setObject("ELTR_NUMB", rs.getObject("ELTR_NUMB")); //	
	  			result.setObject("DCNT_NUMB", rs.getObject("DCNT_NUMB")); //
	  			result.setObject("ELTR_STAT", rs.getObject("ELTR_STAT")); //상태
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Maintenance_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
  		}
	}

	public ClassParameter Get_Discuse_Row(ClassParameter pRow) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT A.*, B.ELTR_NUMB ");
			SQL.append("FROM "+Get_Property("jumpdb.prefix")+"JF2000"+Get_Property("jumpdb.suffix")+" A ");
			SQL.append(", "+Get_Property("jumpdb.prefix")+"JG5000"+Get_Property("jumpdb.suffix")+" B ");
			SQL.append("WHERE SUBSTR(A.DCNT_NUMB,0,12)=B.DCNT_NUMB AND A.JASN_CODE=? ");

//			Show_Msg("Get_Discuse_Row:"+SQL.toString());
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setString(1, pRow.getString("JASN_CODE"));
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result.setObject("LOSS_TYPE", rs.getObject("LOSS_TYPE")); //구분	
	  			result.setObject("DUSE_PRCS", rs.getObject("DUSE_PRCS")); //불용후처리	
	  			result.setObject("LOSS_DATE", rs.getObject("LOSS_DATE")); //불용일자	
	  			result.setObject("DUSE_DATE", rs.getObject("DUSE_DATE")); //처리일자	
	  			result.setObject("DUSE_PRCS", rs.getObject("DUSE_PRCS")); //처리금액	
	  			result.setObject("DCNT_NUMB", rs.getObject("DCNT_NUMB")); //전자결재번호	
	  			result.setObject("ELTR_NUMB", rs.getObject("ELTR_NUMB")); //전자결재번호	
			}
		} catch(Exception e) {
			Show_Err("Get_Discuse_Row:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}
	
	
	public ClassParameter getElecApproval(int pNum) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();
		
		Set<String> keySet = stateMap.keySet();
		Iterator<String> iter = keySet.iterator();
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT A.*, DCNT_NUMB, DECODE(ELTR_STAT,").append(_blank);
			while(iter.hasNext()){
				final String key = iter.next();
				if(key.equals("N")){
					SQL.append(_quat).append(stateMap.get(key)).append(_quat);
				}else{
					SQL.append(_quat).append(key).append(_quat).append(_comma)
					.append(_quat).append(stateMap.get(key)).append(_quat)
					.append(_comma).append(_blank);
				}
			}
			SQL.append(") AS ELTR_STAT FROM  T_DOC A, "+Get_Property("jumpdb.prefix")+"JG5000"+Get_Property("jumpdb.suffix")+" B WHERE A.NUM=B.ELTR_NUMB(+) AND A.NUM=?");
			
//			Show_Msg("getElecApproval:"+SQL.toString());
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("P_NUM", rs.getObject("P_NUM"));	
	  			result.setObject("NUM", rs.getObject("NUM"));	
	  			result.setObject("TITLE", rs.getObject("TITLE"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("STATE", rs.getObject("STATE"));
	  			result.setObject("DCNT_NUMB", rs.getObject("DCNT_NUMB"));
	  			result.setObject("ELTR_STAT", rs.getObject("ELTR_STAT"));
			}
		} catch(Exception e) {
			Show_Err("getElecApproval:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}
	
	// 자산 가동률 기준정보 등록
	public int Insert_Optime(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("INSERT INTO T_OPTIME(A_CODE, OPTIME) ");
			SQL.append("VALUES(?, ?)");
//			Show_Msg("Insert_Optime:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("A_CODE"));		
			pstmt.setString(index++, pRow.getString("OPTIME"));		
			result = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Insert_Optime:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}

	// 자산 가동률 기준정보 수정
	public int Update_Optime(ClassParameter pRow) throws Exception {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();

			SQL.append("UPDATE T_OPTIME SET OPTIME=? ");
			SQL.append("WHERE A_CODE=?");
//			Show_Msg("Update_Optime:"+SQL.toString());

			int index = 1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, pRow.getString("OPTIME"));		
			pstmt.setString(index++, pRow.getString("A_CODE"));		
			result = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			Show_Err("Update_Optime:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
 	}
}
