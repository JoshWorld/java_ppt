package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Logger;

import builder.Builder;
import builder.database.DBConnection;
import jiat.model.Engineer;
import jiat.model.T_CODE;

public class SettingsProc extends Builder {
	static Logger logger = Logger.getLogger(SettingsProc.class.getSimpleName());
	private final String TABLE_NAME = "T_ENGINEER";
	
	public ArrayList<Engineer> getEngineersSetting(){
		ArrayList<Engineer> result = new ArrayList<Engineer>();
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select * from ").append("T_ENGINEER order by INX asc");

			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				Engineer egnr = new Engineer();
				
				egnr.setName(rs.getString(Engineer.NAME_TAG));
				egnr.setInx(rs.getInt(Engineer.INX_TAG));
				egnr.setCost(rs.getInt(Engineer.COST_TAG));
				result.add(egnr);
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	
	public int getMaxInxEngineer(){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		int cnt = 0;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("SELECT MAX(INX) cnt FROM ").append("T_ENGINEER");

			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			
			
			
			while(rs.next()){
				cnt = rs.getInt("cnt");
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return cnt;
		}	
	}
	
	public ArrayList<T_CODE> getCodeSetting(){
		ArrayList<T_CODE> result = new ArrayList<T_CODE>();
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			con = DBCon.getConnection();
			
			SQL.append("Select * from ").append("T_CODE");

			pstmt = con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				T_CODE code = new T_CODE();
				
				code.setValue(rs.getInt(T_CODE.VALUE_TAG));
				code.setCode(rs.getInt(T_CODE.CODE_TAG));
				result.add(code);
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}	
	}
	
	public int updateCode(String key, String value){
		Connection				con 		=	null;
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		DBConnection 			DBCon 		= 	new DBConnection();
		
		try{
			con = DBCon.getConnection();
			
			SQL.append("update ")
			.append("T_CODE")
			.append(" set ").append(T_CODE.VALUE_TAG).append("=?")
			.append(" where ").append(T_CODE.CODE_TAG).append("=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			
			pstmt.setInt(index++, Integer.parseInt(value));			
			pstmt.setString(index++, key);
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}
	public int addEngineer(String name, int cost){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		
		try {
			SQL.append("Insert into T_ENGINEER ")
			.append("(NAME, COST)")
			.append("VALUES (?,?)");
			
			String cols[] = {"INX"};
			
			con = DBCon.getConnection();
			pstmt = con.prepareStatement(SQL.toString(),cols);
			int index=1;
			pstmt.setString(index++, name);
			pstmt.setInt(index++, cost);

			result = pstmt.executeUpdate();
			
		} catch(Exception e) {
			if(con != null) con.rollback();
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}
	public int updateEngineer(Engineer engr,String name, int cost){
		Connection				con 		=	null;
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		DBConnection 			DBCon 		= 	new DBConnection();
		
		try{
			con = DBCon.getConnection();
			
			SQL.append("update ")
				.append("T_ENGINEER")
				.append(" set ")
				.append(Engineer.NAME_TAG).append("=?,")
				.append(Engineer.COST_TAG).append("=?")
				.append(" where ").append(Engineer.INX_TAG).append("=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			pstmt.setString(index++, name);
			pstmt.setInt(index++, cost);
			pstmt.setInt(index++, engr.getInx());
			
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}
	
	public int delEngineer(int inx){
		Connection				con 		=	null;
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		DBConnection 			DBCon 		= 	new DBConnection();
		
		try{
			con = DBCon.getConnection();
			
			SQL.append("delete from ")
				.append("T_ENGINEER")
				.append(" where inx=? ");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			pstmt.setInt(index++, inx);
						
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}
	public int delRootUser(String idnt){
		Connection				con 		=	null;
		int						result		=	-1;
		PreparedStatement 		pstmt 		= 	null;
		ResultSet 				rs 			= 	null;
		StringBuffer 			SQL 		= 	new StringBuffer();
		DBConnection 			DBCon 		= 	new DBConnection();
		
		try{
			con = DBCon.getConnection();
			
			SQL.append("delete from ")
				.append("T_ROOT_USER")
				.append(" where USER_IDNT=? ");
			
			pstmt = con.prepareStatement(SQL.toString());
			
			int index = 1;
			pstmt.setString(index++, idnt);
						
			result = pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}
}
