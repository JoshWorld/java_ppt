package jiat.util;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import builder.web.Param;
import jiat.model.FileInfo;
import jiat.project.file.FileProc;

/**
 * Servlet implementation class FileDeleteServlet
 */
@WebServlet("/FileDeleteServlet")
public class FileDeleteServlet extends JumpServlet {
	private static final long serialVersionUID = 1L;
	Logger logger = Logger.getLogger(FileDeleteServlet.class.getSimpleName());
	
    /**
     * Default constructor. 
     */
    public FileDeleteServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		final String contextRootPath = this.getServletContext().getRealPath("/");
		final String savePath = contextRootPath + "/upload/";
		
		JSONObject json = new JSONObject();
		json.put("result", 0);
		
		Param param = new Param(request, false, "ISO-8859-1", "UTF-8");
		String fNum = param.getParameter("f_num");
		FileProc fileProc = new FileProc();
		int deleteResult = 0;
		if(fNum!=null && fNum.length()>0){
			FileInfo fInfo = fileProc.getFile(Integer.parseInt(fNum));
			deleteResult = fileProc.deleteFile(Integer.parseInt(fNum));
			
			if(deleteResult > 0){				
				File file = new File(savePath + fInfo.getName());
				
				if(file.delete()){
					deleteResult = 1;
				}else{
					deleteResult = 0;
				}
			}
			json.put("result", deleteResult);
		}
		out.print(json.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
