package jiat.util;
import java.io.File;  
import java.io.IOException;  
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;   
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;  
import org.apache.commons.fileupload.FileItemFactory;  
import org.apache.commons.fileupload.FileUploadException;  
import org.apache.commons.fileupload.disk.DiskFileItemFactory;  
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;

import jiat.model.Tax;
import jiat.model.FileInfo;
import jiat.project.tax.TaxProc;
import jiat.project.file.FileProc;

@WebServlet("/project/FileUploadMultipleServlet")
@MultipartConfig(maxFileSize=1024*1024*10)
public class FileUploadMultipleServlet extends JumpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = Logger.getLogger(this.getClass().getSimpleName());
	private TaxProc taxProc;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int pNum = Integer.parseInt(request.getParameter("p_num"));
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain; charset=UTF-8"); 
		
		String contextRootPath = this.getServletContext().getRealPath("/");
		final String savePath = contextRootPath + "/upload";

		ArrayList<FileInfo> files = new ArrayList<FileInfo>();
		FileInfo fInfo = new FileInfo();
		
		for(Part part: request.getParts()){
			for(String headerName : part.getHeaderNames()){
				
				String header = part.getHeader(headerName);
				if(part.getContentType() != null && header.contains("filename")){
					final String _filename_tag = "filename=";

					String fileName = header.substring(header.lastIndexOf(_filename_tag) + _filename_tag.length());
					if(fileName.indexOf("\\") > -1){
						fileName = fileName.substring(fileName.lastIndexOf("\\")+1,fileName.length());
					}

					fileName = fileName.replace('\"', '\0').trim();
					if(!(fileName.length()>0))continue;
					
					String uploadedFileName = System.currentTimeMillis() + UUID.randomUUID().toString() +fileName.substring(fileName.lastIndexOf("."));
					File file = new File(savePath + "/" +uploadedFileName);
					FileUtils.copyInputStreamToFile(part.getInputStream(), file);
					fInfo.setName(file.getName());
					fInfo.setfName(URLEncoder.encode(fileName, "UTF-8"));
					fInfo.setpNum(pNum);
					files.add(fInfo);
				}
			}
		}
//		if(files.size() > 0){
//			new FileProc().addFilesForTax(files);
//		}
		
		out.print(fInfo.toString());
		//getServletContext().getRequestDispatcher("/project/add_receipt.jsp").forward(request, response);
	}
    
    /**
	 * 
	 * @param req
	 * @param proc
	 * @return
	 */
	private int addTax(HttpServletRequest req){
		JSONObject json = new JSONObject();
		
		int taxIdx = -1;
		
		Enumeration<String> enumer = req.getParameterNames();
		while(enumer.hasMoreElements()){
			String element = enumer.nextElement();
			for(String s: req.getParameterValues(element)){
				try {
					String elem = new String(s.getBytes("ISO-8859-1"), "UTF-8");
					json.put(element.toUpperCase(), elem);
				} catch (JSONException e) {
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
		}
		taxProc = new TaxProc();
		Tax tax = Tax.parseTax(json);
		if(!tax.hasNull()){
			taxIdx = taxProc.addTax(tax);
		}
		return taxIdx;
	}
    
    
    
    
}