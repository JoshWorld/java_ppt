package jiat.util;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;

import jiat.ProjectProc;
import jiat.model.Contract;
import jiat.model.FileInfo;
import jiat.project.contract.ContractProc;
import jiat.project.file.FileProc;

/**
 * 
 * 
 */
@WebServlet("/project/contract/MultiFileUploadServlet")
@MultipartConfig(maxFileSize=1024*1024*10)
public class MultiFileUploadServlet extends JumpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = Logger.getLogger(this.getClass().getSimpleName());
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain; charset=UTF-8"); 
		String contextRootPath = this.getServletContext().getRealPath("/");
		final String savePath = contextRootPath + "upload";

		String cNum = request.getParameter("C_NUM");
		String pNum = request.getParameter("P_NUM");
		
		FileInfo fInfo = new FileInfo();
		File file = new File(savePath);
		for(Part part: request.getParts()){
			for(String headerName : part.getHeaderNames()){
				String header = part.getHeader(headerName);
				if(part.getContentType() != null && header.contains("filename")){
					final String _filename_tag = "filename=";
					String fileName = header.substring(header.lastIndexOf(_filename_tag) + _filename_tag.length());
					
					// fileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
					
					if(fileName.indexOf("\\") > -1){
						fileName = fileName.substring(fileName.lastIndexOf("\\")+1,fileName.length());
					}
					fileName = fileName.replace('\"', '\0').trim();
					if(!(fileName.length()>0))continue;
					
					fInfo.setfName(URLEncoder.encode(fileName, "UTF-8"));
					String uploadedFileName = System.currentTimeMillis() + UUID.randomUUID().toString() +fileName.substring(fileName.lastIndexOf("."));
					file = new File(savePath + "/" +uploadedFileName);
					FileUtils.copyInputStreamToFile(part.getInputStream(), file);
				}
			}
		}
		if(file != null && (cNum==null || pNum==null)){
			// add Contract 할 때
			fInfo.setName(file.getName());
			out.print(fInfo.toString());
			return;
		}else if(file != null && (cNum!=null && pNum!=null)){
			// Contract 수정 할 때
			fInfo.setcNum(cNum);
			fInfo.setpNum(pNum);
			fInfo.setName(file.getName());
			fInfo.setfName(URLDecoder.decode(fInfo.getfName()));
			
			new FileProc().addFile(fInfo);
			out.print(fInfo.toString());
			return;
		}
	}
}