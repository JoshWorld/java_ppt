package jiat.util;

import javax.servlet.http.HttpServlet;

public class JumpServlet extends HttpServlet {
	public static final String MESSAGE_TAG = "message";
	public static final String SUCCESS_CODE = "success";
	public static final String FAIL_CODE = "fail";
}
