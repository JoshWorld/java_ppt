package jiat.util;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;

import jiat.ProjectProc;
import jiat.model.Contract;
import jiat.model.FileInfo;
import jiat.project.contract.ContractProc;
import jiat.project.file.FileProc;

/**
 * 
 * 
 */
@WebServlet("/project/contract/FileUploadServlet")
@MultipartConfig(maxFileSize=1024*1024*10)
public class FileUploadServlet extends JumpServlet {
	private static final long serialVersionUID = 1L;
	private Logger logger = Logger.getLogger(this.getClass().getSimpleName());
	private ContractProc contractProc;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int pNum = Integer.parseInt(request.getParameter("p_num"));
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/plain; charset=UTF-8"); 
		
		JSONObject result = new JSONObject();
		
		int contractIdx = 0;
		
		if(request.getParameter("inx")!=null && !request.getParameter("inx").equals("")){
			contractIdx = Integer.parseInt(request.getParameter("inx"));
			updateContract(request);
		}else{
			contractIdx = addContract(request);
		}
		result.put(Contract.INX_TAG, contractIdx);
		
		if(contractIdx > 0){
			String contextRootPath = this.getServletContext().getRealPath("/");
			final String savePath = contextRootPath + "/upload";

			ArrayList<FileInfo> files = new ArrayList<FileInfo>();

			for(Part part: request.getParts()){
				for(String headerName : part.getHeaderNames()){
					FileInfo fInfo = new FileInfo();
					String header = part.getHeader(headerName);
					if(part.getContentType() != null && header.contains("filename")){
						final String _filename_tag = "filename=";

						String fileName = header.substring(header.lastIndexOf(_filename_tag) + _filename_tag.length());
						if(fileName.indexOf("\\") > -1){
							fileName = fileName.substring(fileName.lastIndexOf("\\")+1,fileName.length());
						}

						fileName = fileName.replace('\"', '\0').trim();
						if(!(fileName.length()>0))continue;

						String uploadedFileName = System.currentTimeMillis() + UUID.randomUUID().toString() +fileName.substring(fileName.lastIndexOf("."));
						File file = new File(savePath + "/" +uploadedFileName);
						FileUtils.copyInputStreamToFile(part.getInputStream(), file);
						fInfo.setName(file.getName());
						fInfo.setcNum(contractIdx);
						fInfo.setfName(fileName);
						fInfo.setpNum(pNum);
						files.add(fInfo);
					}
				}
			}
			if(files.size() > 0){
				new FileProc().addFiles(files);
			}
			request.setAttribute(MESSAGE_TAG, SUCCESS_CODE);
		}else{
			request.setAttribute(MESSAGE_TAG, FAIL_CODE);
		}
		getServletContext().getRequestDispatcher("/project/contract/add_contract.jsp").forward(request, response);
	}
	private Contract getUploadedContract(int cNum){
		return contractProc.getContractWithFiles(cNum);
	}
	/**
	 * 
	 * @param req
	 * @param proc
	 * @return
	 */
	private int addContract(HttpServletRequest req){
		JSONObject json = new JSONObject();
		
		int contractIdx = -1;
		
		Enumeration<String> enumer = req.getParameterNames();
		while(enumer.hasMoreElements()){
			String element = enumer.nextElement();
			for(String s: req.getParameterValues(element)){
				try {
					String elem = new String(s.getBytes("ISO-8859-1"), "UTF-8");
					json.put(element.toUpperCase(), elem);
				} catch (JSONException e) {
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
		}
		
		contractProc = new ContractProc();
		Contract contract = Contract.parseContract(json);
		if(!contract.hasNull()){
			contractIdx = contractProc.addContract(contract);
		}
		return contractIdx;
	}
	
	
	/**
	 * 
	 * @param req
	 * @param proc
	 * @return
	 */
	private void updateContract(HttpServletRequest req){
		JSONObject json = new JSONObject();
		
		Enumeration<String> enumer = req.getParameterNames();
		while(enumer.hasMoreElements()){
			String element = enumer.nextElement();
			for(String s: req.getParameterValues(element)){
				try {
					String elem = new String(s.getBytes("ISO-8859-1"), "UTF-8");
					json.put(element.toUpperCase(), elem);
				} catch (JSONException e) {
					e.printStackTrace();
				} catch (UnsupportedEncodingException e) {
					e.printStackTrace();
				}
			}
		}
		contractProc = new ContractProc();
		Contract contract = Contract.parseContract(json);
		int result = 0;
		if(!contract.hasNull()){
			result = contractProc.updateContract(contract);
		}
	}
	
	
}