package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.logging.Logger;

import org.json.JSONObject;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import builder.web.Utility;
import jiat.model.Cost;
import jiat.model.CostDetail;
import jiat.model.EstimateDetail;
import jiat.model.Estimate;

public class ProjectEstimate  extends Builder {
	static Logger logger = Logger.getLogger(ProjectProc.class.getSimpleName());
	static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";

	public String Search_String(ClassParameter pRow) { 
		String rtn = "";
		if(!pRow.getString("search_text").equals("")) {
			rtn += " AND CONCAT(CONCAT(P.TITLE, P.C_COMPANY), C.NAME) LIKE '%"+pRow.getString("search_text")+"%'";
		}
		return rtn; 
	}

	public int Current_Page(ClassParameter pRow) {
		int Current_Page = 0;
		Current_Page = (pRow.getString("page")==null)?1:Utility.Check_Number(pRow.getString("page"), 1);
		return Current_Page;
	}

	public ClassParameter Get_Total(ClassParameter pRow, String mSQL, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		ClassParameter 		result 		= 	new ClassParameter();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				max_num		= 	0; // 총수량
		try {
			SQL.append("SELECT COUNT(1) FROM (");
			SQL.append(mSQL);
			SQL.append(")");
			Show_Msg("Get_Total:"+SQL.toString());

			pstmt = con.prepareStatement(SQL.toString());	
			rs = pstmt.executeQuery();
			if(rs.next()) max_num = rs.getInt(1);
  			result.setInt("total_count", max_num);	
  			result.setInt("total_page", Utility.TotalPage(max_num, pRow.getInt("list_count")));	
  			if(Current_Page(pRow) > result.getInt("total_page")) {
				result.setString("current_page", result.getString("total_page"));	
			} else if(Current_Page(pRow) < 1) {
				result.setInt("current_page", 1);	
			} else {
				result.setInt("current_page", Current_Page(pRow));	
			}
		} catch(Exception e) {
			Show_Err("Get_Total:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
  			return result;
  		}
	}
	
	//  원가산정서 상세 내용 변경
	public int changeCostDetails(Cost cost, ArrayList<CostDetail> cds){
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int					result 		= 	0;
		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			result = changeCostDetails(cost, cds, con);
			con.commit();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return result;
		}
	}

	//  원가산정서 상세 내용 변경
	public int changeCostDetails(Cost cost, ArrayList<CostDetail> cds, Connection con){
		PreparedStatement 	pstmt1 		= 	null;
		PreparedStatement 	pstmt2 		= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;
		
		try {
			pstmt1 = con.prepareStatement("DELETE FROM T_COST_DETAIL WHERE D_NUM=?");
			pstmt1.setInt(1, cost.getdNum());
			result = pstmt1.executeUpdate();
			
			SQL.append("INSERT INTO T_COST_DETAIL ");
			SQL.append("(P_NUM, E_NUM, D_NUM, C_NUM, M_NUM, T_NUM, TYPE, NAME, M_NAME, T_NAME, ENGINEER, COST, USE, UNIT, MONEY) ");
			SQL.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			Show_Msg("changeCostDetails:"+SQL.toString());
			
			pstmt2 = con.prepareStatement(SQL.toString());
			for(int i=0; i<cds.size(); i++) {
				CostDetail cd = cds.get(i);
				int index = 1;
				pstmt2.setInt(index++, cost.getpNum());
				pstmt2.setInt(index++, cost.geteNum());
				pstmt2.setInt(index++, cost.getdNum());
				pstmt2.setInt(index++, cost.getInx());
				pstmt2.setInt(index++, cd.getmNum());
				pstmt2.setInt(index++, cd.gettNum());
				pstmt2.setString(index++, cd.getType());
				pstmt2.setString(index++, cd.getName());
				pstmt2.setString(index++, cd.getmName());
				pstmt2.setString(index++, cd.gettName());
				pstmt2.setString(index++, cd.getEngineer());
				pstmt2.setInt(index++, cd.getCost());
				pstmt2.setInt(index++, cd.getUse());
				pstmt2.setString(index++, cd.getUnit());
				pstmt2.setInt(index++, cd.getMoney());
				result = pstmt2.executeUpdate();
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_PS(pstmt1);
			Close_PS(pstmt2);
			return result;
		}
	}

	// 원가 산정서 내용 가져오기
	public Cost getCost(Cost cost){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		Cost				result 		= 	new Cost();		
		
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_COST WHERE P_NUM=? AND E_NUM=? AND D_NUM=? ORDER BY INX ASC");
			Show_Msg("getCost:"+SQL.toString());

			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, cost.getpNum());
			pstmt.setInt(index++, cost.geteNum());
			pstmt.setInt(index++, cost.getdNum());

			rs = pstmt.executeQuery();
			while(rs.next()){
				result.setInx(rs.getInt("INX"));
				result.setpNum(rs.getInt("P_NUM"));
				result.seteNum(rs.getInt("E_NUM"));
				result.setdNum(rs.getInt("D_NUM"));
				result.setName(rs.getString("NAME"));
				result.setMoney(rs.getString("MONEY"));
				result.setOrate(rs.getInt("ORATE"));
				result.setOcost(rs.getInt("OCOST"));
				result.setTotal(rs.getInt("TOTAL"));
				result.setCostDetail(getCostDetails(result, con));
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 원가 산정서 내용 가져오기
	public Cost getCost(int inx){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		Cost				result 		= 	new Cost();		
		
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_COST WHERE INX=?");
			Show_Msg("getCost:"+SQL.toString());

			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, inx);

			rs = pstmt.executeQuery();
			while(rs.next()){
				result.setInx(rs.getInt("INX"));
				result.setpNum(rs.getInt("P_NUM"));
				result.seteNum(rs.getInt("E_NUM"));
				result.setdNum(rs.getInt("D_NUM"));
				result.setName(rs.getString("NAME"));
				result.setMoney(rs.getString("MONEY"));
				result.setOrate(rs.getInt("ORATE"));
				result.setOcost(rs.getInt("OCOST"));
				result.setTotal(rs.getInt("TOTAL"));
				result.setCostDetail(getCostDetails(result, con));
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 저장된 원가 산정서 목록 가져오기
	public LinkedList getCosts(ClassParameter pRow){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList			list 		= 	new LinkedList();		
		
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT C.*, P.C_COMPANY, P.TITLE FROM T_COST C, T_PROJECT P WHERE C.P_NUM=P.INX AND C.WRITERID='"+pRow.getString("WRITERID")+"' ");
			SQL.append(Search_String(pRow));
			SQL.append(" ORDER BY C.NAME ASC");

			ClassParameter pRow_page = Get_Total(pRow, SQL.toString(), con);
			SQL.insert(0, "SELECT * FROM (SELECT x.*, ceil(rownum/?) as PNUM FROM (");
			SQL.append(")x) WHERE PNUM=?");
			Show_Msg("getCosts:"+SQL.toString());
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pRow.getInt("list_count"));
			pstmt.setInt(2, pRow_page.getInt("current_page"));
			rs = pstmt.executeQuery();
			list.add(pRow_page);
			while(rs.next()){
				ClassParameter result = new ClassParameter();
				result.setObject("INX", rs.getInt("INX"));
				result.setObject("P_NUM", rs.getInt("P_NUM"));
				result.setObject("E_NUM", rs.getInt("E_NUM"));
				result.setObject("D_NUM", rs.getInt("D_NUM"));
				result.setObject("NAME", rs.getString("NAME"));
				result.setObject("MONEY", rs.getString("MONEY"));
				result.setObject("ORATE", rs.getInt("ORATE"));
				result.setObject("OCOST", rs.getInt("OCOST"));
				result.setObject("TOTAL", rs.getInt("TOTAL"));
				result.setObject("C_COMPANY", rs.getString("C_COMPANY"));
				result.setObject("TITLE", rs.getString("TITLE"));
				list.add(result);
			}
		} catch(Exception e) {
			Show_Err("getCosts:"+e.toString());
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}

	// 원가산정서 상세 정보 가져오기
	public ArrayList<CostDetail> getCostDetails(Cost cost, Connection con){
		ArrayList<CostDetail>	list		=	new ArrayList();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		try {
			SQL.append("SELECT * FROM T_COST_DETAIL WHERE P_NUM=? AND E_NUM=? AND D_NUM=? AND C_NUM=? ORDER BY TYPE, INX");
			Show_Msg("getCostDetails:"+SQL.toString());

			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, cost.getpNum());
			pstmt.setInt(index++, cost.geteNum());
			pstmt.setInt(index++, cost.getdNum());
			pstmt.setInt(index++, cost.getInx());

			rs = pstmt.executeQuery();
			while(rs.next()){
				CostDetail result = new CostDetail();		
				result.setInx(rs.getInt("INX"));
				result.setpNum(rs.getInt("P_NUM"));
				result.seteNum(rs.getInt("E_NUM"));
				result.setdNum(rs.getInt("D_NUM"));

				result.setType(rs.getString("TYPE"));
				result.setName(rs.getString("NAME"));
				result.setmNum(rs.getString("M_NUM"));
				result.setmName(rs.getString("M_NAME"));
				result.settNum(rs.getString("T_NUM"));
				result.settName(rs.getString("T_NAME"));

				result.setEngineer(rs.getString("ENGINEER"));
				result.setCost(rs.getInt("COST"));
				result.setUse(rs.getInt("USE"));
				result.setUnit(rs.getString("UNIT"));
				result.setMoney(rs.getInt("MONEY"));
				list.add(result);
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
		}
	}
	
	// 원가산성서 등록하기
	public int addCost(Estimate estimate, EstimateDetail ed, Cost cost, ArrayList<CostDetail> cds){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		
		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			int edNum = modBudgetMain("MOD", estimate, ed);
			cost.setdNum(edNum);

			SQL.append("INSERT INTO T_COST (P_NUM, E_NUM, D_NUM, NAME, MONEY, ORATE, OCOST, TOTAL, WRITER, WRITERID, WRITE) ");
			SQL.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			Show_Msg("addCost:"+SQL.toString());

			int index=1;
			String cols[] = {"INX"};
			pstmt = con.prepareStatement(SQL.toString(), cols);
			pstmt.setInt(index++, cost.getpNum());
			pstmt.setInt(index++, cost.geteNum());
			pstmt.setInt(index++, cost.getdNum());
			pstmt.setString(index++, cost.getName());
			pstmt.setInt(index++, cost.getMoney());
			pstmt.setInt(index++, cost.getOrate());
			pstmt.setInt(index++, cost.getOcost());
			pstmt.setInt(index++, cost.getTotal());
			pstmt.setString(index++, cost.getWriter());
			pstmt.setString(index++, cost.getWriterID());
			pstmt.setString(index++, cost.getWrite());
			
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			int c_num = 0;
			if(rs.next()) c_num = rs.getInt(1);
			cost.setInx(c_num);
			changeCostDetails(cost, cds, con);
			result = c_num;
			con.commit();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 원가산정서 수정하기
	public int modCost(Estimate estimate, EstimateDetail ed, Cost cost, ArrayList<CostDetail> cds){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		
		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			int edNum = modBudgetMain("MOD", estimate, ed);

			SQL.append("UPDATE T_COST SET NAME=?, MONEY=?, ORATE=?, OCOST=?, TOTAL=? WHERE INX=?");
			Show_Msg("modCost:"+SQL.toString());

			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(index++, cost.getName());
			pstmt.setInt(index++, cost.getMoney());
			pstmt.setInt(index++, cost.getOrate());
			pstmt.setInt(index++, cost.getOcost());
			pstmt.setInt(index++, cost.getTotal());
			pstmt.setInt(index++, cost.getInx());
			
			result = pstmt.executeUpdate();
			changeCostDetails(cost, cds, con);
			con.commit();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 견적 정보 가져오기
	public Estimate getEstimate(int eNum){
		Estimate			estimate		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			estimate = getEstimate(con, eNum);
		}catch(Exception e) {
			Show_Err("getEstimate:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return estimate;
  		}
	}

	// 견적 정보 가져오기
	private Estimate getEstimate(Connection con, int eNum){
		Estimate 			estimate 	=	new Estimate();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_ESTIMATE WHERE INX = ?");
			Show_Msg("getEstimate:"+SQL.toString());
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, eNum);
			rs = pstmt.executeQuery();
			if(rs.next()){
				estimate.setInx(rs.getInt(INX_TAG));
				estimate.setP_num(rs.getInt(Estimate.P_NUM_TAG));
				estimate.setNum(rs.getString(Estimate.NUM_TAG));
				estimate.setName(rs.getString(Estimate.NAME_TAG));
				estimate.seteDate(rs.getString(Estimate.EDATE_TAG));
				estimate.setMoney(rs.getInt(Estimate.MONEY_TAG));
				estimate.setUnit(rs.getString(Estimate.UNIT_TAG));
				estimate.setWriter(rs.getString(Estimate.WRITER_TAG));
				estimate.setWriterID(rs.getString(Estimate.WRITERID_TAG));
				estimate.setWrite(rs.getString(Estimate.WRITE_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return estimate;
  		}
	}
	
	// 견적목록 정보 가져오기
	public ArrayList<Estimate> getEstimates(int pNum){
		ArrayList<Estimate>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getEstimates(con, pNum);
		}catch(Exception e) {
			Show_Err("getEstimates:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	// 견적목록 정보 가져오기
	private ArrayList<Estimate> getEstimates(Connection con, int pNum){
		ArrayList<Estimate> list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_ESTIMATE WHERE P_NUM=? AND NVL(STATE,'0')<>'9' ORDER BY WRITE DESC");
//			logger.info(SQL.toString() +" / " + pNum);
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Estimate>();
			while(rs.next()){
				Estimate estimate = new Estimate();
				estimate.setInx(rs.getInt(INX_TAG));
				estimate.setP_num(rs.getInt(Estimate.P_NUM_TAG));
				estimate.setNum(rs.getString(Estimate.NUM_TAG));
				estimate.setName(rs.getString(Estimate.NAME_TAG));
				estimate.seteDate(rs.getString(Estimate.EDATE_TAG));
				estimate.setMoney(rs.getInt(Estimate.MONEY_TAG));
				estimate.setUnit(rs.getString(Estimate.UNIT_TAG));
				estimate.setWriter(rs.getString(Estimate.WRITER_TAG));
				estimate.setWriterID(rs.getString(Estimate.WRITERID_TAG));
				estimate.setWrite(rs.getString(Estimate.WRITE_TAG));
				
				list.add(estimate);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}

	// 견적 상세 정보  가져오기
	public EstimateDetail getEstimateDetail(int dNum){
		EstimateDetail		ed			=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			ed = getEstimateDetail(con, dNum);
		}catch(Exception e) {
			Show_Err("getEstimateDetail:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return ed;
  		}
	}

	// 견적 상세 정보  가져오기
	private EstimateDetail getEstimateDetail(Connection con, int dNum){
		EstimateDetail 		ed 			=	new EstimateDetail();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_ESTIMATE_DETAIL WHERE INX = ?");
			Show_Msg("getEstimateDetail:"+SQL.toString());
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, dNum);
			rs = pstmt.executeQuery();
			if(rs.next()){
				ed.setInx(rs.getInt(EstimateDetail.INX_TAG));
				ed.setP_num(rs.getInt(EstimateDetail.P_NUM_TAG));
				ed.setE_num(rs.getInt(EstimateDetail.E_NUM_TAG));
				ed.setType(rs.getString(EstimateDetail.TYPE_TAG));
				ed.setName(rs.getString(EstimateDetail.NAME_TAG));
				ed.setCost(rs.getString(EstimateDetail.COST_TAG));
				ed.setMoney(rs.getString(EstimateDetail.MONEY_TAG));
				ed.setCount(rs.getString(EstimateDetail.COUNT_TAG));
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return ed;
  		}
	}

	// 견적 상세 목록  가져오기
	public ArrayList<EstimateDetail> getEstimateDetails(int pNum, int eNum){
		ArrayList<EstimateDetail>	list		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		try {
			con = DBCon.getConnection();
			list = getEstimateDetails(con, pNum, eNum);
		}catch(Exception e) {
			Show_Err("getEstimateDetails:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}

	// 견적 상세 목록  가져오기
	private ArrayList<EstimateDetail> getEstimateDetails(Connection con, int pNum, int eNum){
		ArrayList<EstimateDetail> list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_ESTIMATE_DETAIL WHERE P_NUM=? AND E_NUM=? ORDER BY INX ASC");
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			pstmt.setInt(2, eNum);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<EstimateDetail>();
			while(rs.next()){
				EstimateDetail estimateDetail = new EstimateDetail();
				estimateDetail.setInx(rs.getInt(EstimateDetail.INX_TAG));
				estimateDetail.setType(rs.getString(EstimateDetail.TYPE_TAG));
				estimateDetail.setName(rs.getString(EstimateDetail.NAME_TAG));
				estimateDetail.setCost(rs.getString(EstimateDetail.COST_TAG));
				estimateDetail.setMoney(rs.getString(EstimateDetail.MONEY_TAG));
				estimateDetail.setCount(rs.getString(EstimateDetail.COUNT_TAG));
				list.add(estimateDetail);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}

	// 견적 등록 하기
	public String addBudget(ClassParameter param){
		int pNum = param.getInt(P_NUM_TAG);
		
		Estimate estimate = new Estimate(); 
		estimate.setName(param.getString(Estimate.NAME_TAG));
		estimate.seteDate(param.getString(Estimate.EDATE_TAG));
		estimate.setMoney(param.getString(Estimate.MONEY_TAG));
		estimate.setUnit(param.getString(Estimate.UNIT_TAG));
		
		EstimateDetail ed = new EstimateDetail();
		ed.setName(param.getString(EstimateDetail.NAME_TAG));
		ed.setCost(param.getString(EstimateDetail.COST_TAG));
		ed.setMoney(param.getString(EstimateDetail.MONEY_TAG));
		ed.setCount(param.getString(EstimateDetail.COUNT_TAG));
		
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		JSONObject jsonObject = new JSONObject();
		
		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			SQL.append("INSERT INTO T_ESTIMATE (P_NUM, NAME, EDATE, MONEY, UNIT. WRITER, WRITERID, WRITE)");
			SQL.append("VALUES (?,?,?,?,?,?)");
			int index=1;
			String cols[] = {"INX"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			pstmt.setInt(index++, pNum);
			pstmt.setString(index++, estimate.getName());
			pstmt.setString(index++, estimate.geteDate());
			pstmt.setInt(index++, estimate.getMoney());
			pstmt.setString(index++, estimate.getUnit());
			pstmt.setString(index++, estimate.getWriter());
			pstmt.setString(index++, estimate.getWriterID());
			pstmt.setString(index++, estimate.getWrite());
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			int e_num = 0;
			if(rs.next()) e_num = rs.getInt(1);
			if(e_num > 0){
				int edNum = addEstimateDetail(ed);
				jsonObject.put("e_num", e_num);
				jsonObject.put("ed_num", edNum);
			}else{
				result = -1;
			}
			con.commit();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return jsonObject.toString();
		}
	}

	// 견적 등록 하기
	public int addBudgetMain(Estimate estimate){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		JSONObject jsonObject = new JSONObject();
		
		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO T_ESTIMATE (P_NUM, NAME, EDATE, MONEY, UNIT, WRITER, WRITERID, WRITE, STATE)");
			SQL.append("VALUES (?,?,?,?,?,?,?,?,?)");
			int index=1;
			String cols[] = {"INX"};
			
			pstmt = con.prepareStatement(SQL.toString(), cols);
			pstmt.setInt(index++, estimate.getP_num());
			pstmt.setString(index++, estimate.getName());
			pstmt.setString(index++, estimate.geteDate());
			pstmt.setInt(index++, estimate.getMoney());
			pstmt.setString(index++, estimate.getUnit());
			pstmt.setString(index++, estimate.getWriter());
			pstmt.setString(index++, estimate.getWriterID());
			pstmt.setString(index++, estimate.getWrite());
			pstmt.setString(index++, "0");
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 견적 삭제 하기
	public int delBudgetMain(int inx){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		
		try {
			con = DBCon.getConnection();
			SQL.append("UPDATE T_ESTIMATE SET STATE=9 WHERE INX=?");
			Show_Msg("delBudgetMain:"+SQL.toString());
			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, inx);
			result = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 견적 수정 하기
	public int modBudgetMain(String MODE, Estimate estimate, EstimateDetail ed){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		JSONObject jsonObject = new JSONObject();
		
		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			result = modBudgetMain(MODE, estimate, ed, con);
			con.commit();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 견적 수정 하기
	public int modBudgetMain(String MODE, Estimate estimate, EstimateDetail ed, Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		
		JSONObject jsonObject = new JSONObject();
		
		try {
			SQL.append("UPDATE T_ESTIMATE SET P_NUM=?, NAME=?, EDATE=?, MONEY=?, UNIT=? WHERE INX=?");
			Show_Msg("modBudgetMain:"+SQL.toString());
			int index=1;
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(index++, estimate.getP_num());
			pstmt.setString(index++, estimate.getName());
			pstmt.setString(index++, estimate.geteDate());
			pstmt.setInt(index++, estimate.getMoney());
			pstmt.setString(index++, estimate.getUnit());
			pstmt.setInt(index++, estimate.getInx());
			result = pstmt.executeUpdate();

			if(ed.getInx()==0) {
				result = addEstimateDetail(ed);
			} else {
				if(MODE.equals("DEL")) {
					result = delEstimateDetail(ed, con);
				} else {
					result = modEstimateDetail(ed, con);
				}
			}
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
	
	// 견적 상세 등록 하기
	private int addEstimateDetail(EstimateDetail ed){
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			con = DBCon.getConnection();
			SQL.append("INSERT INTO T_ESTIMATE_DETAIL (P_NUM, E_NUM, TYPE, NAME, COST, COUNT, MONEY) ");
			SQL.append("VALUES (?,?,?,?,?,?,?)");
			Show_Msg("addEstimateDetail:"+SQL.toString());
			
			int index=1;
			String cols[] = {"INX"};
			pstmt = con.prepareStatement(SQL.toString(), cols);
			
			pstmt.setInt(index++, ed.getP_num());
			pstmt.setInt(index++, ed.getE_num());
			pstmt.setString(index++, ed.getType());
			pstmt.setString(index++, ed.getName());
			pstmt.setInt(index++, ed.getCost());
			pstmt.setInt(index++, ed.getCount());
			pstmt.setInt(index++, ed.getMoney());
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			
			if(rs.next()) result = rs.getInt(1);
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
			} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}

	// 견적 상세 수정 하기
	private int modEstimateDetail(EstimateDetail ed, Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			SQL.append("UPDATE T_ESTIMATE_DETAIL SET P_NUM=?, E_NUM=?, TYPE=?, NAME=?, COST=?, COUNT=?, MONEY=? WHERE INX=?");
			
			Show_Msg("modEstimateDetail:"+SQL.toString());
			int index=1;
			pstmt = con.prepareStatement(SQL.toString());
			
			pstmt.setInt(index++, ed.getP_num());
			pstmt.setInt(index++, ed.getE_num());
			pstmt.setString(index++, ed.getType());
			pstmt.setString(index++, ed.getName());
			pstmt.setInt(index++, ed.getCost());
			pstmt.setInt(index++, ed.getCount());
			pstmt.setInt(index++, ed.getMoney());
			pstmt.setInt(index++, ed.getInx());
			result = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}

	// 견적 상세 삭제 하기
	private int delEstimateDetail(EstimateDetail ed, Connection con){
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;

		StringBuffer 		SQL 		= 	new StringBuffer();
		int					result 		= 	0;		

		try {
			SQL.append("DELETE FROM T_ESTIMATE_DETAIL WHERE INX=?");
			Show_Msg("delEstimateDetail:"+SQL.toString());
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, ed.getInx());
			result = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
		}
	}
}
