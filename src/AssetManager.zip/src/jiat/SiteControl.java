package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Logger;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import jiat.model.Menu;

public class SiteControl extends Builder {
	static Logger logger = Logger.getLogger(SiteControl.class.getSimpleName());
	
	public SiteControl(){
	}
	
	public ArrayList<Menu> getOptions(int type){
		ArrayList<Menu>		list 		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		
		try {
			con = DBCon.getConnection();
			list = getOptionItems(con, type);
		} catch(Exception e) {
//			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	private ArrayList<Menu> getOptionItems(Connection con, int type){
		ArrayList<Menu>		list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM OPTION_SELECT WHERE TYPE=? ORDER BY VALUE DESC");
			pstmt 	= con.prepareStatement(SQL.toString());
			
			pstmt.setInt(1, type);
			rs = pstmt.executeQuery();
			list = new ArrayList<Menu>();
			while(rs.next()){
				Menu result = new Menu();
				result.setMenuId(rs.getInt("VALUE"));
				result.setMenuName(rs.getString("NAME"));
				
				list.add(result);
			}
		}catch(Exception e) {
			e.printStackTrace();
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	public ArrayList<Menu> getMenus(){
		ArrayList<Menu>		list 		=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		
		try {
			con = DBCon.getConnection();
			list = getMenuItems(con);
		} catch(Exception e) {
//			Show_Err("01. Get_Machine_List_1:"+e.toString());
			e.printStackTrace();
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	private ArrayList<Menu> getMenuItems(Connection con){
		ArrayList<Menu>		list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		
		try{
			SQL.append("SELECT * FROM T_MENU order by MENU_ID ASC");
			pstmt 	= con.prepareStatement(SQL.toString());
			
			rs = pstmt.executeQuery();
			
			list = new ArrayList<Menu>();
			while(rs.next()){
				Menu result = new Menu();
				result.setMenuId(rs.getInt("MENU_ID"));
				result.setMenuName(rs.getString("NAME"));
				result.setUrl(rs.getString("PATH"));
				list.add(result);
			}
		}catch(Exception e) {
			Show_Err("02: "+e.toString());
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
}
