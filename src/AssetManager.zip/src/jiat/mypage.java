package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;

import builder.*;
import builder.web.*;
import builder.database.*;

public class mypage extends Builder {

	// 결재정보 가져오기 
	public LinkedList Get_Projects(String UID) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_PROJECT WHERE NVL(STATE,'0')<'5' AND WRITERID=? ORDER BY NUM DESC");
//			Show_Msg("Get_Projects:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, UID);		
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("INX", rs.getString("INX"));
    			result.setString("NUM", rs.getString("NUM"));
    			result.setString("TITLE", rs.getString("TITLE"));
    			result.setString("PDATE", rs.getString("PDATE"));
    			result.setString("KIND", rs.getString("KIND"));
    			result.setString("STATE", rs.getString("STATE"));
    			result.setString("C_COMPANY", rs.getString("C_COMPANY"));
    			list.add(result);
    		}
		} catch(Exception e) {
			Show_Err("Get_Projects:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		
	
	// 결재정보 가져오기 
	public LinkedList Get_Contracts(String UID) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();
		
		try {
			con = DBCon.getConnection();

			SQL.append("SELECT P.TITLE, P.C_COMPANY, C.* ").append(_blank)
				.append("FROM T_PROJECT P, T_CONTRACT C ").append(_blank)
				.append("WHERE P.INX=C.P_NUM AND ( (C.STATE='1' AND APPROVALID=?) ").append(_blank)
				.append("OR (C.STATE='2' AND APPROVALID2=?))");
//			Show_Msg("Get_Contracts:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, UID);		
			pstmt.setString(2, UID);		
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("P_NUM", rs.getString("P_NUM"));
    			result.setString("TITLE", rs.getString("TITLE"));
    			result.setString("C_COMPANY", rs.getString("C_COMPANY"));
    			result.setString("CONTENT", rs.getString("CONTENT"));
    			result.setString("CDATE", rs.getString("CDATE"));
    			result.setString("WRITER", rs.getString("WRITER"));
    			result.setString("MONEY", rs.getString("MONEY"));
    			result.setString("APPROVAL", rs.getString("APPROVAL"));
    			result.setString("APPROVAL2", rs.getString("APPROVAL2"));
    			list.add(result);
    		}
		} catch(Exception e) {
			logger.info("Get_Code:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

	// 계산서발행요청정보 가져오기 
	public LinkedList Get_Taxs() {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	new LinkedList();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT P.WRITER as P_WRITER, P.TITLE, P.C_COMPANY, T.* FROM T_PROJECT P, T_TAX T WHERE P.INX=T.P_NUM AND T.STATE='0'");
			Show_Msg("Get_Contracts:"+SQL.toString());
			
			pstmt = con.prepareStatement(SQL.toString());
    		rs = pstmt.executeQuery();
			
    		while(rs.next()) {
    			ClassParameter result = new ClassParameter();
    			result.setString("INX", rs.getString("INX"));
    			result.setString("TITLE", rs.getString("TITLE"));
    			result.setString("C_COMPANY", rs.getString("C_COMPANY"));
    			result.setString("P_NUM", rs.getString("P_NUM"));
    			result.setString("RDATE", rs.getString("RDATE"));
    			result.setString("RMONEY", rs.getString("RMONEY"));
    			result.setString("PDATE", rs.getString("PDATE"));
    			result.setString("WRITER", rs.getString("WRITER"));
    			result.setString("P_WRITER", rs.getString("P_WRITER"));
    			list.add(result);
    		}
		} catch(Exception e) {
			logger.info("Get_Code:"+e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
		}
	}		

}
