package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;

import builder.*;
import builder.web.*;
import builder.database.*;

public class code extends Builder {

	// 코드정보 가져오기 
	public String Get_Code(String pName) {
		Connection			con 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		StringBuffer 		SQL 		= 	new StringBuffer();
		String 				result 		= 	"";

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_CODE WHERE CODE=?");
			
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, pName);		
    		rs = pstmt.executeQuery();
			
    		if(rs.next()) {
    			result = rs.getString("VALUE");	
			}
		} catch(Exception e) {
			logger.info(e.toString());
		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
		}
	}		
}
