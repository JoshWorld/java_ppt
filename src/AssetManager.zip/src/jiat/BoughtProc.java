package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Logger;

import builder.Builder;
import builder.database.DBConnection;
import jiat.model.Bought;

public class BoughtProc extends Builder {
	final String TABLE_NAME;
	Logger logger;
	public BoughtProc(){
		TABLE_NAME = Get_Property("jumpdb.prefix")+"JB1000_VIEW_2"+Get_Property("jumpdb.suffix");
		logger = Logger.getLogger(BoughtProc.class.getSimpleName());
	}
	public ArrayList<Bought> getBought(){
		ArrayList<Bought>	list	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		
		try {
			con = DBCon.getConnection();
			list = getBought(con);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	public ArrayList<Bought> getBought(int p_num){
		ArrayList<Bought>	list	=	null;
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		
		try {
			con = DBCon.getConnection();
			list = getBought(con, p_num);
		}catch(Exception e) {
			Show_Err("01. Get_Machine_List_1:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	private ArrayList<Bought> getBought(Connection con){
		ArrayList<Bought>	list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		try{
			SQL.append("SELECT * FROM ").append(TABLE_NAME).append(' ')
			.append("WHERE PCMG_NUMB like 'P17%' ")
			.append(" ORDER BY PCMG_CODE DESC");
			
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			list = new ArrayList<Bought>();
			
			while(rs.next()){
				Bought bought = new Bought();
				bought.setPcmgCode(rs.getInt(Bought.PCMG_CODE));
				bought.setPcmgNumb(rs.getString(Bought.PCMG_NUMB));
				bought.setRatnCode(rs.getInt(Bought.RATN_CODE));
				bought.setPrchTitl(rs.getString(Bought.PRCH_TITL));
				bought.setDemdDate(rs.getString(Bought.DEMD_DATE));
				bought.setEstmTotl(rs.getInt(Bought.ESTM_TOTL));
				bought.setPrchStat(rs.getInt(Bought.PRCH_STAT));
				list.add(bought);
			}
		}catch(Exception e) {
			Show_Err("02: "+e.toString());
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
	public ArrayList<Bought> getBought(Connection con, int p_num){
//		pNum = pNum.replace('R', 'P');
		
		ArrayList<Bought>	list 		=	null;
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		try{
			SQL.append("SELECT * FROM ").append(TABLE_NAME).append(' ')
			.append("WHERE RATN_CODE = ? ")
			.append(" ORDER BY PCMG_CODE DESC");
			
			pstmt 	= con.prepareStatement(SQL.toString());
			pstmt.setInt(1, p_num);
			
			rs = pstmt.executeQuery();
			list = new ArrayList<Bought>();
			
			while(rs.next()){
				Bought bought = new Bought();
				bought.setPcmgCode(rs.getInt(Bought.PCMG_CODE));
				bought.setPcmgNumb(rs.getString(Bought.PCMG_NUMB));
				bought.setRatnCode(rs.getInt(Bought.RATN_CODE));
				bought.setPrchTitl(rs.getString(Bought.PRCH_TITL));
				bought.setDemdDate(rs.getString(Bought.DEMD_DATE));
				bought.setEstmTotl(rs.getInt(Bought.ESTM_TOTL));
				bought.setPrchStat(rs.getInt(Bought.PRCH_STAT));
				list.add(bought);
			}
		}catch(Exception e) {
			Show_Err("02: "+e.toString());
  		}finally{
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}
}
