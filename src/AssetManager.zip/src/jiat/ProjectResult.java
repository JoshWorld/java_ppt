package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import builder.web.Utility;

public class ProjectResult extends Builder {

	
	public ClassParameter getResult(int pInx) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT A.*, B.JASN_NAME AS A_NAME FROM T_RESULT A, ");
			SQL.append(Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("B WHERE A.A_NUM=B.JASN_NUMB AND A.INX=?");
			Show_Msg("getResult:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pInx);
			rs = pstmt.executeQuery();
			if(rs.next()) {
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("P_NUM", rs.getObject("P_NUM"));	
	  			result.setObject("A_NUM", rs.getObject("A_NUM"));	
	  			result.setObject("A_NAME", rs.getObject("A_NAME"));	
	  			result.setObject("YM", rs.getObject("YM"));	
	  			result.setObject("UHOUR", rs.getObject("UHOUR"));	
	  			result.setObject("EHOUR", rs.getObject("EHOUR"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
			}
		} catch(Exception e) {
			Show_Err("getResult:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}		

	public LinkedList getResults(int pNum) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
 
			SQL.append("SELECT A.*, B.JASN_NAME AS A_NAME, SUM(NVL(UHOUR,0)+NVL(EHOUR,0)) OVER (PARTITION BY A_NUM) AS SHOUR  FROM T_RESULT A, ");
			SQL.append(Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" ");
			SQL.append("B WHERE A.A_NUM=B.JASN_NUMB AND P_NUM=? ORDER BY A_NUM, YM");
			
//			Show_Msg("getResults:"+SQL.toString());
//			logger.info(SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("P_NUM", rs.getObject("P_NUM"));	
	  			result.setObject("A_NUM", rs.getObject("A_NUM"));	
	  			result.setObject("A_NAME", rs.getObject("A_NAME"));	
	  			result.setObject("YM", rs.getObject("YM"));	
	  			result.setObject("UHOUR", rs.getObject("UHOUR"));	
	  			result.setObject("EHOUR", rs.getObject("EHOUR"));	
	  			result.setObject("SHOUR", rs.getObject("SHOUR"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("getResults:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
  		}
	}		
	
	
	// 프로젝트에 사용된 자산목록 가져오기
	public LinkedList Get_Asset_List(int pNum) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_Asset_List(pNum, 0, con);	
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	
	public LinkedList Get_Asset_List(int pNum, int rNum, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			// 기술원 DB가 Full Outer Join 을 사용하면 Socket이 끊기는 현상이 발생 => Left Outer Join + Union + Right Outer Join 으로 변경함.(2017.04.19)
			SQL.append(" 	SELECT Z.*,	 ");
			SQL.append(" 	  A.JASN_NUMB AS A_NUM,	 ");
			SQL.append(" 	  A.JASN_NAME AS A_NAME	 ");
			SQL.append(" 	FROM (	 ");
			SQL.append(" 	  SELECT CASE WHEN X.A_NUM IS NULL THEN Y.A_NUM ELSE X.A_NUM END A_NUM, X.USE,	 ");
			SQL.append(" 	    NVL(Y.INX,0) AS RD_NUM,	 ");
			SQL.append(" 	    Y.UHOUR,	 ");
			SQL.append(" 	    Y.EHOUR	 ");
			SQL.append(" 	  FROM	 ");
			SQL.append(" 	    (SELECT A_NUM,	 ");
			SQL.append(" 	      SUM(USE*COUNT) AS USE	 ");
			SQL.append(" 	    FROM	 ");
			SQL.append(" 	      (SELECT A_NUM,	 ");
			SQL.append(" 	        CD.USE,	 ");
			SQL.append(" 	        ED.COUNT	 ");
			SQL.append(" 	      FROM T_COST_DETAIL CD,	 ");
			SQL.append(" 	        T_ESTIMATE_DETAIL ED,	 ");
			SQL.append(" 	        T_MACHINE M,	 ");
			SQL.append(" 	        T_MA_ASSET MA	 ");
			SQL.append(" 	      WHERE CD.D_NUM=ED.INX	 ");
			SQL.append(" 	      AND ED.E_NUM IN	 ");
			SQL.append(" 	        (SELECT A.INX	 ");
			SQL.append(" 	        FROM	 ");
			SQL.append(" 	          (SELECT INX	 ");
			SQL.append(" 	          FROM T_ESTIMATE	 ");
			SQL.append(" 	          WHERE NVL(STATE,'0') <> '9'	 ");
			SQL.append(" 	          AND P_NUM             =?	 ");
			SQL.append(" 	          ORDER BY EDATE DESC,	 ");
			SQL.append(" 	            INX DESC	 ");
			SQL.append(" 	          ) A	 ");
			SQL.append(" 	        WHERE ROWNUM =1	 ");
			SQL.append(" 	        )	 ");
			SQL.append(" 	      AND CD.M_NUM =M.INX	 ");
			SQL.append(" 	      AND M.STATE <>'9'	 ");
			SQL.append(" 	      AND MA.M_NUM =M.INX	 ");
			SQL.append(" 	      AND MA.STATE<>'9'	 ");
			SQL.append(" 	      AND CD.P_NUM =?	 ");
			SQL.append(" 	      )	 ");
			SQL.append(" 	    GROUP BY A_NUM	 ");
			SQL.append(" 	    ) X	 ");
			SQL.append(" 	  LEFT OUTER JOIN	 ");
			SQL.append(" 	    (SELECT * FROM T_RESULT_DETAIL WHERE R_NUM=?	 ");
			SQL.append(" 	    ) Y	 ");
			SQL.append(" 	  ON X.A_NUM=Y.A_NUM	 ");
			SQL.append(" 	  UNION	 ");
			SQL.append(" 	  SELECT CASE WHEN X.A_NUM IS NULL THEN Y.A_NUM ELSE X.A_NUM END A_NUM, X.USE,	 ");
			SQL.append(" 	    NVL(Y.INX,0) AS RD_NUM,	 ");
			SQL.append(" 	    Y.UHOUR,	 ");
			SQL.append(" 	    Y.EHOUR	 ");
			SQL.append(" 	  FROM	 ");
			SQL.append(" 	    (SELECT A_NUM,	 ");
			SQL.append(" 	      SUM(USE*COUNT) AS USE	 ");
			SQL.append(" 	    FROM	 ");
			SQL.append(" 	      (SELECT A_NUM,	 ");
			SQL.append(" 	        CD.USE,	 ");
			SQL.append(" 	        ED.COUNT	 ");
			SQL.append(" 	      FROM T_COST_DETAIL CD,	 ");
			SQL.append(" 	        T_ESTIMATE_DETAIL ED,	 ");
			SQL.append(" 	        T_MACHINE M,	 ");
			SQL.append(" 	        T_MA_ASSET MA	 ");
			SQL.append(" 	      WHERE CD.D_NUM=ED.INX	 ");
			SQL.append(" 	      AND ED.E_NUM IN	 ");
			SQL.append(" 	        (SELECT A.INX	 ");
			SQL.append(" 	        FROM	 ");
			SQL.append(" 	          (SELECT INX	 ");
			SQL.append(" 	          FROM T_ESTIMATE	 ");
			SQL.append(" 	          WHERE NVL(STATE,'0') <> '9'	 ");
			SQL.append(" 	          AND P_NUM             =?	 ");
			SQL.append(" 	          ORDER BY EDATE DESC,	 ");
			SQL.append(" 	            INX DESC	 ");
			SQL.append(" 	          ) A	 ");
			SQL.append(" 	        WHERE ROWNUM =1	 ");
			SQL.append(" 	        )	 ");
			SQL.append(" 	      AND CD.M_NUM =M.INX	 ");
			SQL.append(" 	      AND M.STATE <>'9'	 ");
			SQL.append(" 	      AND MA.M_NUM =M.INX	 ");
			SQL.append(" 	      AND MA.STATE<>'9'	 ");
			SQL.append(" 	      AND CD.P_NUM =?	 ");
			SQL.append(" 	      )	 ");
			SQL.append(" 	    GROUP BY A_NUM	 ");
			SQL.append(" 	    ) X	 ");
			SQL.append(" 	  RIGHT OUTER JOIN	 ");
			SQL.append(" 	    (SELECT * FROM T_RESULT_DETAIL WHERE R_NUM=?	 ");
			SQL.append(" 	    ) Y	 ");
			SQL.append(" 	  ON X.A_NUM=Y.A_NUM	 ");
			SQL.append(" 	  ) Z,	 ");
			SQL.append( 	  Get_Property("jumpdb.prefix")+"JF2000_VIEW"+Get_Property("jumpdb.suffix")+" A 	 ");
			SQL.append(" 	WHERE Z.A_NUM =A.JASN_NUMB	 ");

			Show_Msg("Get_Asset_List:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			pstmt.setInt(2, pNum);
			pstmt.setInt(3, rNum);
			pstmt.setInt(4, pNum);
			pstmt.setInt(5, pNum);
			pstmt.setInt(6, rNum);
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("A_NUM", rs.getObject("A_NUM"));	
	  			result.setObject("A_NAME", rs.getObject("A_NAME"));	
	  			result.setObject("USE", rs.getObject("USE"));	
	  			result.setObject("RD_NUM", rs.getObject("RD_NUM"));	
	  			result.setObject("UHOUR", rs.getObject("UHOUR"));	
	  			result.setObject("EHOUR", rs.getObject("EHOUR"));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_Asset_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		

	public int modifyResult(ClassParameter result) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int 				rtn 		= 	0;

		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			if(result.getInt("INX")==0) {
				rtn = addResult(result, con);	
			} else {
				rtn = modResult(result, con);	
			}
			con.commit();
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return rtn;
  		}
	}

	public int delResult(ClassParameter result) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		int 				rtn 		= 	0;

		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			if(result.getInt("INX")==0) {
			} else {
				rtn = delResult(result, con);	
			}
			con.commit();
		} catch(Exception e) {
			Show_Err("delResult:"+e.toString());
  		} finally {
			Close_Con(con);
			return rtn;
  		}
	}

	public int addResult(ClassParameter result, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				rtn			= 	0;
		try {
			SQL.append("INSERT INTO T_RESULT(P_NUM, A_NUM, YM, UHOUR, EHOUR, WRITER, WRITERID, WRITE) ");
			SQL.append(" VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
			Show_Msg("addResult:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setString(index++, result.getString("P_NUM"));
			pstmt.setString(index++, result.getString("A_NUM"));
			pstmt.setString(index++, result.getString("YM"));
			pstmt.setString(index++, result.getString("UHOUR"));
			pstmt.setString(index++, result.getString("EHOUR"));
			pstmt.setString(index++, result.getString("WRITER"));
			pstmt.setString(index++, result.getString("WRITERID"));
			pstmt.setString(index++, result.getString("WRITE"));

			rtn = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_PS(pstmt);
			return rtn;
		}
	}	
	public int modResult(ClassParameter result, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				rtn 		= 	0;

		try {
			SQL.append("UPDATE T_RESULT SET P_NUM=?, A_NUM=?, YM=?, UHOUR=?, EHOUR=?, WRITER=?, WRITERID=?, WRITE=? WHERE INX=?");
			Show_Msg("modResult:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			int index = 1;
			pstmt.setString(index++, result.getString("P_NUM"));
			pstmt.setString(index++, result.getString("A_NUM"));
			pstmt.setString(index++, result.getString("YM"));
			pstmt.setString(index++, result.getString("UHOUR"));
			pstmt.setString(index++, result.getString("EHOUR"));
			pstmt.setString(index++, result.getString("WRITER"));
			pstmt.setString(index++, result.getString("WRITERID"));
			pstmt.setString(index++, result.getString("WRITE"));
			pstmt.setString(index++, result.getString("INX"));

			rtn = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_PS(pstmt);
			return rtn;
		}
	}	
	public int delResult(ClassParameter result, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				rtn 		= 	0;

		try {
			SQL.append("DELETE FROM T_RESULT WHERE INX=? ");
			Show_Msg("delResult:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setString(1, result.getString("INX"));

			rtn = pstmt.executeUpdate();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_PS(pstmt);
			return rtn;
		}
	}		

	public int initResult(int pNum) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();

		PreparedStatement 	pstmt 		= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				rtn 		= 	0;

		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);

			SQL.append("INSERT INTO T_RESULT(P_NUM, A_NUM, YM, UHOUR) ");
			SQL.append("SELECT ?, A_NUM, TO_CHAR(sysdate,'YYYY-MM'), SUM(USE) FROM T_COST_DETAIL A, T_MA_ASSET B  ");
			SQL.append("WHERE  A.TYPE=0 AND B.STATE<>'9' AND A.M_NUM=B.M_NUM AND A.P_NUM=?  ");
			SQL.append("AND A.E_NUM IN (SELECT INX FROM (SELECT INX FROM T_ESTIMATE WHERE P_NUM=? AND  STATE<>'9' ORDER BY EDATE DESC, INX DESC) WHERE ROWNUM=1)  ");
			SQL.append("GROUP BY A_NUM  ");
//			Show_Msg("initResult:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			pstmt.setInt(2, pNum);
			pstmt.setInt(3, pNum);

			rtn = pstmt.executeUpdate();

			con.commit();
		} catch(Exception e) {
	  		if(con != null) con.rollback();
			e.printStackTrace();
  		} finally {
			Close_PS(pstmt);
			Close_Con(con);
			return rtn;
		}
	}		

	public int modifyResultMain(ClassParameter result) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		PreparedStatement 	pstmt 		= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		int 				rtn 		= 	0;

		try {
			con = DBCon.getConnection();
			con.setAutoCommit(false);
			if(getResultMain(result.getInt("P_NUM")).getString("P_NUM").equals("")) {
				SQL.append("INSERT INTO T_RESULT_MAIN(P_NUM, SDATE, EDATE, WRITER, WRITERID, WRITE) VALUES(?, ?, ?, ?, ?, ?)");
				Show_Msg("modifyResultMain:"+SQL.toString());
						
				pstmt = con.prepareStatement(SQL.toString());
				int index = 1;
				pstmt.setString(index++, result.getString("P_NUM"));
				pstmt.setString(index++, result.getString("SDATE"));
				pstmt.setString(index++, result.getString("EDATE"));
				pstmt.setString(index++, result.getString("WRITER"));
				pstmt.setString(index++, result.getString("WRITERID"));
				pstmt.setString(index++, result.getString("WRITE"));
				rtn = pstmt.executeUpdate();
			} else {
				SQL.append("UPDATE T_RESULT_MAIN SET SDATE=?, EDATE=?, WRITER=?, WRITERID=?, WRITE=? WHERE P_NUM=?");
				Show_Msg("modifyResultMain:"+SQL.toString());
						
				pstmt = con.prepareStatement(SQL.toString());
				int index = 1;
				pstmt.setString(index++, result.getString("SDATE"));
				pstmt.setString(index++, result.getString("EDATE"));
				pstmt.setString(index++, result.getString("WRITER"));
				pstmt.setString(index++, result.getString("WRITERID"));
				pstmt.setString(index++, result.getString("WRITE"));
				pstmt.setString(index++, result.getString("P_NUM"));
				rtn = pstmt.executeUpdate();
			}
			con.commit();
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_PS(pstmt);
			Close_Con(con);
			return rtn;
  		}
	}
	public ClassParameter getResultMain(int pNum) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		ClassParameter 		result 		= 	new ClassParameter();

		try {
			con = DBCon.getConnection();

			SQL.append("SELECT * FROM T_RESULT_MAIN WHERE P_NUM=?");
//			logger.info(SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			if(rs.next()) {
	  			result.setObject("P_NUM", rs.getObject("P_NUM"));	
	  			result.setObject("SDATE", rs.getObject("SDATE"));	
	  			result.setObject("EDATE", rs.getObject("EDATE"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));	
			}
		} catch(Exception e) {
			Show_Err("getResultMain:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return result;
  		}
	}	
	
	
	public LinkedList getResultsList(int pNum) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
 
			SQL.append("SELECT * FROM T_RESULT_MAIN WHERE P_NUM=?");
			Show_Msg("getResults:"+SQL.toString());
					
			pstmt = con.prepareStatement(SQL.toString());
			pstmt.setInt(1, pNum);
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
				result.setObject("P_NUM", rs.getObject("P_NUM"));	
	  			result.setObject("SDATE", rs.getObject("SDATE"));	
	  			result.setObject("EDATE", rs.getObject("EDATE"));	
	  			result.setObject("WRITER", rs.getObject("WRITER"));	
	  			result.setObject("WRITERID", rs.getObject("WRITERID"));	
	  			result.setObject("WRITE", rs.getObject("WRITE"));
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("getResults:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			Close_Con(con);
			return list;
  		}
	}
	
}
