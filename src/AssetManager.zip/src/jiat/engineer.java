package jiat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.LinkedList;

import builder.Builder;
import builder.database.DBConnection;
import builder.web.ClassParameter;
import builder.web.Utility;
import jiat.model.Engineer;

public class engineer extends Builder {

	public String Search_String(ClassParameter pRow) { return ""; }

	public int Current_Page(ClassParameter pRow) {
		int Current_Page = 0;
		Current_Page = (pRow.getString("page")==null)?1:Utility.Check_Number(pRow.getString("page"), 1);
		return Current_Page;
	}

	// 엔지니어 목록 가져오기
	public LinkedList Get_List(ClassParameter pRow) {
		Connection			con 		=	null;
		DBConnection 		DBCon 		= 	new DBConnection();
		LinkedList 			list 		= 	null;

		try {
			con = DBCon.getConnection();
			list = Get_List(pRow, con);	
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return list;
  		}
	}
	public HashMap<String, Engineer> getAllEngineerMap(){
		Connection					con 		=	null;
		DBConnection 				DBCon 		= 	new DBConnection();
		HashMap<String, Engineer> 	result 		= 	null;
		try {
			con = DBCon.getConnection();
			result = getAllEngineerMap(con);
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_Con(con);
			return result;
  		}
	}
	private HashMap<String, Engineer> getAllEngineerMap(Connection con){
		PreparedStatement 			pstmt 		= 	null;
		ResultSet 					rs 			= 	null;
		StringBuffer 				SQL 		= 	new StringBuffer();
		HashMap<String, Engineer> 	result 		= 	null;
		try {
			SQL.append("SELECT * FROM T_ENGINEER ORDER BY NAME ASC");
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			result = new HashMap<String, Engineer>();
			
			while(rs.next()) {
				Engineer engr = new Engineer();
				
	  			engr.setInx(rs.getInt("INX"));	
	  			engr.setName(rs.getString("NAME"));	
	  			engr.setCost(rs.getInt("COST"));	
	  			result.put(engr.getName(), engr);
			}
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return result;
  		}
	}
	private LinkedList Get_List(ClassParameter pRow, Connection con) {
		PreparedStatement 	pstmt 		= 	null;
		ResultSet 			rs 			= 	null;
		StringBuffer 		SQL 		= 	new StringBuffer();
		LinkedList 			list 		= 	null;

		try {
			SQL.append("SELECT * FROM T_ENGINEER ORDER BY NAME ASC");
//			Show_Msg("Get_List:"+SQL.toString());
					
			pstmt 	= con.prepareStatement(SQL.toString());
			rs = pstmt.executeQuery();
			list = new LinkedList();
			while(rs.next()) {
				ClassParameter result = new ClassParameter();
	  			result.setObject("INX", rs.getObject("INX"));	
	  			result.setObject("NAME", rs.getObject("NAME"));	
	  			result.setObject("COST", rs.getObject("COST"));	
	  			list.add(result);
			}
		} catch(Exception e) {
			Show_Err("Get_List:"+e.toString());
  		} finally {
			Close_RS(rs);
			Close_PS(pstmt);
			return list;
  		}
	}		

}
