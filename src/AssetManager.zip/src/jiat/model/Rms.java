package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Rms {
	public static final String CODE_TAG = "CODE";
	public static final String NAME_TAG = "NAME";
	public static final String CUR_PERIOD = "CURR_PERIOD";
	String code;
	String name;
	String curPeriod;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getCurPeriod() {
		return curPeriod;
	}
	public void setCurPeriod(String curPeriod) {
		this.curPeriod = curPeriod;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
