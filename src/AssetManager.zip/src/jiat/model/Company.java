package jiat.model;

public class Company {
	public static final String USER_IDNT_TAG = "USER_IDNT";
	public static final String COMP_KNAM_TAG = "COMP_KNAM";
	public static final String COMP_ENAM_TAG = "COMP_ENAM";
	public static final String PRSN_NAME_TAG = "PRSN_NAME";
	public static final String COMP_LOCN_TAG = "COMP_LOCN";
	public static final String COMP_ZIPC_TAG = "COMP_ZIPC";
	public static final String COMP_ADDR_TAG = "COMP_ADDR";
	public static final String COMP_PHON_TAG = "COMP_PHON";
	public static final String COMP_FAXN_TAG = "COMP_FAXN";
	public static final String HTTP_NAME_TAG = "HTTP_NAME";
	public static final String COMP_SRNM_TAG = "COMP_SRNM";
	public static final String WRTE_IDNT_TAG = "WRTE_IDNT";
	public static final String WRTE_DATE_TAG = "WRTE_DATE";
	public static final String UPDT_DATE_TAG = "UPDT_DATE";
	
	String userIdnt;
	String kname;
	String ename;
	String presidentName;
	String location;
	String zipcode;
	String address;
	String phone;
	String faxNumber;
	String homepageName;
	String srName;
	String writerIdnt;
	String writeDate;
	String updateDate;
	public String getUserIdnt() {
		return userIdnt;
	}
	public void setUserIdnt(String userIdnt) {
		this.userIdnt = userIdnt;
	}
	public String getKname() {
		return kname;
	}
	public void setKname(String kname) {
		this.kname = kname;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getPresidentName() {
		return presidentName;
	}
	public void setPresidentName(String presidentName) {
		this.presidentName = presidentName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	public String getHomepageName() {
		return homepageName;
	}
	public void setHomepageName(String homepageName) {
		this.homepageName = homepageName;
	}
	public String getSrName() {
		return srName;
	}
	public void setSrName(String srName) {
		this.srName = srName;
	}
	public String getWriterIdnt() {
		return writerIdnt;
	}
	public void setWriterIdnt(String writerIdnt) {
		this.writerIdnt = writerIdnt;
	}
	public String getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(String writeDate) {
		this.writeDate = writeDate;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	public static String getUserIdntTag() {
		return USER_IDNT_TAG;
	}
	public static String getCompKnamTag() {
		return COMP_KNAM_TAG;
	}
	public static String getCompEnamTag() {
		return COMP_ENAM_TAG;
	}
	public static String getPrsnNameTag() {
		return PRSN_NAME_TAG;
	}
	public static String getCompLocnTag() {
		return COMP_LOCN_TAG;
	}
	public static String getCompZipcTag() {
		return COMP_ZIPC_TAG;
	}
	public static String getCompAddrTag() {
		return COMP_ADDR_TAG;
	}
	public static String getCompPhonTag() {
		return COMP_PHON_TAG;
	}
	public static String getCompFaxnTag() {
		return COMP_FAXN_TAG;
	}
	public static String getHttpNameTag() {
		return HTTP_NAME_TAG;
	}
	public static String getCompSrnmTag() {
		return COMP_SRNM_TAG;
	}
	public static String getWrteIdntTag() {
		return WRTE_IDNT_TAG;
	}
	public static String getWrteDateTag() {
		return WRTE_DATE_TAG;
	}
	public static String getUpdtDateTag() {
		return UPDT_DATE_TAG;
	}
}
