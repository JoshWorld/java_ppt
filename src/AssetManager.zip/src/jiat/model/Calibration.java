package jiat.model;

import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

public class Calibration {
	public static final String OPPR_CODE_TAG = "OPPR_CODE";
	public static final String OPPR_NUMB_TAG = "OPPR_NUMB";
	public static final String JASN_CODE_TAG = "JASN_CODE";
	public static final String STRT_DATE_TAG = "STRT_DATE";
	public static final String ENDS_DATE_TAG = "ENDS_DATE";
	public static final String COMP_NAME_TAG = "COMP_NAME";
	public static final String MONY_TOTL_TAG = "MONY_TOTL";
	public static final String RMRK_NOTE_TAG = "RMRK_NOTE";
	public static final String WRTE_IDNT_TAG = "WRTE_IDNT";
	public static final String WRTE_DATE_TAG = "WRTE_DATE";
	public static final String UPDT_DATE_TAG = "UPDT_DATE";
	public static final String ELTR_NUMB_TAG = "ELTR_NUMB";
	
	int opprCode;
	String opprNumb;
	int jasnCode;
	String strtDate;
	String endsDate;
	String compName;
	int monyTotl;
	String rmrkNote;
	String wrteIdnt;
	String wrteDate;
	String updtDate;
	int eltrNumb;
	
	
	
	
	public int getOpprCode() {
		return opprCode;
	}
	public void setOpprCode(int opprCode) {
		this.opprCode = opprCode;
	}
	public String getOpprNumb() {
		return opprNumb;
	}
	public void setOpprNumb(String opprNumb) {
		this.opprNumb = opprNumb;
	}
	public int getJasnCode() {
		return jasnCode;
	}
	public void setJasnCode(int jasnCode) {
		this.jasnCode = jasnCode;
	}
	public String getStrtDate() {
		return strtDate;
	}
	public void setStrtDate(String strtDate) {
		this.strtDate = strtDate;
	}
	public String getEndsDate() {
		return endsDate;
	}
	public void setEndsDate(String endsDate) {
		this.endsDate = endsDate;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getMonyTotl() {
		return monyTotl;
	}
	public void setMonyTotl(int monyTotl) {
		this.monyTotl = monyTotl;
	}
	public String getRmrkNote() {
		return rmrkNote;
	}
	public void setRmrkNote(String rmrkNote) {
		this.rmrkNote = rmrkNote;
	}
	public String getWrteIdnt() {
		return wrteIdnt;
	}
	public void setWrteIdnt(String wrteIdnt) {
		this.wrteIdnt = wrteIdnt;
	}
	public String getWrteDate() {
		return wrteDate;
	}
	public void setWrteDate(String wrteDate) {
		this.wrteDate = wrteDate;
	}
	public String getUpdtDate() {
		return updtDate;
	}
	public void setUpdtDate(String updtDate) {
		this.updtDate = updtDate;
	}
	public int getEltrNumb() {
		return eltrNumb;
	}
	public void setEltrNumb(int eltrNumb) {
		this.eltrNumb = eltrNumb;
	}

	
	@Override
	public String toString() {
		return toJSONObject(this).toString();
	}
	public static Calibration parseCalibration(JSONObject json){
		Calibration result = new Calibration();
		if(json.has(OPPR_CODE_TAG)){
			result.setOpprCode(json.getInt(OPPR_CODE_TAG));
		}
		if(json.has(OPPR_NUMB_TAG)){
			result.setOpprNumb(json.getString(OPPR_NUMB_TAG));
		}
		if(json.has(JASN_CODE_TAG)){
			result.setJasnCode(json.getInt(JASN_CODE_TAG));
		}
		if(json.has(STRT_DATE_TAG)){
			result.setStrtDate(json.getString(STRT_DATE_TAG));
		}
		if(json.has(ENDS_DATE_TAG)){
			result.setEndsDate(json.getString(ENDS_DATE_TAG));
		}
		if(json.has(COMP_NAME_TAG)){
			result.setCompName(json.getString(COMP_NAME_TAG));
		}
		if(json.has(MONY_TOTL_TAG)){
			result.setMonyTotl(json.getInt(MONY_TOTL_TAG));
		}
		if(json.has(RMRK_NOTE_TAG)){
			result.setRmrkNote(json.getString(RMRK_NOTE_TAG));
		}
		if(json.has(WRTE_IDNT_TAG)){
			result.setWrteIdnt(json.getString(WRTE_IDNT_TAG));
		}
		if(json.has(WRTE_DATE_TAG)){
			result.setWrteDate(json.getString(WRTE_DATE_TAG));
		}
		if(json.has(UPDT_DATE_TAG)){
			result.setUpdtDate(json.getString(UPDT_DATE_TAG));
		}
		if(json.has(ELTR_NUMB_TAG)){
			result.setEltrNumb(json.getInt(ELTR_NUMB_TAG));
		}
		
		return result;
	}
	public static JSONObject toJSONObject(Calibration con){
		JSONObject result = new JSONObject();
		
		result.put(OPPR_CODE_TAG, con.getOpprCode());
		result.put(OPPR_NUMB_TAG, con.getOpprNumb());
		result.put(JASN_CODE_TAG, con.getJasnCode());
		result.put(STRT_DATE_TAG, con.getStrtDate());
		result.put(ENDS_DATE_TAG, con.getEndsDate());
		result.put(COMP_NAME_TAG, con.getCompName());
		result.put(MONY_TOTL_TAG, con.getMonyTotl());
		result.put(RMRK_NOTE_TAG, con.getRmrkNote());
		result.put(WRTE_IDNT_TAG, con.getWrteIdnt());
		result.put(WRTE_DATE_TAG, con.getWrteDate());
		result.put(UPDT_DATE_TAG, con.getUpdtDate());
		result.put(ELTR_NUMB_TAG, con.getEltrNumb());
		
		return result;
	}
	
}