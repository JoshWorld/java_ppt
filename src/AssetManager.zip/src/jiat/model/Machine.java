package jiat.model;

import org.json.JSONObject;

public class Machine {
	public static final String INX_TAG = "INX";
	public static final String CODE_TAG = "CODE";
	public static final String NAME_TAG = "NAME";
	public static final String WRITER_TAG = "WRITER";
	public static final String WRITERID_TAG = "WRITERID";
	public static final String WRITE_TAG = "WRITE";
	public static final String ORATE_TAG = "ORATE";
	public static final String STATE_TAG = "STATE";
	
	int inx;
	String code;
	String name;
	String writer;
	String writerid;
	String write;
	int orate;
	String state;
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWriterID() {
		return writerid;
	}
	public void setWriterID(String writerid) {
		this.writerid = writerid;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	public int getOrate() {
		return orate;
	}
	public void setOrate(int orate) {
		this.orate = orate;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		JSONObject json = new JSONObject();
		json.put(INX_TAG, getInx());
		json.put(CODE_TAG, getCode());
		json.put(NAME_TAG, getName());
		json.put(WRITER_TAG, getWriter());
		json.put(WRITERID_TAG, getWriterID());
		json.put(WRITE_TAG, getWrite());
		json.put(ORATE_TAG, getOrate());
		json.put(STATE_TAG, getState());
		return json.toString();
	}
}
