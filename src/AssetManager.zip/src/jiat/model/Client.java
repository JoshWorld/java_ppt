package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.json.JSONException;
import org.json.JSONObject;

public class Client {
	public static final String ClientTag = Client.class.getSimpleName();
	int    mgnrNumb;
	String userIdnt;
	String bscrIdnt;
	String bscrName;
	String bscrHpnb;
	String bscrMail;
	String compKnam;
	String compLocn;
	
	public static final String MGNR_NUMB = "MGNR_NUMB";
	public static final String USER_IDNT = "USER_IDNT";
	public static final String BSCR_IDNT = "BSCR_IDNT";
	public static final String BSCR_NAME = "BSCR_NAME";
	public static final String BSCR_HPNB = "BSCR_HPNB";
	public static final String BSCR_MAIL = "BSCR_MAIL";
	public static final String COMP_KNAM = "COMP_KNAM";
	public static final String COMP_LOCN = "COMP_LOCN";
	
	public int getMgnrNumb() {
		return mgnrNumb;
	}
	public void setMgnrNumb(int mgnrNumb) {
		this.mgnrNumb = mgnrNumb;
	}
	public String getUserIdnt() {
		return userIdnt;
	}
	public void setUserIdnt(String userIdnt) {
		this.userIdnt = userIdnt;
	}
	public String getBscrIdnt() {
		return bscrIdnt;
	}
	public void setBscrIdnt(String bscrIdnt) {
		this.bscrIdnt = bscrIdnt;
	}
	public String getBscrName() {
		return bscrName;
	}
	public void setBscrName(String bscrName) {
		this.bscrName = bscrName;
	}
	public String getBscrHpnb() {
		return bscrHpnb;
	}
	public void setBscrHpnb(String bscrHpnb) {
		this.bscrHpnb = bscrHpnb;
	}
	public String getBscrMail() {
		return bscrMail;
	}
	public void setBscrMail(String bscrMail) {
		this.bscrMail = bscrMail;
	}
	public String getCompKnam() {
		return compKnam;
	}
	public void setCompKnam(String compKnam) {
		this.compKnam = compKnam;
	}
	public String getCompLocn() {
		return compLocn;
	}
	public void setCompLocn(String compLocn) {
		this.compLocn = compLocn;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
