package jiat.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;

public class FileInfo {
	public static final String INX_TAG = "INX";
	public static final String CNUM_TAG = "C_NUM";
	public static final String TYPE_TAG = "TYPE";
	public static final String PNUM_TAG = "P_NUM";
	public static final String NAME_TAG = "NAME";
	public static final String FNAME_TAG = "FNAME";
	
	int inx;
	int cNum;
	int type;
	int pNum;
	String name;
	String fName;
	
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getcNum() {
		return cNum;
	}
	public void setcNum(int cNum) {
		this.cNum = cNum;
	}
	public void setcNum(String cNum){
		try{
			this.cNum = Integer.parseInt(cNum);
		}catch(NumberFormatException e){
			e.printStackTrace();
		}
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(String pNum){
		try{
			this.pNum = Integer.parseInt(pNum);
		}catch(NumberFormatException e){
			e.printStackTrace();
		}
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	@Override
	public String toString() {
		JSONObject result = new JSONObject();
		result.put(INX_TAG, getInx());
		result.put(CNUM_TAG, getcNum());
		result.put(TYPE_TAG, getType());
		result.put(FNAME_TAG, getfName());
		result.put(PNUM_TAG, getpNum());
		result.put(NAME_TAG, getName());
		return result.toString();
	}
	public JSONObject toJSONObject() {
		JSONObject result = new JSONObject();
		result.put(INX_TAG, getInx());
		result.put(CNUM_TAG, getcNum());
		result.put(TYPE_TAG, getType());
		result.put(PNUM_TAG, getpNum());
		result.put(NAME_TAG, getName());
		result.put(FNAME_TAG, getfName());
		return result;
	}
	public static FileInfo resultSetToFileInfo(ResultSet rs) throws SQLException{
		FileInfo result = new FileInfo();
		result.setInx(rs.getInt(INX_TAG));
		result.setcNum(rs.getInt(CNUM_TAG));
		result.setType(rs.getInt(TYPE_TAG));
		result.setName(rs.getString(NAME_TAG));
		result.setpNum(rs.getInt(PNUM_TAG));
		result.setfName(rs.getString(FNAME_TAG));
		return result;
	}
}
