package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Engineer {
	public static final String INX_TAG = "INX";
	public static final String NAME_TAG = "NAME";
	public static final String COST_TAG = "COST";
	
	int inx;
	String name;
	int cost;
	
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
