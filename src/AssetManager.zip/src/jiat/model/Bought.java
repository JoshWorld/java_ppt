package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class Bought {
	public static final String PCMG_CODE = "PCMG_CODE";
	public static final String PCMG_NUMB = "PCMG_NUMB";
	public static final String RATN_CODE = "RATN_CODE";
	public static final String PRCH_TITL = "PRCH_TITL";
	public static final String DEMD_DATE = "DEMD_DATE";
	public static final String ESTM_TOTL = "ESTM_TOTL";
	public static final String PRCH_STAT = "PRCH_STAT";
	
	int pcmgCode;		//일련번호
	String pcmgNumb;	//구매코드
	int ratnCode;		//수주코드
	String prchTitl;	//제목
	String demdDate;	//작성일
	int estmTotl;		//견적금액
	int prchStat;		//상태 (20,30,40 : 등록 / 50,55,60 : 구매승인 / 70 : 검수완료 / 80 : 결재완료)
	public int getPcmgCode() {
		return pcmgCode;
	}
	public void setPcmgCode(int pcmgCode) {
		this.pcmgCode = pcmgCode;
	}
	public String getPcmgNumb() {
		return pcmgNumb;
	}
	public void setPcmgNumb(String pcmgNumb) {
		this.pcmgNumb = pcmgNumb;
	}
	public int getRatnCode() {
		return ratnCode;
	}
	public void setRatnCode(int ratnCode) {
		this.ratnCode = ratnCode;
	}
	public String getPrchTitl() {
		return prchTitl;
	}
	public void setPrchTitl(String prchTitl) {
		this.prchTitl = prchTitl;
	}
	public String getDemdDate() {
		return demdDate;
	}
	public void setDemdDate(String demdDate) {
		this.demdDate = demdDate;
	}
	public int getEstmTotl() {
		return estmTotl;
	}
	public void setEstmTotl(int estmTotl) {
		this.estmTotl = estmTotl;
	}
	public int getPrchStat() {
		return prchStat;
	}
	public void setPrchStat(int prchStat) {
		this.prchStat = prchStat;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
