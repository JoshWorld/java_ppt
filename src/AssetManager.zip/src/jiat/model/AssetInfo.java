package jiat.model;

public class AssetInfo {
	public static void main(String[] args) {
		Bought bt = new Bought();
		bt.pcmgCode = 1;
	}
}
