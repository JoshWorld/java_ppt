package jiat.model;

public class Session {
	public static final String DUTY_NAME 			= "USER_DUTY_NAME";
	public static final String DUTY_CODE			= "USER_DUTY_CODE";
	public static final String PART_NAME			= "USER_PART_NAME";
	public static final String PART_CODE			= "USER_PART_CODE";
	public static final String USER_NAME			= "USER_NAME";
	public static final String USER_ID				= "USER_ID";
	public static final String USER_IDNT			= "USER_IDNT";
	public static final String ADMIN				= "ADMIN";
	public static final String CHILDPARTCODE		= "USER_CHILD_PART_CODE";
	public static final String AUTH_PART			= "AUTH_PART";
}
