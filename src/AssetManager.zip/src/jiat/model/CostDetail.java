package jiat.model;

public class CostDetail {
	public static final String C_NUM_TAG = "C_NUM";
	public static final String M_NUM_TAG = "M_NUM";
	public static final String T_NUM_TAG = "T_NUM";
	public static final String P_NUM_TAG = "P_NUM";
	public static final String E_NUM_TAG = "E_NUM";
	public static final String D_NUM_TAG = "D_NUM";
	public static final String TYPE_TAG = "TYPE";
	public static final String NAME_TAG = "NAME";
	public static final String M_NAME_TAG = "M_NAME";
	public static final String T_NAME_TAG = "T_NAME";
	public static final String ENGINEER_TAG ="ENGINEER";
	public static final String COST_TAG = "COST";
	public static final String USE_TAG = "USE";
	public static final String UNIT_TAG = "UNIT";
	public static final String MONEY_TAG = "MONEY";
	
	int inx=0;
	int pNum=0;
	int eNum=0;
	int dNum=0;
	int cNum=0;
	int mNum=0;
	int tNum=0;
	String type="";
	String name="";
	String mName="";
	String tName="";
	String engineer="";
	int cost=0;
	int use=0;
	String unit="";
	int money=0;
	
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public int geteNum() {
		return eNum;
	}
	public void seteNum(int eNum) {
		this.eNum = eNum;
	}
	public int getdNum() {
		return dNum;
	}
	public void setdNum(int dNum) {
		this.dNum = dNum;
	}
	public int getcNum() {
		return cNum;
	}
	public void setcNum(int cNum) {
		this.cNum = cNum;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getmNum() {
		return mNum;
	}
	public void setmNum(int mNum) {
		this.mNum = mNum;
	}
	public void setmNum(String mNum) {
		try{
			this.mNum = Integer.parseInt(mNum);
		}catch(NumberFormatException e){
			this.mNum = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public int gettNum() {
		return tNum;
	}
	public void settNum(int tNum) {
		this.tNum = tNum;
	}
	public void settNum(String tNum) {
		try{
			this.tNum = Integer.parseInt(tNum);
		}catch(NumberFormatException e){
			this.tNum = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public String gettName() {
		return tName;
	}
	public void settName(String tName) {
		this.tName = tName;
	}
	public String getEngineer() {
		return engineer;
	}
	public void setEngineer(String engineer) {
		this.engineer = engineer;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public void setCost(String cost) {
		try{
			this.cost = Integer.parseInt(cost);
		}catch(NumberFormatException e){
			this.cost = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public int getUse() {
		return use;
	}
	public void setUse(int use) {
		this.use = use;
	}
	public void setUse(String use) {
		try{
			this.use = Integer.parseInt(use);
		}catch(NumberFormatException e){
			this.use = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public void setMoney(String money) {
		try{
			this.money = Integer.parseInt(money);
		}catch(NumberFormatException e){
			this.money = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	
}
