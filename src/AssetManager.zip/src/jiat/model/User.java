package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class User {
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
	
	public static final String USER_IDNT = "USER_IDNT";
	public static final String USER_LOID = "USER_LOID";
	public static final String USER_LOPW = "USER_LOPW";
	public static final String USER_KNAM = "USER_KNAM";
	public static final String PART_CODE = "PART_CODE";
	public static final String PART_NAME = "PART_NAME";
	public static final String DUTY_CODE = "DUTY_CODE";
	public static final String DUTY_NAME = "DUTY_NAME";
	public static final String USER_HPNO = "USER_HPNO";
	public static final String USER_MAIL = "USER_MAIL";
	
	String userIdnt;		// 직원코드
	String workNumb;		// 사번
	String userLoid;		// 아이디
	String userLopw;		// 비밀번호
	String kName;			//성명(한글)
	String eName;			//성명(영문)
	String hName;			//성명(한문)
	String birthDay;		//생년월일
	String runlFlag;		//음력여부
	String userPhone;		//유선전화
	String userHpno;		//무선전화
	String userMail;		//이메일
	String userZipc;		//우편번호
	String userAddr;		//주소
	String compPhon;		//회사전화
	String compPhon2;		//회사내선번호
	String partCode;		//부서코드
	String partName;		//부서명
	String dutyCode;		//직책코드
	String dutyName;		//직책명
	String clasCode;		//직급코드
	String clasName;		//직급명
	String scotDate;		//입사일
	String retrFlag;		//퇴사여부
	String retrDate;		//퇴사일
	
	public String getUserIdnt() {
		return userIdnt;
	}
	public void setUserIdnt(String userIdnt) {
		this.userIdnt = userIdnt;
	}
	public String getWorkNumb() {
		return workNumb;
	}
	public void setWorkNumb(String workNumb) {
		this.workNumb = workNumb;
	}
	public String getUserLoid() {
		return userLoid;
	}
	public void setUserLoid(String userLoid) {
		this.userLoid = userLoid;
	}
	public String getUserLopw() {
		return userLopw;
	}
	public void setUserLopw(String userLopw) {
		this.userLopw = userLopw;
	}
	public String getkName() {
		return kName;
	}
	public void setkName(String kName) {
		this.kName = kName;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String gethName() {
		return hName;
	}
	public void sethName(String hName) {
		this.hName = hName;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	public String getRunlFlag() {
		return runlFlag;
	}
	public void setRunlFlag(String runlFlag) {
		this.runlFlag = runlFlag;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserHpno() {
		return userHpno;
	}
	public void setUserHpno(String userHpno) {
		this.userHpno = userHpno;
	}
	public String getUserMail() {
		return userMail;
	}
	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	public String getUserZipc() {
		return userZipc;
	}
	public void setUserZipc(String userZipc) {
		this.userZipc = userZipc;
	}
	public String getUserAddr() {
		return userAddr;
	}
	public void setUserAddr(String userAddr) {
		this.userAddr = userAddr;
	}
	public String getCompPhon() {
		return compPhon;
	}
	public void setCompPhon(String compPhon) {
		this.compPhon = compPhon;
	}
	public String getCompPhon2() {
		return compPhon2;
	}
	public void setCompPhon2(String compPhon2) {
		this.compPhon2 = compPhon2;
	}
	public String getPartCode() {
		return partCode;
	}
	public void setPartCode(String partCode) {
		this.partCode = partCode;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getDutyCode() {
		return dutyCode;
	}
	public void setDutyCode(String dutyCode) {
		this.dutyCode = dutyCode;
	}
	public String getDutyName() {
		return dutyName;
	}
	public void setDutyName(String dutyName) {
		this.dutyName = dutyName;
	}
	public String getClasCode() {
		return clasCode;
	}
	public void setClasCode(String clasCode) {
		this.clasCode = clasCode;
	}
	public String getClasName() {
		return clasName;
	}
	public void setClasName(String clasName) {
		this.clasName = clasName;
	}
	public String getScotDate() {
		return scotDate;
	}
	public void setScotDate(String scotDate) {
		this.scotDate = scotDate;
	}
	public String getRetrFlag() {
		return retrFlag;
	}
	public void setRetrFlag(String retrFlag) {
		this.retrFlag = retrFlag;
	}
	public String getRetrDate() {
		return retrDate;
	}
	public void setRetrDate(String retrDate) {
		this.retrDate = retrDate;
	}
}
