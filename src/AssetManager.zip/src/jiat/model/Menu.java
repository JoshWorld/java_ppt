package jiat.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Menu {
	public static final String SEARCH_TYPE 		= "SEARCH_TYPE";
	public static final int	SEARCH_TYPE_VALUE	= 2;
	public static final int	YEAR_TYPE_VALUE		= 0;
	public static final String PART_TYPE 		= "PART_TYPE";
	public static final String YEAR_TYPE 		= "YEAR_TYPE";
	public static final String STATE_TYPE 		= "STATE_TYPE";
	public static final String MENU_NAME 		= "NAME";
	public static final String URL				= "PATH";
	public static final String MENUID 			= "MENU_ID";
	public static final String QUERY 			= "QUERY";
	
	String menuName;
	String url;
	int menuId;
	int stateType;
	int searchType;
	int partType;
	int yearType;
	String query;
	
	public int getStateType() {
		return stateType;
	}
	public void setStateType(int stateType) {
		this.stateType = stateType;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public int getSearchType() {
		return searchType;
	}
	public void setSearchType(int searchType) {
		this.searchType = searchType;
	}
	public int getPartType() {
		return partType;
	}
	public void setPartType(int partType) {
		this.partType = partType;
	}
	public int getYearType() {
		return yearType;
	}
	public void setYearType(int yearType) {
		this.yearType = yearType;
	}
	
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	@Override
	public String toString() {
		JSONObject json = new JSONObject();
		try{
			json.put("name", getMenuName());
			json.put("path", getUrl());
			json.put("menu_id", getMenuId());
			
		}catch(JSONException e){
			e.printStackTrace();
		}
		return json.toString();
	}
}
