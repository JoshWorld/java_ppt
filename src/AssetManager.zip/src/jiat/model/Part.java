package jiat.model;

public class Part {
	public static final String P_CODE_TAG = "PART_CODE";
	public static final String P_NAME_TAG = "PART_NAME";
	public static final String P_ORDER_TAG = "PART_ORDR";
	public static final String USAG_FLAG = "USAG_FLAG";
	public static final String UPPR_PART = "UPPR_PART";
	
	String partCode;
	String partName;
	int partOrder;
	String usagFlag;
	String upperPart;
	String depth;
	
	public String getPartCode() {
		return partCode;
	}
	public void setPartCode(String partCode) {
		this.partCode = partCode;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public int getPartOrder() {
		return partOrder;
	}
	public void setPartOrder(int partOrder) {
		this.partOrder = partOrder;
	}
	public String getUsagFlag() {
		return usagFlag;
	}
	public void setUsagFlag(String usagFlag) {
		this.usagFlag = usagFlag;
	}
	public String getUpperPart() {
		return upperPart;
	}
	public void setUpperPart(String upperPart) {
		this.upperPart = upperPart;
	}
	public String getDepth() {
		return depth;
	}
	public void setDepth(String depth) {
		this.depth = depth;
	}
	
}
