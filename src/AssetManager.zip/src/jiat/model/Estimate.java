package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import builder.web.ClassParameter;

public class Estimate {
	public static final int		AFTER_MIGRATION	=	200000;
	public static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";
	public static final String NUM_TAG ="NUM";
	public static final String NAME_TAG ="NAME";
	public static final String MONEY_TAG = "MONEY";
	public static final String EDATE_TAG = "EDATE";
	public static final String UNIT_TAG = "UNIT";
	public static final String WRITER_TAG = "WRITER";
	public static final String WRITERID_TAG = "WRITERID";
	public static final String WRITE_TAG = "WRITE";
	public static final String STATE_TAG = "STATE";
	
	int inx; //E_NUM
	int p_num;
	String num;
	String name;
	String eDate;
	int money;
	String unit;
	String writer;
	String writerid;
	String write;
	String state;
	public Estimate(){
		this.money = 0;
	}
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public void setMoney(String money) {
		try{
			this.money = Integer.parseInt(money);
		}catch(NumberFormatException e){
			this.money = Integer.parseInt(money.replaceAll("[^0-9]",  ""));
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWriterID() {
		return writerid;
	}
	public void setWriterID(String writerid) {
		this.writerid = writerid;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
	public static Estimate parseEstimate(ClassParameter param){
		Estimate estim = new Estimate();
		estim.setInx(param.getInt(Estimate.INX_TAG));
		estim.setP_num(param.getInt(Estimate.P_NUM_TAG));
		estim.setNum(param.getString(Estimate.NUM_TAG));
		estim.setName(param.getString(Estimate.NAME_TAG));
		estim.seteDate(param.getString(Estimate.EDATE_TAG));
//		estim.setMoney(param.getString(Estimate.MONEY_TAG));
		estim.setUnit(param.getString(Estimate.UNIT_TAG));
		estim.setWriter(param.getString(Estimate.WRITER_TAG));
		estim.setWrite(param.getString(Estimate.WRITE_TAG));
		estim.setWriterID(param.getString(Estimate.WRITERID_TAG));
		estim.setState(param.getString(Estimate.STATE_TAG));
		return estim;
	}
}
