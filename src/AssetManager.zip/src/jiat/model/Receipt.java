package jiat.model;

import org.json.JSONObject;

public class Receipt {
	public static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";
	public static final String NUM_TAG = "NUM";
	public static final String TITLE_TAG = "TITLE";
	public static final String WRITERID_TAG = "WRITERID";
	public static final String WRITER_TAG = "WRITER";
	public static final String WRITE_TAG = "WRITE";
	public static final String STATE_TAG = "STATE";
	public static final String DCNT_NUMB = "DCNT_NUMB";
	public static final String ELTR_STAT = "ELTR_STAT";
	int inx;
	int pNum;
	String num;
	String title;
	String writerId;
	String writer;
	String write;
	String state;
	String dcntNumb;
	String eltrState;
	
	public Receipt(){}
	public Receipt(String input){
		JSONObject json = new JSONObject(input);
		if(json.has(INX_TAG))this.setInx(json.getInt(INX_TAG));
		if(json.has(NUM_TAG))this.setNum(json.getString(NUM_TAG));
		if(json.has(P_NUM_TAG))this.setpNum(json.getInt(P_NUM_TAG));
		if(json.has(STATE_TAG))this.setState(json.getString(STATE_TAG));
		if(json.has(TITLE_TAG))this.setTitle(json.getString(TITLE_TAG));
		if(json.has(WRITE_TAG))this.setWrite(json.getString(WRITE_TAG));
		if(json.has(WRITER_TAG))this.setWriter(json.getString(WRITER_TAG));
		if(json.has(WRITERID_TAG))this.setWriterId(json.getString(WRITERID_TAG));
		if(json.has(ELTR_STAT)){
			this.setEltrState(json.getString(ELTR_STAT));
		}else{
			this.setEltrState("미등록");
		}
	}
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDcntNumb() {
		return dcntNumb;
	}
	public void setDcntNumb(String dcntNumb) {
		this.dcntNumb = dcntNumb;
	}
	public String getEltrState() {
		return eltrState;
	}
	public void setEltrState(String eltrState) {
		this.eltrState = eltrState;
	}
	@Override
	public String toString() {
		JSONObject result = new JSONObject();
		result.put(INX_TAG, getInx());
		result.put(P_NUM_TAG, getpNum());
		result.put(NUM_TAG, getNum());
		result.put(STATE_TAG, getState());
		result.put(TITLE_TAG, getTitle());
		result.put(WRITERID_TAG, getWriterId());
		result.put(WRITER_TAG, getWriter());
		result.put(WRITE_TAG, getWrite());
		result.put(DCNT_NUMB, getDcntNumb());
		result.put(ELTR_STAT, getEltrState());
		return result.toString();
	}
}
