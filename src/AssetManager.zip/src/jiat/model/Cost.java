package jiat.model;

import java.util.ArrayList;

public class Cost {
	public static final String INX_TAG = "INX";
	public static final String PNUM_TAG = "P_NUM";
	public static final String ENUM_TAG = "E_NUM";
	public static final String DNUM_TAG = "D_NUM";
	public static final String NAME_TAG = "NAME";
	public static final String MONEY_TAG = "MONEY";
	public static final String ORATE_TAG = "ORATE";
	public static final String OCOST_TAG = "OCOST";
	public static final String TOTAL_TAG = "TOTAL";
	public static final String WRITER_TAG = "WRITER";
	public static final String WRITERID_TAG = "WRITERID";
	public static final String WRITE_TAG = "WRITE";
	
	int inx=0;
	int pNum=0;
	int eNum=0;
	int dNum=0;
	String name="";
	int money=0;
	int orate=0;
	int ocost=0;
	int total=0;
	String writer="";
	String writerid="";
	String write="";
	ArrayList<CostDetail> costDetail;
	
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public int geteNum() {
		return eNum;
	}
	public void seteNum(int eNum) {
		this.eNum = eNum;
	}
	public int getdNum() {
		return dNum;
	}
	public void setdNum(int dNum) {
		this.dNum = dNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public void setMoney(String money) {
		try{
			this.money = Integer.parseInt(money);
		}catch(NumberFormatException e){
			this.money = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public int getOrate() {
		return orate;
	}
	public void setOrate(int orate) {
		this.orate = orate;
	}
	public void setOrate(String orate) {
		try{
			this.orate = Integer.parseInt(orate);
		}catch(NumberFormatException e){
			this.orate = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public int getOcost() {
		return ocost;
	}
	public void setOcost(int ocost) {
		this.ocost = ocost;
	}
	public void setOcost(String ocost) {
		try{
			this.ocost = Integer.parseInt(ocost);
		}catch(NumberFormatException e){
			this.ocost = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public void setTotal(String total) {
		try{
			this.total = Integer.parseInt(total);
		}catch(NumberFormatException e){
			this.total = 0;
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public ArrayList getCostDetail() {
		return costDetail;
	}
	public void setCostDetail(ArrayList costDetail) {
		this.costDetail = costDetail;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWriterID() {
		return writerid;
	}
	public void setWriterID(String writerid) {
		this.writerid = writerid;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	
}
