package jiat.model;

import org.json.JSONObject;
import builder.web.ClassParameter;

public class Project {
	public static final int 	STATE_COMMIT			=	0;
	public static final int 	STATE_CONTRACT_REQUIRE	=	1;
	public static final int 	STATE_CONTRACT_DONE		=	2;
	public static final int 	STATE_RESULT			=	3;
	public static final int 	STATE_RECEIT_REQUIRE	=	4;
	public static final int 	STATE_RECEIT_DONE		=	5;
	
	public static final String 	INX_TAG = "INX";
	public static final String 	NUM_TAG = "NUM";
	public static final String 	PARTCODE_TAG = "PART_CODE";
	public static final String 	PDATE_TAG = "PDATE";
	public static final String 	KOLAS_TAG = "KOLAS";
	public static final String 	TYPE_TAG = "TYPE";
	public static final String 	KIND_TAG = "KIND";
	public static final String 	STATE_TAG = "STATE";
	public static final String 	CONTENT_TAG = "CONTENT";
	public static final String 	C_COMPANY_TAG = "C_COMPANY";
	public static final String 	C_NAME_TAG = "C_NAME";
	public static final String 	C_PHONE_TAG = "C_PHONE";
	public static final String 	C_MAIL_TAG = "C_MAIL";
	public static final String 	SECURE_TAG = "SECURE";
	public static final String 	WRITER_TAG = "WRITER";
	public static final String 	WRITERID_TAG = "WRITERID";
	public static final String 	WRITE_TAG = "WRITE";
	public static final String 	INSIDE_TAG = "INSIDE";
	public static final String 	PARTNAME_TAG = "PART_NAME";
	public static final String 	RMSCODE_TAG = "RMS_CODE";
	public static final String 	RMSNAME_TAG = "RMS_NAME";
	public static final String 	C_CODE_TAG = "C_CODE";
	public static final String 	TITLE_TAG = "TITLE";
	
	@Override
	public String toString() {
		JSONObject result = new JSONObject();
		result.put(INX_TAG, getInx());
		result.put(NUM_TAG, getNum());
		result.put(PARTCODE_TAG, getPartCode());
		result.put(PDATE_TAG, getPdate());
		result.put(KOLAS_TAG, getKolas());
		result.put(TYPE_TAG, getType());
		result.put(KIND_TAG, getKind());
		result.put(SECURE_TAG, getSecure());
		result.put(INSIDE_TAG, getInside());
		result.put(STATE_TAG, getState());
		result.put(CONTENT_TAG, getContent());
		result.put(C_COMPANY_TAG, getC_company());
		result.put(C_NAME_TAG, getC_name());
		result.put(C_PHONE_TAG, getC_phone());
		result.put(C_MAIL_TAG, getC_mail());
		result.put(WRITER_TAG, getWriter());
		result.put(WRITERID_TAG, getWriterId());
		result.put(WRITE_TAG, getWrite());
		result.put(PARTNAME_TAG, getPartName());
		result.put(RMSCODE_TAG, getRmsCode());
		result.put(RMSNAME_TAG, getRmsName());
		result.put(C_CODE_TAG, getcCode());
		result.put(TITLE_TAG, getTitle());
		return result.toString();
	}
	public static Project parseProject(ClassParameter input){
		Project result = new Project();
		result.setInx(input.getInt(INX_TAG));
		result.setNum(input.getString(NUM_TAG));
		result.setPartCode(input.getString(PARTCODE_TAG));
		result.setPdate(input.getString(PDATE_TAG));
		result.setKolas(input.getInt(KOLAS_TAG));
		result.setType(input.getInt(TYPE_TAG));
		result.setKind(input.getInt(KIND_TAG));
		result.setSecure(input.getInt(SECURE_TAG));
		result.setInside(input.getInt(INSIDE_TAG));
		result.setState(input.getInt(STATE_TAG));
		result.setContent(input.getString(CONTENT_TAG).trim());
		result.setC_company(input.getString(C_COMPANY_TAG));
		result.setC_name(input.getString(C_NAME_TAG));
		result.setC_phone(input.getString(C_PHONE_TAG));
		result.setC_mail(input.getString(C_MAIL_TAG));
		result.setWriter(input.getString(WRITER_TAG));
		result.setWriterId(input.getString(WRITERID_TAG));
		result.setWrite(input.getString(WRITE_TAG));
		result.setPartName(input.getString(PARTNAME_TAG));
		result.setRmsCode(input.getString(RMSCODE_TAG));
		result.setRmsName(input.getString(RMSNAME_TAG));
		result.setcCode(input.getString(C_CODE_TAG));
		result.setTitle(input.getString(TITLE_TAG));
		
		return result;
	}
	public static Project parseProject(String input){
		Project result = new Project();
		
		JSONObject json = new JSONObject(input);
		if(json.has(INX_TAG))result.setInx((Integer)json.get(INX_TAG));
		if(json.has(NUM_TAG))result.setNum((String)json.get(NUM_TAG));
		if(json.has(PARTCODE_TAG))result.setPartCode((String)json.get(PARTCODE_TAG));
		if(json.has(PDATE_TAG))result.setPdate((String)json.get(PDATE_TAG));
		if(json.has(KOLAS_TAG))result.setKolas((Integer)json.get(KOLAS_TAG));
		if(json.has(TYPE_TAG))result.setType((Integer)json.get(TYPE_TAG));
		if(json.has(KIND_TAG))result.setKind((Integer)json.get(KIND_TAG));
		if(json.has(STATE_TAG))result.setState((Integer)json.get(STATE_TAG));
		if(json.has(SECURE_TAG))result.setSecure((Integer)json.get(SECURE_TAG));
		if(json.has(INSIDE_TAG))result.setInside((Integer)json.get(INSIDE_TAG));
		if(json.has(CONTENT_TAG))result.setContent((String)json.get(CONTENT_TAG));
		if(json.has(C_COMPANY_TAG))result.setC_company((String)json.get(C_COMPANY_TAG));
		if(json.has(C_NAME_TAG))result.setC_name((String)json.get(C_NAME_TAG));
		if(json.has(C_PHONE_TAG))result.setC_phone((String)json.get(C_PHONE_TAG));
		if(json.has(C_MAIL_TAG))result.setC_mail((String)json.get(C_MAIL_TAG));
		if(json.has(WRITER_TAG))result.setWriter((String)json.get(WRITER_TAG));
		if(json.has(WRITE_TAG))result.setWrite((String)json.get(WRITE_TAG));
		if(json.has(PARTNAME_TAG))result.setPartName((String)json.get(PARTNAME_TAG));
		if(json.has(RMSCODE_TAG))result.setRmsCode((String)json.get(RMSCODE_TAG));
		if(json.has(RMSNAME_TAG))result.setRmsName((String)json.get(RMSNAME_TAG));
		if(json.has(C_CODE_TAG))result.setcCode((String)json.get(C_CODE_TAG));
		if(json.has(TITLE_TAG))result.setTitle((String)json.get(TITLE_TAG));
		if(json.has(WRITERID_TAG))result.setWriterId((String)json.get(WRITERID_TAG));
		return result;
	}
	int 		inx;			// 일련번호
	String 		num;			// 접수번호
	String 		partCode;		// 부서코드
	String 		pdate;			// 상담일
	int 		kolas;			// KOLAS
	int 		type;			// 사업구분
	int 		kind;			// 분류
	int 		state;			// 상태 
	String 		content;		// 상담내용
	String 		c_company;		// 업체명
	String 		c_name;			// 의뢰인
	String 		c_phone;		// 의뢰인 연락처
	String 		c_mail;			// 의뢰인 이메일
	int 		secure;			// 보안 : 안함 0, 보안 1
	String 		writer;			// 등록자
	String		writerId;		// 등록자 ID
	String 		write;			// 등록일
	int 		inside;			// 도내 : 0 , 도외 : 1
	String 		partName;		// 부서이름
	String 		rmsCode;		// 과제코드
	String 		rmsName;		// 과제명
	String 		cCode;			// 업체코드
	String 		title;			// 제목
	
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getRmsCode() {
		return rmsCode;
	}
	public void setRmsCode(String rmsCode) {
		this.rmsCode = rmsCode;
	}
	public String getRmsName() {
		return rmsName;
	}
	public void setRmsName(String rmsName) {
		this.rmsName = rmsName;
	}
	public String getcCode() {
		return cCode;
	}
	public void setcCode(String cCode) {
		this.cCode = cCode;
	}
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public String getPartCode() {
		return partCode;
	}
	public void setPartCode(String part) {
		this.partCode = part;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public int getKolas() {
		return kolas;
	}
	public void setKolas(int kolas) {
		this.kolas = kolas;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public int getKind() {
		return kind;
	}
	public void setKind(int kind) {
		this.kind = kind;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getC_company() {
		return c_company;
	}
	public void setC_company(String c_company) {
		this.c_company = c_company;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	public String getC_phone() {
		return c_phone;
	}
	public void setC_phone(String c_phone) {
		this.c_phone = c_phone;
	}
	public String getC_mail() {
		return c_mail;
	}
	public void setC_mail(String c_mail) {
		this.c_mail = c_mail;
	}
	public int getSecure() {
		return secure;
	}
	public void setSecure(int secure) {
		this.secure = secure;
	}
	public int getInside() {
		return inside;
	}
	public void setInside(int inside) {
		this.inside = inside;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}	
}
