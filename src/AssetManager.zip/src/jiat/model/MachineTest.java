package jiat.model;

import org.json.JSONObject;

public class MachineTest {
	public static final String INX_TAG = "INX";
	public static final String CODE_TAG = "CODE";
	public static final String NAME_TAG = "NAME";
	public static final String M_NUM_TAG = "M_NUM";
	public static final String COST_TAG = "COST";
	public static final String E_NUM_TAG = "E_NUM";
	public static final String E_NAME_TAG = "E_NAME";
	public static final String E_COST_TAG = "E_COST";
	public static final String APPLY_TAG = "APPLY";
	public static final String STATE_TAG = "STATE";
	public static final String WRITER_TAG = "WRITER";
	public static final String WRITERID_TAG = "WRITERID";
	public static final String WRITE_TAG = "WRITE";
	
	int inx;
	int mNum;
	String code;
	String name;
	int cost;
	int eNum;
	String eName;
	int eCost;
	String apply;
	String state;
	String writer;
	String writerid;
	String write;
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getmNum() {
		return mNum;
	}
	public void setmNum(int mNum) {
		this.mNum = mNum;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int geteNum() {
		return eNum;
	}
	public void seteNum(int eNum) {
		this.eNum = eNum;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public int geteCost() {
		return eCost;
	}
	public void seteCost(int eCost) {
		this.eCost = eCost;
	}
	public String getApply() {
		return apply;
	}
	public void setApply(String apply) {
		this.apply = apply;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWriterID() {
		return writerid;
	}
	public void setWriterID(String writerid) {
		this.writerid = writerid;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	@Override
	public String toString() {
		JSONObject json = new JSONObject();
		json.put(INX_TAG, getInx());
		json.put(M_NUM_TAG, getmNum());
		json.put(CODE_TAG, getCode());
		json.put(NAME_TAG, getName());
		json.put(COST_TAG, getCost());
		json.put(E_NUM_TAG, geteNum());
		json.put(E_NAME_TAG, geteName());
		json.put(E_COST_TAG, geteCost());
		json.put(APPLY_TAG, getApply());
		json.put(STATE_TAG, getState());
		json.put(WRITER_TAG, getWriter());
		json.put(WRITERID_TAG, getWriterID());
		json.put(WRITE_TAG, getWrite());
		
		return json.toString();
	}
}
