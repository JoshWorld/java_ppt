package jiat.model;

public class Budget {
	public static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";
	public static final String E_NUM_TAG = "E_NUM";
	public static final String D_NUM_TAG = "D_NUM";
	public static final String C_NUM_TAG = "C_NUM";
	public static final String T_NUM_TAG = "T_NUM";
	public static final String M_NUM_TAG = "M_NUM";
	public static final String TYPE_TAG = "TYPE";
	public static final String NAME_TAG ="NAME";
	public static final String M_NAME_TAG ="M_NAME";
	public static final String T_NAME_TAG ="T_NAME";
	public static final String ENGINEER_TAG = "ENGINEER";
	public static final String COST_TAG = "COST";
	public static final String USE_TAG = "USE";
	public static final String UNIT_TAG = "UNIT";
	public static final String MONEY_TAG = "MONEY";
	
	int inx;
	int p_num;
	int e_num;
	int d_num;
	int c_num;
	int m_num;
	int t_num;
	
	char type;
	String name;
	String m_name;
	String t_name;
	String engineer;
	int cost;
	int use;
	String unit;
	int money;
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getE_num() {
		return e_num;
	}
	public void setE_num(int e_num) {
		this.e_num = e_num;
	}
	public int getD_num() {
		return d_num;
	}
	public void setD_num(int d_num) {
		this.d_num = d_num;
	}
	public int getC_num() {
		return c_num;
	}
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public int getM_num() {
		return m_num;
	}
	public void setM_num(int m_num) {
		this.m_num = m_num;
	}
	public int getT_num() {
		return t_num;
	}
	public void setT_num(int t_num) {
		this.t_num = t_num;
	}
	public char getType() {
		return type;
	}
	public void setType(char type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getT_name() {
		return t_name;
	}
	public void setT_name(String t_name) {
		this.t_name = t_name;
	}
	public String getEngineer() {
		return engineer;
	}
	public void setEngineer(String engineer) {
		this.engineer = engineer;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getUse() {
		return use;
	}
	public void setUse(int use) {
		this.use = use;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	
	
}
