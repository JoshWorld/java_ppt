package jiat.model;

import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

public class Repair {
	public static final String REPR_NUMB_TAG = "REPR_NUMB";
	public static final String JASN_CODE_TAG = "JASN_CODE";
	public static final String WORK_DATE_TAG = "WORK_DATE";
	public static final String PEPR_BODY_TAG = "PEPR_BODY";
	public static final String CNFM_USER_TAG = "CNFM_USER";
	public static final String COST_MONY_TAG = "COST_MONY";
	public static final String RMRK_NOTE_TAG = "RMRK_NOTE";
	public static final String WRTE_IDNT_TAG = "WRTE_IDNT";
	public static final String WRTE_DATE_TAG = "WRTE_DATE";
	public static final String UPDT_DATE_TAG = "UPDT_DATE";
	public static final String PEPR_CODE_TAG = "PEPR_CODE";
	public static final String ELTR_NUMB_TAG = "ELTR_NUMB";
	
	int reprNumb;
	int jasnCode;
	String workDate;
	String peprBody;
	String cnfmUser;
	int costMony;
	String rmrkNote;
	String wrteIdnt;
	
	String wrteDate;
	String updtDate;
	String peprCode;
	int eltrNumb;
	
	
	
	public int getReprNumb() {
		return reprNumb;
	}
	public void setReprNumb(int reprNumb) {
		this.reprNumb = reprNumb;
	}
	public int getJasnCode() {
		return jasnCode;
	}
	public void setJasnCode(int jasnCode) {
		this.jasnCode = jasnCode;
	}
	public String getWorkDate() {
		return workDate;
	}
	public void setWorkDate(String workDate) {
		this.workDate = workDate;
	}
	public String getPeprBody() {
		return peprBody;
	}
	public void setPeprBody(String peprBody) {
		this.peprBody = peprBody;
	}
	public String getCnfmUser() {
		return cnfmUser;
	}
	public void setCnfmUser(String cnfmUser) {
		this.cnfmUser = cnfmUser;
	}
	public int getCostMony() {
		return costMony;
	}
	public void setCostMony(int costMony) {
		this.costMony = costMony;
	}
	public String getRmrkNote() {
		return rmrkNote;
	}
	public void setRmrkNote(String rmrkNote) {
		this.rmrkNote = rmrkNote;
	}
	public String getWrteIdnt() {
		return wrteIdnt;
	}
	public void setWrteIdnt(String wrteIdnt) {
		this.wrteIdnt = wrteIdnt;
	}
	public String getWrteDate() {
		return wrteDate;
	}
	public void setWrteDate(String wrteDate) {
		this.wrteDate = wrteDate;
	}
	public String getUpdtDate() {
		return updtDate;
	}
	public void setUpdtDate(String updtDate) {
		this.updtDate = updtDate;
	}
	public String getPeprCode() {
		return peprCode;
	}
	public void setPeprCode(String peprCode) {
		this.peprCode = peprCode;
	}
	public int getEltrNumb() {
		return eltrNumb;
	}
	public void setEltrNumb(int eltrNumb) {
		this.eltrNumb = eltrNumb;
	}
	
	
	
	@Override
	public String toString() {
		return toJSONObject(this).toString();
	}
	public static Repair parseRepair(JSONObject json){
		Repair result = new Repair();
		if(json.has(REPR_NUMB_TAG)){
			result.setReprNumb(json.getInt(REPR_NUMB_TAG));
		}
		if(json.has(JASN_CODE_TAG)){
			result.setJasnCode(json.getInt(JASN_CODE_TAG));
		}
		if(json.has(WORK_DATE_TAG)){
			result.setWorkDate(json.getString(WORK_DATE_TAG));
		}
		if(json.has(PEPR_BODY_TAG)){
			result.setPeprBody(json.getString(PEPR_BODY_TAG));
		}
		if(json.has(CNFM_USER_TAG)){
			result.setCnfmUser(json.getString(CNFM_USER_TAG));
		}
		if(json.has(COST_MONY_TAG)){
			result.setCostMony(json.getInt(COST_MONY_TAG));
		}
		if(json.has(RMRK_NOTE_TAG)){
			result.setRmrkNote(json.getString(RMRK_NOTE_TAG));
		}
		if(json.has(WRTE_IDNT_TAG)){
			result.setWrteIdnt(json.getString(WRTE_IDNT_TAG));
		}
		if(json.has(WRTE_DATE_TAG)){
			result.setWrteDate(json.getString(WRTE_DATE_TAG));
		}
		if(json.has(UPDT_DATE_TAG)){
			result.setUpdtDate(json.getString(UPDT_DATE_TAG));
		}
		if(json.has(PEPR_CODE_TAG)){
			result.setPeprCode(json.getString(PEPR_CODE_TAG));
		}
		if(json.has(ELTR_NUMB_TAG)){
			result.setEltrNumb(json.getInt(ELTR_NUMB_TAG));
		}
		
		return result;
	}
	
	
	
	public static JSONObject toJSONObject(Repair con){
		JSONObject result = new JSONObject();
		
		result.put(REPR_NUMB_TAG, con.getReprNumb());
		result.put(JASN_CODE_TAG, con.getJasnCode());
		result.put(WORK_DATE_TAG, con.getWorkDate());
		result.put(PEPR_BODY_TAG, con.getPeprBody());
		result.put(CNFM_USER_TAG, con.getCnfmUser());
		result.put(COST_MONY_TAG, con.getCostMony());
		result.put(RMRK_NOTE_TAG, con.getRmrkNote());
		result.put(WRTE_IDNT_TAG, con.getWrteIdnt());
		result.put(WRTE_DATE_TAG, con.getWrteDate());
		result.put(UPDT_DATE_TAG, con.getUpdtDate());
		result.put(PEPR_CODE_TAG, con.getPeprCode());
		result.put(ELTR_NUMB_TAG, con.getEltrNumb());
		
		return result;
	}
	
}




