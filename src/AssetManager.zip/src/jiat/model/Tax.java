package jiat.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;

public class Tax {
	public static final int STATE_REGISTERED 	= 0;
	public static final int STATE_COMPLETE 		= 1;
	
	public static final String INX_TAG 			= "INX";
	public static final String T_NUM_TAG 		= "T_NUM";
	public static final String PNUM_TAG 		= "P_NUM";
	public static final String CONTENT_TAG 		= "CONTENT";
	public static final String C_NAME_TAG 		= "C_NAME";
	public static final String C_PHONE_TAG 		= "C_PHONE";
	public static final String C_MAIL_TAG 		= "C_MAIL";
	public static final String R_DATE_TAG 		= "RDATE";
	public static final String R_MONEY_TAG 		= "RMONEY";
	public static final String P_DATE_TAG 		= "PDATE";
	public static final String PUBLISH_TAG 		= "PUBLISH";
	public static final String P_MONEY_TAG 		= "PMONEY";
	public static final String WRITER_TAG 		= "WRITER";
	public static final String WRITER_ID_TAG 	= "WRITERID";
	public static final String WRITE_TAG 		= "WRITE";
	public static final String STATE_TAG 		= "STATE";
	
	public static final String C_NAME2_TAG 		= "C_NAME2";
	public static final String C_PHONE2_TAG 	= "C_PHONE2";
	public static final String C_MAIL2_TAG 		= "C_MAIL2";
	public static final String C_TAXNUM_TAG 	= "C_TAXNUM";
	public static final String C_MEMO_TAG 		= "C_MEMO";
	
	int inx;
	int pNum;
	String content;
	String cName;
	String cPhone;
	String cMail;
	String rDate;
	int rMoney;
	String pDate;
	String publish;
	int pMoney;
	String writer;
	String write;
	String writerId;
	int state;
	
	String cName2;
	String cPhone2;
	String cMail2;
	String cTaxNum;
	String cMemo;
	
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getpNum() {
		return pNum;
	}
	public void setpNum(int pNum) {
		this.pNum = pNum;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getcPhone() {
		return cPhone;
	}
	public void setcPhone(String cPhone) {
		this.cPhone = cPhone;
	}
	public String getcMail() {
		return cMail;
	}
	public void setcMail(String cMail) {
		this.cMail = cMail;
	}
	public String getrDate() {
		return rDate;
	}
	public void setrDate(String rDate) {
		this.rDate = rDate;
	}
	public int getrMoney() {
		return rMoney;
	}
	public void setrMoney(int rMoney) {
		this.rMoney = rMoney;
	}
	public String getpDate() {
		return pDate;
	}
	public void setpDate(String pDate) {
		this.pDate = pDate;
	}
	public String getPublish() {
		return publish;
	}
	public void setPublish(String publish) {
		this.publish = publish;
	}
	public int getpMoney() {
		return pMoney;
	}
	public void setpMoney(int pMoney) {
		this.pMoney = pMoney;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
	
	public String getcName2() {
		return cName2;
	}
	public void setcName2(String cName2) {
		this.cName2 = cName2;
	}
	public String getcPhone2() {
		return cPhone2;
	}
	public void setcPhone2(String cPhone2) {
		this.cPhone2 = cPhone2;
	}
	public String getcMail2() {
		return cMail2;
	}
	public void setcMail2(String cMail2) {
		this.cMail2 = cMail2;
	}
	public String getcTaxNum() {
		return cTaxNum;
	}
	public void setcTaxNum(String cTaxNum) {
		this.cTaxNum = cTaxNum;
	}
	public String getcMemo() {
		return cMemo;
	}
	public void setcMemo(String cMemo) {
		this.cMemo = cMemo;
	}
	@Override
	public String toString() {
		return toJSONObject(this).toString();
	}
	
	static public JSONObject toJSONObject(Tax tax){
		JSONObject result = new JSONObject();
		
		result.put("T_NUM", tax.getInx());
		result.put(PNUM_TAG, tax.getpNum());
		result.put(CONTENT_TAG, tax.getContent());
		result.put(C_NAME_TAG, tax.getcName());
		result.put(C_PHONE_TAG, tax.getcPhone());
		result.put(C_MAIL_TAG, tax.getcMail());		
		result.put(R_DATE_TAG, tax.getrDate());
		result.put(R_MONEY_TAG, tax.getrMoney());
		result.put(P_DATE_TAG, tax.getpDate());
		result.put(PUBLISH_TAG, tax.getPublish());
		result.put(P_MONEY_TAG, tax.getpMoney());
		result.put(WRITER_ID_TAG, tax.getWriterId());
		result.put(WRITER_TAG, tax.getWriter());
		result.put(WRITE_TAG, tax.getWrite());
		result.put(STATE_TAG, tax.getState());
		
		result.put(C_NAME2_TAG, tax.getcName2());
		result.put(C_PHONE2_TAG, tax.getcPhone2());
		result.put(C_MAIL2_TAG, tax.getcMail2());
		result.put(C_TAXNUM_TAG, tax.getcTaxNum());
		result.put(C_MEMO_TAG, tax.getcMemo());
		
		return result;
	}
	static public Tax getTaxFromDB(ResultSet rs){
		Tax tax = new Tax();
		try {
			tax.setInx(rs.getInt(INX_TAG));
			tax.setpNum(rs.getInt(PNUM_TAG));
			tax.setContent(rs.getString(CONTENT_TAG));
			tax.setcName(rs.getString(C_NAME_TAG));
			tax.setcPhone(rs.getString(C_PHONE_TAG));
			tax.setcMail(rs.getString(C_MAIL_TAG));			
			tax.setrDate(rs.getString(R_DATE_TAG));
			tax.setrMoney(rs.getInt(R_MONEY_TAG));
			tax.setpDate(rs.getString(P_DATE_TAG));
			tax.setPublish(rs.getString(PUBLISH_TAG));
			tax.setpMoney(rs.getInt(P_MONEY_TAG));
			tax.setWriterId(rs.getString(WRITER_ID_TAG));
			tax.setWriter(rs.getString(WRITER_TAG));
			tax.setWrite(rs.getString(WRITE_TAG));
			tax.setState(rs.getInt(STATE_TAG));
			
			tax.setcName2(rs.getString(C_NAME2_TAG));
			tax.setcPhone2(rs.getString(C_PHONE2_TAG));
			tax.setcMail2(rs.getString(C_MAIL2_TAG));
			tax.setcTaxNum(rs.getString(C_TAXNUM_TAG));
			tax.setcMemo(rs.getString(C_MEMO_TAG));
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tax;
	}
	
	
	public static Tax parseTax(JSONObject json){
		Tax result = new Tax();
		if(json.has(INX_TAG)){
			result.setInx(json.getInt(INX_TAG));
		}else if(json.has(T_NUM_TAG)){
			result.setInx(json.getInt(T_NUM_TAG));
		}
		if(json.has(PNUM_TAG)){
			result.setpNum(json.getInt(PNUM_TAG));
		}
		if(json.has(CONTENT_TAG)){
			result.setContent(json.getString(CONTENT_TAG));
		}
		if(json.has(C_NAME_TAG)){
			result.setcName(json.getString(C_NAME_TAG));
		}
		if(json.has(C_PHONE_TAG)){
			result.setcPhone(json.getString(C_PHONE_TAG));
		}
		if(json.has(C_MAIL_TAG)){
			result.setcMail(json.getString(C_MAIL_TAG));
		}
		if(json.has(R_DATE_TAG)){
			result.setrDate(json.getString(R_DATE_TAG));
		}
		try{
			if(json.get(R_MONEY_TAG) instanceof Integer){
				if(json.has(R_MONEY_TAG) && (Integer)json.get(R_MONEY_TAG)>0){
					result.setrMoney((Integer)json.get(R_MONEY_TAG));
				}
			}else if(json.get(R_MONEY_TAG) instanceof String){
				if(json.has(R_MONEY_TAG)){
					result.setrMoney(Integer.parseInt(json.getString(R_MONEY_TAG)));
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		if(json.has(STATE_TAG)){
			result.setState(json.getInt(STATE_TAG));
		}
		if(json.has(WRITER_TAG)){
			result.setWriter(json.getString(WRITER_TAG));
		}
		if(json.has(WRITE_TAG)){
			result.setWrite(json.getString(WRITE_TAG));
		}
		if(json.has(WRITER_ID_TAG)){
			result.setWriterId(json.getString(WRITER_ID_TAG));
		}
		if(json.has(CONTENT_TAG)){
			result.setContent(json.getString(CONTENT_TAG));
		}
		if(json.has(P_DATE_TAG)){
			result.setpDate(json.getString(P_DATE_TAG));
		}
		if(json.has(PUBLISH_TAG)){
			result.setPublish(json.getString(PUBLISH_TAG));
		}
		try{
			if(json.has(P_MONEY_TAG) && (Integer)json.get(P_MONEY_TAG)>0){
				result.setpMoney((Integer)json.get(P_MONEY_TAG));
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		if(json.has(C_NAME2_TAG)){
			result.setcName2(json.getString(C_NAME2_TAG));
		}
		if(json.has(C_PHONE2_TAG)){
			result.setcPhone2(json.getString(C_PHONE2_TAG));
		}
		if(json.has(C_MAIL2_TAG)){
			result.setcMail2(json.getString(C_MAIL2_TAG));
		}
		if(json.has(C_TAXNUM_TAG)){
			result.setcTaxNum(json.getString(C_TAXNUM_TAG));
		}
		if(json.has(C_MEMO_TAG)){
			result.setcMemo(json.getString(C_MEMO_TAG));
		}
		return result;
	}
	
	public boolean hasNull(){
		if(this.getpNum() > 0 
				&& this.getrDate() != null
				&& !(this.getrMoney() < 0) 
				&& this.getcTaxNum() != null)return false;
		else return true;
	}
	
	
	
}
