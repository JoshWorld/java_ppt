package jiat.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class T_CODE {
	public static final String CODE_TAG = "CODE";
	public static final String VALUE_TAG = "VALUE";
	public static final String INDERECT = "INDIRECT_DEFAULT";
	public static final String OPTIME = "OPTIME_DEFAULT";
	
	int code;
	int value;
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
