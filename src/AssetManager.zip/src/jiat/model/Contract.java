package jiat.model;

import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

public class Contract {
	public static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";
	public static final String C_DATE_TAG = "CDATE";
	public static final String MONEY_TAG = "MONEY";
	public static final String APPROVAL_TAG = "APPROVAL";
	public static final String RDATE_TAG = "RDATE";
	public static final String GRANTOR_TAG = "GRANTOR";
	public static final String G_DATE_TAG = "GDATE";
	public static final String STATE_TAG = "STATE";
	public static final String WRITER_TAG = "WRITER";
	public static final String WRITERID_TAG = "WRITERID";
	public static final String WRITE_TAG = "WRITE";
	public static final String CONTENT_TAG = "CONTENT";
	public static final String FILENAME_TAG = "FILE_NAME";
	public static final String FILE_INFOS_TAG = "FILE_INFOS";
	public static final String GRANTOR_ID_TAG = "GRANTORID";
	public static final String APPROVAL_ID_TAG = "APPROVALID";
	
	public static final String APPROVAL2_TAG = "APPROVAL2";
	public static final String GRANTOR2_TAG = "GRANTOR2";
	public static final String G_DATE2_TAG = "GDATE2";
	public static final String APPROVAL_ID2_TAG = "APPROVALID2";
	public static final String GRANTOR_ID2_TAG = "GRANTORID2";
	
	
	int inx;
	int p_num;
	String cdate;
	int money;
	String approval;
	String rdate;
	String grantor;
	String gdate;
	int state;
	String writer;
	String write;
	String content;
	String approvalId;
	String grantorId;
	String writerId;
	
	String approval2;
	String grantor2;
	String gdate2;
	String approvalId2;
	String grantorId2;
	
	
	ArrayList<FileInfo> fileInfos;
	
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public String getCdate() {
		return cdate;
	}
	public void setCdate(String cdate) {
		this.cdate = cdate;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getApproval() {
		return approval;
	}
	public void setApproval(String approval) {
		this.approval = approval;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public String getGrantor() {
		return grantor;
	}
	public void setGrantor(String grantor) {
		this.grantor = grantor;
	}
	public String getGdate() {
		return gdate;
	}
	public void setGdate(String gdate) {
		this.gdate = gdate;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getWrite() {
		return write;
	}
	public void setWrite(String write) {
		this.write = write;
	}
	public ArrayList<FileInfo> getFileInfos() {
		return fileInfos;
	}
	public void setFileInfos(ArrayList<FileInfo> fileInfos) {
		this.fileInfos = fileInfos;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getApprovalId() {
		return approvalId;
	}
	public void setApprovalId(String approvalId) {
		this.approvalId = approvalId;
	}
	public String getGrantorId() {
		return grantorId;
	}
	public void setGrantorId(String grantorId) {
		this.grantorId = grantorId;
	}
	public String getWriterId() {
		return writerId;
	}
	public void setWriterId(String writerId) {
		this.writerId = writerId;
	}
		
	public String getApproval2() {
		return approval2;
	}
	public void setApproval2(String approval2) {
		this.approval2 = approval2;
	}
	public String getGrantor2() {
		return grantor2;
	}
	public void setGrantor2(String grantor2) {
		this.grantor2 = grantor2;
	}
	public String getGdate2() {
		return gdate2;
	}
	public void setGdate2(String gdate2) {
		this.gdate2 = gdate2;
	}
	public String getApprovalId2() {
		return approvalId2;
	}
	public void setApprovalId2(String approvalId2) {
		this.approvalId2 = approvalId2;
	}
	public String getGrantorId2() {
		return grantorId2;
	}
	public void setGrantorId2(String grantorId2) {
		this.grantorId2 = grantorId2;
	}	
	
	@Override
	public String toString() {
		return toJSONObject(this).toString();
	}
	public static Contract parseContract(JSONObject json){
		Contract result = new Contract();
		if(json.has(INX_TAG)){
			result.setInx(json.getInt(INX_TAG));
		}
		if(json.has(P_NUM_TAG)){
			result.setP_num(json.getInt(P_NUM_TAG));
		}
		if(json.has(C_DATE_TAG)){
			result.setCdate(json.getString(C_DATE_TAG));
		}
		
		if(json.has(MONEY_TAG) && json.getInt(MONEY_TAG)>0){
			if(json.get(MONEY_TAG) instanceof Integer){
				result.setMoney(json.getInt(MONEY_TAG));
			}else if(json.get(MONEY_TAG) instanceof String){
				result.setMoney(Integer.parseInt(json.getString(MONEY_TAG)));
			}
		}
		
		if(json.has(APPROVAL_TAG)){
			result.setApproval(json.getString(APPROVAL_TAG));
		}
		if(json.has(RDATE_TAG)){
			result.setRdate(json.getString(RDATE_TAG));
		}
		if(json.has(GRANTOR_TAG)){
			result.setGrantor(json.getString(GRANTOR_TAG));
		}
		if(json.has(G_DATE_TAG)){
			result.setGdate(json.getString(G_DATE_TAG));
		}
		if(json.has(STATE_TAG)){
			result.setState(json.getInt(STATE_TAG));
		}
		if(json.has(WRITER_TAG)){
			result.setWriter(json.getString(WRITER_TAG));
		}
		if(json.has(WRITE_TAG)){
			result.setWrite(json.getString(WRITE_TAG));
		}
		if(json.has(CONTENT_TAG)){
			result.setContent(json.getString(CONTENT_TAG));
		}
		if(json.has(APPROVAL_ID_TAG)){
			result.setApprovalId(json.getString(APPROVAL_ID_TAG));
		}
		if(json.has(GRANTOR_ID_TAG)){
			result.setGrantorId(json.getString(GRANTOR_ID_TAG));
		}
		if(json.has(WRITERID_TAG)){
			result.setWriterId(json.getString(WRITERID_TAG));
		}
		if(json.has(APPROVAL2_TAG)){
			result.setApproval2(json.getString(APPROVAL2_TAG));
		}
		if(json.has(GRANTOR2_TAG)){
			result.setGrantor2(json.getString(GRANTOR2_TAG));
		}
		if(json.has(G_DATE2_TAG)){
			result.setGdate2(json.getString(G_DATE2_TAG));
		}
		if(json.has(APPROVAL_ID2_TAG)){
			result.setApprovalId2(json.getString(APPROVAL_ID2_TAG));
		}
		if(json.has(GRANTOR_ID2_TAG)){
			result.setGrantorId2(json.getString(GRANTOR_ID2_TAG));
		}
		return result;
	}
	public static JSONObject toJSONObject(Contract con){
		JSONObject result = new JSONObject();
		
		result.put(INX_TAG, con.getInx());
		result.put(P_NUM_TAG, con.getP_num());
		result.put(C_DATE_TAG, con.getCdate());
		result.put(MONEY_TAG, con.getMoney());
		result.put(APPROVAL_TAG, con.getApproval());
		result.put(RDATE_TAG, con.getRdate());
		result.put(GRANTOR_TAG, con.getGrantor());
		result.put(G_DATE_TAG, con.getGdate());
		result.put(STATE_TAG, con.getState());
		result.put(WRITER_TAG, con.getWriter());
		result.put(WRITE_TAG, con.getWrite());
		result.put(CONTENT_TAG, con.getContent());
		result.put(GRANTOR_ID_TAG, con.getGrantorId());
		result.put(APPROVAL_ID_TAG, con.getApprovalId());
		result.put(WRITERID_TAG, con.getWriterId());
		
		result.put(APPROVAL2_TAG, con.getApproval2());
		result.put(GRANTOR2_TAG, con.getGrantor2());
		result.put(G_DATE2_TAG, con.getGdate2());
		result.put(GRANTOR_ID2_TAG, con.getGrantorId2());
		result.put(APPROVAL_ID2_TAG, con.getApprovalId2());
		
		
		if(con.getFileInfos() != null){
			JSONArray fileInfoArray = new JSONArray();
			Iterator<FileInfo> iter = con.getFileInfos().iterator();
			while(iter.hasNext()){
				fileInfoArray.put(iter.next().getfName());
			}
			result.put(FILE_INFOS_TAG, fileInfoArray);
		}
		return result;
	}
	public boolean hasNull(){
		if(this.getP_num() > 0 
				&& this.getCdate() != null
				&& !(this.getMoney() < 0))return false;
		else return true;
	}
}
