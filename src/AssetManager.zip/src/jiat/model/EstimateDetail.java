package jiat.model;

public class EstimateDetail {
	public static final String INX_TAG = "INX";
	public static final String P_NUM_TAG = "P_NUM";
	public static final String E_NUM_TAG = "E_NUM";
	public static final String TYPE_TAG = "TYPE";
	public static final String NAME_TAG ="NAME";
	public static final String COST_TAG = "COST";
	public static final String MONEY_TAG = "MONEY";
	public static final String COUNT_TAG = "COUNT";
	
	int inx;
	int p_num;
	int e_num;
	String type;
	String name;
	int cost;
	int count;
	int money;
	public int getInx() {
		return inx;
	}
	public void setInx(int inx) {
		this.inx = inx;
	}
	public int getP_num() {
		return p_num;
	}
	public void setP_num(int p_num) {
		this.p_num = p_num;
	}
	public int getE_num() {
		return e_num;
	}
	public void setE_num(int e_num) {
		this.e_num = e_num;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public void setCost(String cost){
		try{
			this.cost = Integer.parseInt(cost);
		}catch(NumberFormatException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public void setCount(String count){
		try{
			this.count = Integer.parseInt(count);
		}catch(NumberFormatException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public void setMoney(String money){
		try{
			this.money = Integer.parseInt(money);
		}catch(NumberFormatException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
	}
	
}
