package com.motor.impl;

public interface CarController {
	public void goAhead();
	public void goBack();
	public void stop();
	public void startEngine();
	public void offEngine();
}
