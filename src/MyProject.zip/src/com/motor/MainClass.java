package com.motor;

import com.motor.parts.Body;

public class MainClass {

	public static void main(String[] args) {
		Body body = new Body("���", 5, 4);
		
	}
}
